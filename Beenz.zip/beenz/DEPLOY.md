# Put Beenz online (free): Neon + Vercel

You need: a GitHub account, about 20 minutes, and Node.js installed on your computer
(for step 3). Both services have free plans that are enough for a university project.

---

## Step 1: Create the database on Neon

1. Go to **neon.tech** and sign up (you can use your GitHub account).
2. Create a project. Name it `beenz`. Pick the region closest to your students.
3. Open **Connect** (on the project dashboard) and copy the connection string.
   Choose the **pooled** connection if you're asked. It looks like:
   ```
   postgresql://user:password@ep-something-pooler.region.aws.neon.tech/neondb?sslmode=require
   ```
   Keep it secret: anyone with this string can read and change your database.

## Step 2: Put the code on GitHub

1. Go to **github.com/new**, create a **private** repository called `beenz`.
2. Upload the project:
   - easiest: on the new repo page click **uploading an existing file**, then drag in
     everything inside the `beenz` folder (not `node_modules` or `.next` if you have them), and commit;
   - or with git:
     ```bash
     git init && git add . && git commit -m "Beenz v1"
     git branch -M main
     git remote add origin https://github.com/YOUR-NAME/beenz.git
     git push -u origin main
     ```
   `.env.local` is listed in `.gitignore`, so your secrets are never uploaded.

## Step 3: Create the tables (once)

On your computer, inside the `beenz` folder:

```bash
copy .env.example .env.local        # Mac/Linux: cp .env.example .env.local
```

Open `.env.local` and set:

```
DATABASE_URL=<the Neon connection string from step 1>
ADMIN_EMAILS=<your own email>
```

Then:

```bash
npm install
npm run db:setup
```

You should see `Applying 001_initial_schema.sql ... Done. 1 migration(s) applied.`

## Step 4: Deploy on Vercel

1. Go to **vercel.com**, sign up with GitHub, click **Add New... → Project**, and
   import the `beenz` repository. Vercel detects Next.js by itself.
2. Before clicking Deploy, open **Environment Variables** and add:

   | Name | Value |
   |---|---|
   | `DATABASE_URL` | the Neon connection string |
   | `ADMIN_EMAILS` | your email (comma-separate several) |
   | `ALLOWED_EMAIL_DOMAINS` | leave empty to allow any email, or your university domain, e.g. `students.youruni.edu.pk` |

3. Click **Deploy**. After about a minute you get a link like `https://beenz-xyz.vercel.app`.
4. Optional, for speed: in the Vercel project go to **Settings → Functions** and pick
   the region closest to your Neon database region.

## Step 5: First login

1. Open your link and **Create account** with the email you put in `ADMIN_EMAILS`.
2. You're an admin: you'll see **Moderation** in the top menu (on desktop).
3. In Moderation → People you can make classmates **moderators** to help review reports.
4. Post a welcome announcement (Moderation → Announcements) with the house rules.
5. Share the link.

## Updating the app later

Change the code, commit and push to GitHub. Vercel redeploys automatically.
If a new file appears in `db/migrations/`, run `npm run db:setup` again (with the
Neon `DATABASE_URL` in `.env.local`) before or right after pushing.

## Demo data

For a class demo, use a **separate** Neon database and Vercel project, then run:

```bash
SEED_URL=https://your-demo-link.vercel.app npm run db:seed
```

(Windows PowerShell: `$env:SEED_URL="https://your-demo-link.vercel.app"; npm run db:seed`.)
Don't seed the real site students use: it would add 14 fake accounts to their leaderboard.

## Backups and monitoring

- **Backups:** Neon keeps a history you can restore from (the length depends on your
  plan): Neon dashboard → Branches/Restore. For an extra copy, run
  `pg_dump "<DATABASE_URL>" > beenz-backup.sql` from any computer with PostgreSQL tools.
  Test a restore once on a scratch database so you know it works.
- **Errors:** Vercel dashboard → your project → **Logs** shows server errors
  (they're printed as `[api error]`).
- **Usage:** Moderation → Stats shows accounts, active users, ratings and open reports.

## Troubleshooting

| Problem | Fix |
|---|---|
| Every page shows an error after deploying | `DATABASE_URL` is missing or wrong in Vercel → Settings → Environment Variables. Redeploy after changing it. |
| `relation "users" does not exist` | You skipped step 3. Run `npm run db:setup` with the Neon URL. |
| I signed up but I'm not an admin | Your email must be in `ADMIN_EMAILS` exactly. Fix it, redeploy, then log out and back in. |
| Students can't sign up: "Sign-up is limited to..." | `ALLOWED_EMAIL_DOMAINS` is set. Empty it or add their domain. |
| "Too many sign-ups from this network" | Many students on one campus Wi-Fi share an IP. The limit is 30 per hour per network; raise it in `src/lib/account.ts` if needed. |
| A student forgot their password | Moderation → People → find them → Manage → **Reset password** (admins only). Give them the temporary password; they change it in Settings. |
