# Beenz

A social reputation platform. People rate each other from 1 to 5 ("beans"), ratings
add up to a score, and the score places each person in one of five tiers. Built from
the *Project Beenz product proposal* (version 1.0), MVP scope.

- **Stack:** Next.js 15 (App Router, React 19, TypeScript) + PostgreSQL, as one app
  (the proposal's "modular monolith": no separate backend server, no microservices).
- **Hosting:** free on Vercel (app) + Neon (database). See **[DEPLOY.md](DEPLOY.md)**.
- **Tests:** 42 automated tests (`npm test`) covering the proposal's acceptance criteria.

---

## 1. Features (MVP scope from the proposal)

| Proposal item | Where it lives |
|---|---|
| Registration and login | `/signup`, `/login`, `src/lib/account.ts`, `src/lib/auth.ts` |
| Onboarding | `/onboarding` |
| User profiles and search | `/u/[username]`, `/search` |
| Five-point ratings, one current rating per user pair | `PUT /api/v1/users/:username/ratings/me`, `src/lib/reputation.ts` |
| Server-side score and tier calculation | `src/lib/reputation.ts` (`recalculate`), rules in `src/lib/tiers.ts` |
| Rating history | `rating_audit_history` table + score history chart on profiles |
| Leaderboard | `/leaderboard` |
| Home feed (joins, rankings, tier-ups, milestones, announcements) | `/feed` |
| Basic notifications | `/notifications` (bell badge in the header) |
| Blocking and reporting | "More" menu on every profile |
| Moderation tools | `/admin` (reports, people, announcements, stats) |
| Account and privacy settings, account deletion | `/settings` |
| Responsive web UI | Phone layout with a bottom tab bar; desktop layout with a top nav |
| Basic analytics | Stats tab in `/admin` |

Deferred, as the proposal recommends: weighted voting, posts and direct messages,
communities, follows, native apps, multiple ranking algorithms.

## 2. How reputation works

| Rule | Value | Where to change it |
|---|---|---|
| Score | Simple average of eligible ratings, rounded to 2 decimals: `sum / count` | `src/lib/tiers.ts` |
| Tier thresholds | 1.00–1.49 → 1, 1.50–2.49 → 2, 2.50–3.49 → 3, 3.50–4.49 → 4, 4.50–5.00 → 5 | `TIERS` in `src/lib/tiers.ts` |
| Provisional period | No score or tier until **3** ratings | `MIN_RATINGS_FOR_TIER` |
| Eligible rating | A rating from an active (not suspended) account | `recalculate()` |
| Changing a rating | Allowed; **10 min** cooldown per person you rated | `RATING_CHANGE_COOLDOWN_MINUTES` |
| Rating volume cap | **60** rating actions per hour per person | `MAX_RATING_ACTIONS_PER_HOUR` |
| Leaderboard ties | Higher score first; then more ratings; equal on both = shared rank | `getLeaderboard()` |

Every score is **derived data**. The `ratings` table is the source of truth; whenever
a rating changes, the server re-derives the score from all eligible ratings inside a
database transaction. The rated person's row is locked (`SELECT ... FOR UPDATE`),
so ratings that arrive at the same moment are applied one after another and the
score can't be corrupted. Each change writes a `reputation_snapshots` row tagged
with the algorithm version (`simple-average-v1`).

## 3. Privacy and safety (proposal section 11)

| Risk | What the app does |
|---|---|
| Fake accounts | Rate-limited sign-up; tiers need 3 ratings; optional email-domain restriction (`ALLOWED_EMAIL_DOMAINS`); moderators can suspend |
| Rating brigades | Reports with a "rating abuse" reason; moderators can see the ratings an account gave (logged) and remove them all at once |
| Reciprocal boosting | Moderators can review ratings given; suspended accounts' ratings stop counting automatically |
| Automated voting | Per-person hourly cap, per-pair cooldown, login and sign-up rate limits (stored in Postgres, so they work on serverless) |
| Score corruption | Transactions, row locks, unique `(rater, subject)` key, `CHECK` constraints, deterministic recalculation |
| Harassment | Votes are private; blocking stops ratings both ways and hides the blocker; only tier *ups* appear in the public feed, drops are private |
| Admin abuse | Roles (user, moderator, admin); every moderator action goes to `moderation_actions` and `audit_logs` |

Privacy defaults: individual votes are never shown to anyone except the person who
gave them. Scores are hidden while a profile is provisional, so the first one or two
voters can't be identified from the score. Feed events are aggregate (joined, ranked,
tier up, milestones), never single ratings. People can pause new ratings, hide from
the leaderboard and feed, or delete their account. All pages need a login.

Security: passwords are hashed with scrypt; session tokens are random 256-bit values,
and only their SHA-256 hash is stored. Cookies are `httpOnly`, `SameSite=Lax` and
`Secure` in production. Mutating API calls from other websites are rejected (Origin
check). All SQL is parameterised. Security headers are set in `next.config.mjs`.

## 4. Architecture

```
Browser (React pages)  ──fetch──►  REST API  /api/v1/*  (Next.js route handlers)
        ▲                                   │
        │ server-rendered pages             ▼
        └──────────── src/lib/*  (auth, reputation engine, moderation, queries)
                                            │
                                            ▼
                                  PostgreSQL (Neon)
```

Pages are rendered on the server and read from the same `src/lib` functions the API
uses, so there's one set of rules. Buttons (rate, report, block, settings) call the
REST API, then refresh the page to show the score the server calculated. The browser
never decides a score or rank.

### Folder structure

```
beenz/
├── db/migrations/001_initial_schema.sql   tables, constraints, indexes
├── scripts/
│   ├── db-setup.mjs        applies migrations (npm run db:setup)
│   └── seed-demo.mjs       demo accounts + ratings via the API (npm run db:seed)
├── src/
│   ├── app/
│   │   ├── page.tsx, login/, signup/        public pages
│   │   ├── (app)/                           pages that need a login
│   │   │   feed/ search/ u/[username]/ leaderboard/ notifications/ settings/ onboarding/ admin/
│   │   └── api/v1/                          REST API (route.ts files)
│   ├── components/                          UI pieces (Bean, TierBadge, BeanRating, AdminConsole, ...)
│   └── lib/
│       ├── tiers.ts          scoring rules (pure functions, unit tested)
│       ├── reputation.ts     rating actions + recalculation + notifications
│       ├── auth.ts           passwords, sessions, roles
│       ├── account.ts        sign-up, login, settings, deletion
│       ├── moderation.ts     blocks, reports, moderator actions, stats
│       ├── users.ts          profiles, search, leaderboard, feed queries
│       ├── validation.ts     input checks
│       ├── ratelimit.ts      Postgres-backed rate limiting
│       ├── http.ts           consistent JSON responses and errors
│       └── db.ts             connection pool + transactions
└── tests/
    ├── unit.test.ts          score and tier rules
    └── api.test.mjs          end-to-end API tests (acceptance criteria)
```

## 5. API

All responses are JSON: `{ "data": ... }` on success, `{ "error": { "code", "message" } }`
on failure. Users are addressed by **username** in URLs (usernames can't change);
the internal UUID stays the stable key in the database.

| Method | Endpoint | Purpose |
|---|---|---|
| POST | `/api/v1/auth/signup` | Create an account (and log in) |
| POST | `/api/v1/auth/login` | Log in |
| POST | `/api/v1/auth/logout` | Log out |
| GET / PATCH / DELETE | `/api/v1/me` | Your account / update profile and privacy / delete account |
| PATCH | `/api/v1/me/password` | Change password |
| GET | `/api/v1/users/:username` | Profile |
| GET | `/api/v1/users/:username/reputation` | Score, tier and history |
| PUT / DELETE | `/api/v1/users/:username/ratings/me` | Create or replace / remove your rating `{ "value": 1-5 }` |
| POST / DELETE | `/api/v1/users/:username/block` | Block / unblock |
| GET | `/api/v1/search?q=` | Find people |
| GET | `/api/v1/leaderboard?page=` | Ranked users, 25 per page |
| GET | `/api/v1/feed?before=` | Feed, 20 per page |
| GET | `/api/v1/notifications` · POST `/api/v1/notifications/read` | Notifications |
| POST | `/api/v1/reports` | Report someone |
| GET | `/api/v1/admin/reports?status=` · PATCH `/api/v1/admin/reports/:id` | Moderators: review reports |
| GET | `/api/v1/admin/users?q=` · POST `/api/v1/admin/users/:id` | Moderators: suspend, unsuspend, remove ratings, clear profile; admins: reset password, set role |
| GET | `/api/v1/admin/users/:id/ratings-given` | Moderators: ratings an account gave (logged) |
| POST | `/api/v1/admin/announcements` | Post to everyone's feed |
| GET | `/api/v1/admin/stats` | Basic analytics |

## 6. Run it on your computer

1. Install **Node.js 20 LTS or newer** from nodejs.org.
2. Get a PostgreSQL database: either install PostgreSQL locally, or create a free
   database on Neon (see DEPLOY.md, step 1) and use its connection string.
3. In this folder:
   ```bash
   copy .env.example .env.local      # Windows (Mac/Linux: cp .env.example .env.local)
   # edit .env.local: set DATABASE_URL and ADMIN_EMAILS
   npm install
   npm run db:setup                  # creates the tables
   npm run dev                       # http://localhost:3000
   ```
4. Sign up with the email you put in `ADMIN_EMAILS`. That account is an admin.
5. Optional demo data (14 accounts, ~125 ratings; password `beenz-demo-123`):
   keep the app running and, in a second terminal, run `npm run db:seed`.

## 7. Tests

```bash
# in .env.local add a SEPARATE throwaway database (it is wiped on every run):
# TEST_DATABASE_URL=postgres://.../beenz_test
npm run build
npm test
```

`tests/unit.test.ts` checks the average, rounding and every tier boundary.
`tests/api.test.mjs` starts the real app and checks: sign-up/login/logout, self-rating
rejected, invalid values rejected, duplicate requests can't create duplicate votes,
updates and deletes change the score, provisional handling, 20 simultaneous ratings,
leaderboard order and ties, blocking, reporting, suspension removing ratings from
scores, moderator vs admin permissions, CSRF protection, login rate limiting, account
deletion, feed privacy and notification de-duplication.

Last run: **42 passed, 0 failed.**

## 8. Configuration

| Variable | Required | Default | Meaning |
|---|---|---|---|
| `DATABASE_URL` | yes | – | PostgreSQL connection string |
| `ADMIN_EMAILS` | yes | – | Comma-separated emails that become admins |
| `ALLOWED_EMAIL_DOMAINS` | no | empty (anyone) | e.g. `students.youruni.edu.pk` to allow only university emails |
| `MIN_RATINGS_FOR_TIER` | no | 3 | Ratings needed to be ranked |
| `RATING_CHANGE_COOLDOWN_MINUTES` | no | 10 | Wait before changing a rating of the same person |
| `MAX_RATING_ACTIONS_PER_HOUR` | no | 60 | Rating actions per person per hour |

## 9. Decisions made (proposal section 16)

| Question | Decision in v1 |
|---|---|
| Simple or weighted average? | Simple average (proposal Option A) |
| Minimum ratings before ranking? | 3 (configurable) |
| Can users edit or delete ratings? | Yes, with a 10-minute cooldown per person |
| Do ratings expire or decay? | No |
| How are ties resolved? | More ratings ranks higher; equal score and count share a rank |
| Can users follow one another? Are posts in the MVP? | No; deferred |
| Who can rate whom? | Any logged-in, active user can rate anyone else who accepts ratings, unless either has blocked the other |
| Are votes private? | Yes, always. Only aggregates are public |
| Global or community leaderboards? | One global leaderboard |
| Who can moderate? | Moderators and admins; admins are set with `ADMIN_EMAILS`, and admins can promote moderators |
| Can decisions be appealed? | Suspended users see the reason and are told to contact the moderators |
| What happens when an account is suspended? | Logged out, can't log in, profile hidden, its ratings stop counting until unsuspended |
| What is kept after deletion? | Nothing personal. Audit rows keep only anonymous values (user IDs are set to null) |
| Web-only or mobile? Which auth? Where hosted? | Responsive web; built-in email + password auth; Vercel + Neon |
