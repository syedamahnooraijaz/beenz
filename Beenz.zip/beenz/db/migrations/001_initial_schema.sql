-- ============================================================================
-- Beenz database schema, version 1
-- PostgreSQL 13+ (gen_random_uuid is built in)
--
-- Rule of thumb: the `ratings` table is the source of truth.
-- Score, tier and rating_count on `users` are DERIVED data that the server
-- recalculates from ratings whenever a rating changes.
-- ============================================================================

-- ---------------------------------------------------------------------------
-- Users and sessions
-- ---------------------------------------------------------------------------
CREATE TABLE users (
  id                  uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  username            text NOT NULL CHECK (username ~ '^[a-z0-9_]{3,20}$'),
  email               text NOT NULL,
  password_hash       text NOT NULL,
  display_name        text NOT NULL CHECK (char_length(display_name) BETWEEN 1 AND 40),
  bio                 text NOT NULL DEFAULT '' CHECK (char_length(bio) <= 160),
  avatar_color        text NOT NULL DEFAULT '#3D3BD1' CHECK (avatar_color ~ '^#[0-9A-Fa-f]{6}$'),
  role                text NOT NULL DEFAULT 'user' CHECK (role IN ('user', 'moderator', 'admin')),
  status              text NOT NULL DEFAULT 'active' CHECK (status IN ('active', 'suspended')),
  suspension_reason   text,
  onboarded           boolean NOT NULL DEFAULT false,

  -- privacy preferences
  accepts_ratings     boolean NOT NULL DEFAULT true,   -- can others rate me?
  is_public           boolean NOT NULL DEFAULT true,   -- show me on leaderboard + feed

  -- derived reputation (recalculated by the server)
  score               numeric(3,2) CHECK (score BETWEEN 1 AND 5),   -- NULL = no ratings yet
  tier                smallint CHECK (tier BETWEEN 1 AND 5),         -- NULL = provisional
  rating_count        integer NOT NULL DEFAULT 0 CHECK (rating_count >= 0),

  created_at          timestamptz NOT NULL DEFAULT now(),
  updated_at          timestamptz NOT NULL DEFAULT now(),
  last_active_at      timestamptz NOT NULL DEFAULT now()
);

CREATE UNIQUE INDEX users_username_unique ON users (lower(username));
CREATE UNIQUE INDEX users_email_unique ON users (lower(email));
CREATE INDEX users_leaderboard ON users (score DESC, rating_count DESC, created_at)
  WHERE tier IS NOT NULL AND status = 'active' AND is_public;
CREATE INDEX users_display_name_search ON users (lower(display_name));

CREATE TABLE sessions (
  token_hash    text PRIMARY KEY,               -- SHA-256 of the cookie token (raw token never stored)
  user_id       uuid NOT NULL REFERENCES users (id) ON DELETE CASCADE,
  created_at    timestamptz NOT NULL DEFAULT now(),
  expires_at    timestamptz NOT NULL,
  last_seen_at  timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX sessions_user ON sessions (user_id);
CREATE INDEX sessions_expiry ON sessions (expires_at);

-- ---------------------------------------------------------------------------
-- Ratings (source of truth) + audit trail + reputation history
-- ---------------------------------------------------------------------------
CREATE TABLE ratings (
  rater_id    uuid NOT NULL REFERENCES users (id) ON DELETE CASCADE,
  subject_id  uuid NOT NULL REFERENCES users (id) ON DELETE CASCADE,
  value       smallint NOT NULL CHECK (value BETWEEN 1 AND 5),
  created_at  timestamptz NOT NULL DEFAULT now(),
  updated_at  timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (rater_id, subject_id),          -- one active rating per rater-subject pair
  CHECK (rater_id <> subject_id)               -- no self-rating, enforced by the database too
);
CREATE INDEX ratings_subject ON ratings (subject_id);

CREATE TABLE rating_audit_history (
  id          bigserial PRIMARY KEY,
  rater_id    uuid REFERENCES users (id) ON DELETE SET NULL,
  subject_id  uuid REFERENCES users (id) ON DELETE SET NULL,
  action      text NOT NULL CHECK (action IN ('create', 'update', 'delete', 'moderator_remove')),
  old_value   smallint,
  new_value   smallint,
  created_at  timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX rating_audit_rater_time ON rating_audit_history (rater_id, created_at);
CREATE INDEX rating_audit_pair_time ON rating_audit_history (rater_id, subject_id, created_at);

CREATE TABLE reputation_snapshots (
  id                 bigserial PRIMARY KEY,
  user_id            uuid NOT NULL REFERENCES users (id) ON DELETE CASCADE,
  score              numeric(3,2),
  tier               smallint,
  rating_count       integer NOT NULL,
  algorithm_version  text NOT NULL,
  calculated_at      timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX reputation_snapshots_user_time ON reputation_snapshots (user_id, calculated_at);

-- ---------------------------------------------------------------------------
-- Social: blocks, notifications, feed
-- ---------------------------------------------------------------------------
CREATE TABLE blocks (
  blocker_id  uuid NOT NULL REFERENCES users (id) ON DELETE CASCADE,
  blocked_id  uuid NOT NULL REFERENCES users (id) ON DELETE CASCADE,
  created_at  timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (blocker_id, blocked_id),
  CHECK (blocker_id <> blocked_id)
);
CREATE INDEX blocks_blocked ON blocks (blocked_id);

CREATE TABLE notifications (
  id          bigserial PRIMARY KEY,
  user_id     uuid NOT NULL REFERENCES users (id) ON DELETE CASCADE,
  type        text NOT NULL,
  message     text NOT NULL,
  link        text,
  dedupe_key  text,                          -- stops the same milestone being sent twice
  read_at     timestamptz,
  created_at  timestamptz NOT NULL DEFAULT now()
);
CREATE UNIQUE INDEX notifications_dedupe ON notifications (user_id, dedupe_key) WHERE dedupe_key IS NOT NULL;
CREATE INDEX notifications_user ON notifications (user_id, id DESC);

CREATE TABLE feed_events (
  id          bigserial PRIMARY KEY,
  type        text NOT NULL CHECK (type IN ('joined', 'ranked', 'tier_up', 'milestone', 'announcement')),
  user_id     uuid REFERENCES users (id) ON DELETE CASCADE,
  data        jsonb NOT NULL DEFAULT '{}',
  created_at  timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX feed_events_user ON feed_events (user_id);

-- ---------------------------------------------------------------------------
-- Trust and safety: reports, moderation, audit log, rate limits
-- ---------------------------------------------------------------------------
CREATE TABLE reports (
  id               bigserial PRIMARY KEY,
  reporter_id      uuid REFERENCES users (id) ON DELETE SET NULL,
  subject_id       uuid NOT NULL REFERENCES users (id) ON DELETE CASCADE,
  reason           text NOT NULL CHECK (reason IN ('harassment', 'fake_account', 'rating_abuse',
                                                   'inappropriate_profile', 'spam', 'other')),
  details          text NOT NULL DEFAULT '' CHECK (char_length(details) <= 1000),
  status           text NOT NULL DEFAULT 'open' CHECK (status IN ('open', 'resolved', 'dismissed')),
  resolution_note  text,
  resolved_by      uuid REFERENCES users (id) ON DELETE SET NULL,
  created_at       timestamptz NOT NULL DEFAULT now(),
  resolved_at      timestamptz
);
CREATE INDEX reports_status ON reports (status, created_at);
CREATE UNIQUE INDEX reports_one_open_per_pair ON reports (reporter_id, subject_id) WHERE status = 'open';

CREATE TABLE moderation_actions (
  id              bigserial PRIMARY KEY,
  moderator_id    uuid REFERENCES users (id) ON DELETE SET NULL,
  target_user_id  uuid REFERENCES users (id) ON DELETE SET NULL,
  report_id       bigint REFERENCES reports (id) ON DELETE SET NULL,
  action          text NOT NULL,
  note            text NOT NULL DEFAULT '',
  created_at      timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX moderation_actions_target ON moderation_actions (target_user_id, created_at);

CREATE TABLE audit_logs (
  id          bigserial PRIMARY KEY,
  actor_id    uuid REFERENCES users (id) ON DELETE SET NULL,
  action      text NOT NULL,
  target      text,
  ip          text,
  created_at  timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX audit_logs_time ON audit_logs (created_at);

CREATE TABLE rate_limits (
  key           text PRIMARY KEY,
  window_start  timestamptz NOT NULL,
  count         integer NOT NULL
);
