// Creates demo accounts and ratings THROUGH THE API (so every rule runs).
// Usage:  npm run db:seed                 (app running on http://localhost:3000)
//         SEED_URL=https://your-app.vercel.app npm run db:seed
// Every demo account uses the password: beenz-demo-123
import { loadEnv } from "./env.mjs";

loadEnv();
const BASE = process.env.SEED_URL || process.argv[2] || "http://localhost:3000";
const PASSWORD = "beenz-demo-123";

const PEOPLE = [
  ["ali_raza", "Ali Raza", "#3D3BD1", "Aerospace, 3rd year. Football on Fridays."],
  ["ayesha_s", "Ayesha Siddiqui", "#1F9D6B", "Computing. Runs the coding club."],
  ["bilal_ahmed", "Bilal Ahmed", "#C27C0E", "Electrical engineering. Always has a charger."],
  ["fatima_noor", "Fatima Noor", "#7A4FD6", "Space science. Astrophotography nerd."],
  ["hassan_j", "Hassan Javed", "#2F6FE4", "Mechanical. Fixes everyone's bikes."],
  ["iqra_malik", "Iqra Malik", "#C2416B", "Materials science. Debate society."],
  ["usman_t", "Usman Tariq", "#0E8A9A", "Avionics. Cricket captain."],
  ["zainab_shah", "Zainab Shah", "#5B5F73", "Computing. Notes are legendary."],
  ["saad_q", "Saad Qureshi", "#3D3BD1", "Electrical. DJ at every event."],
  ["mahnoor_i", "Mahnoor Iqbal", "#1F9D6B", "Aerospace. Model rocketry team."],
  ["daniyal_b", "Daniyal Butt", "#C27C0E", "Mechanical. Gym before 8am."],
  ["hira_aslam", "Hira Aslam", "#7A4FD6", "Space science. Planetarium volunteer."],
  ["omar_f", "Omar Farooq", "#2F6FE4", "Computing. Ships side projects."],
  ["sana_mirza", "Sana Mirza", "#C2416B", "Materials. Photography society."],
];

// Each person has a "typical" rating so the demo has a spread of tiers.
const TYPICAL = [4.6, 4.2, 3.4, 4.8, 3.9, 2.8, 3.6, 4.4, 2.2, 4.0, 3.1, 4.7, 1.6, 3.8];

async function call(path, { method = "GET", body, cookie } = {}) {
  const res = await fetch(BASE + path, {
    method,
    headers: { ...(body ? { "Content-Type": "application/json" } : {}), ...(cookie ? { Cookie: cookie } : {}) },
    body: body ? JSON.stringify(body) : undefined,
  });
  const json = await res.json().catch(() => ({}));
  const setCookie = res.headers.get("set-cookie");
  return { status: res.status, json, cookie: setCookie ? setCookie.split(";")[0] : null };
}

async function account(username, displayName, extra = {}) {
  const email = `${username}@beenz.test`;
  let r = await call("/api/v1/auth/signup", { method: "POST", body: { username, displayName, email, password: PASSWORD } });
  if (r.status === 409) r = await call("/api/v1/auth/login", { method: "POST", body: { email, password: PASSWORD } });
  if (!r.cookie) throw new Error(`Could not sign in ${username}: ${JSON.stringify(r.json)}`);
  await call("/api/v1/me", { method: "PATCH", cookie: r.cookie, body: { onboarded: true, ...extra } });
  return r.cookie;
}

// deterministic pseudo-random numbers so the demo looks the same every time
let seed = 7;
const rand = () => ((seed = (seed * 16807) % 2147483647) / 2147483647);

console.log(`Seeding demo data at ${BASE} ...`);
const cookies = [];
for (const [username, name, color, bio] of PEOPLE) {
  cookies.push(await account(username, name, { avatarColor: color, bio }));
}
const adminEmail = (process.env.ADMIN_EMAILS || "").split(",")[0]?.trim();
if (adminEmail) console.log(`Tip: sign up with ${adminEmail} to get the admin role.`);

let given = 0;
for (let i = 0; i < PEOPLE.length; i++) {
  for (let j = 0; j < PEOPLE.length; j++) {
    if (i === j || rand() < 0.35) continue;
    const value = Math.min(5, Math.max(1, Math.round(TYPICAL[j] + (rand() - 0.5) * 1.6)));
    const r = await call(`/api/v1/users/${PEOPLE[j][0]}/ratings/me`, { method: "PUT", cookie: cookies[i], body: { value } });
    if (r.status === 200) given++;
  }
}
console.log(`Done: ${PEOPLE.length} demo accounts, ${given} ratings. Password for all of them: ${PASSWORD}`);
