import { AdminConsole } from "@/components/AdminConsole";
import { requirePageModerator } from "@/lib/page";

export const metadata = { title: "Moderation" };

export default async function AdminPage() {
  const user = await requirePageModerator();
  return (
    <div className="page" style={{ maxWidth: 900 }}>
      <div className="page-head">
        <h1>Moderation</h1>
        <p>Review reports, manage accounts and post announcements. Every action here is logged.</p>
      </div>
      <AdminConsole isAdmin={user.role === "admin"} />
    </div>
  );
}
