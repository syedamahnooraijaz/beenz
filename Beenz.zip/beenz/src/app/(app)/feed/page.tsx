import Link from "next/link";
import { FeedEntry } from "@/components/FeedEntry";
import { PersonRow } from "@/components/PersonRow";
import { StandingPanel } from "@/components/StandingPanel";
import { requirePageUser } from "@/lib/page";
import { getFeed, myStanding, suggestPeople } from "@/lib/users";

export const metadata = { title: "Feed" };

export default async function FeedPage({ searchParams }: { searchParams: Promise<{ before?: string }> }) {
  const user = await requirePageUser("/feed");
  const { before } = await searchParams;
  const b = Number.parseInt(before ?? "", 10);
  const [feed, standing, suggestions] = await Promise.all([
    getFeed(user, Number.isFinite(b) ? b : null),
    myStanding(user.id),
    suggestPeople(user, 5),
  ]);

  return (
    <div className="with-aside">
      <div className="page">
        <div className="page-head">
          <h1>Feed</h1>
          <p>New members, people getting ranked, tier moves and milestones. Individual ratings never appear here.</p>
        </div>
        {feed.items.length === 0 ? (
          <div className="empty">
            <h3>Nothing here yet</h3>
            <p>
              When people join and get rated, it shows up here. <Link href="/search">Find people to rate</Link>.
            </p>
          </div>
        ) : (
          <ul className="list">
            {feed.items.map((item) => (
              <li key={item.id}>
                <FeedEntry item={item} />
              </li>
            ))}
          </ul>
        )}
        <div className="pager">
          {before ? <Link href="/feed">Back to newest</Link> : <span />}
          {feed.nextBefore ? <Link href={`/feed?before=${feed.nextBefore}`}>Older</Link> : null}
        </div>
      </div>

      <aside className="aside">
        <StandingPanel standing={standing} username={user.username} />
        <section className="panel">
          <h2 className="panel-title">People you haven&apos;t rated</h2>
          {suggestions.length ? (
            <ul className="list">
              {suggestions.map((p) => (
                <li key={p.id}>
                  <PersonRow user={p} compact />
                </li>
              ))}
            </ul>
          ) : (
            <p className="muted small">You&apos;ve rated everyone who&apos;s accepting ratings. Nice.</p>
          )}
        </section>
      </aside>
    </div>
  );
}
