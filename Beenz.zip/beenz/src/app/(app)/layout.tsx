import Link from "next/link";
import { redirect } from "next/navigation";
import { Avatar } from "@/components/Avatar";
import { NavLinks, TabBar } from "@/components/NavLinks";
import { Wordmark } from "@/components/Wordmark";
import { getCurrentUser, isModerator } from "@/lib/auth";
import { unreadCount } from "@/lib/users";

// Every page in this folder needs a logged-in user.
export default async function AppLayout({ children }: { children: React.ReactNode }) {
  const user = await getCurrentUser();
  if (!user) redirect("/login");
  if (user.status === "suspended") redirect("/login?suspended=1");
  const unread = await unreadCount(user.id);

  return (
    <>
      <header className="app-header">
        <div className="app-header-inner">
          <Wordmark href="/feed" />
          <NavLinks isModerator={isModerator(user)} />
          <div className="header-right">
            <Link href="/notifications" className="bell" aria-label={unread ? `Notifications, ${unread} unread` : "Notifications"}>
              <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" aria-hidden="true">
                <path d="M6 16V11a6 6 0 1 1 12 0v5l1.5 2h-15L6 16Zm4 4h4" />
              </svg>
              {unread > 0 ? <span className="count">{unread > 99 ? "99+" : unread}</span> : null}
            </Link>
            <Link href="/settings" className="bell" aria-label="Settings">
              <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" aria-hidden="true">
                <path d="M4 7h10M18 7h2M4 17h4M12 17h8" /><circle cx="16" cy="7" r="2" /><circle cx="10" cy="17" r="2" />
              </svg>
            </Link>
            <Link href={`/u/${user.username}`} className="me-link">
              <Avatar name={user.displayName} color={user.avatarColor} size={34} />
              <span className="me-name">{user.displayName}</span>
            </Link>
          </div>
        </div>
      </header>
      <main className="app-main">{children}</main>
      <TabBar username={user.username} />
    </>
  );
}
