import Link from "next/link";
import { Avatar } from "@/components/Avatar";
import { TierBadge } from "@/components/TierBadge";
import { requirePageUser } from "@/lib/page";
import { formatScore } from "@/lib/tiers";
import { getLeaderboard } from "@/lib/users";

export const metadata = { title: "Leaderboard" };

export default async function LeaderboardPage({ searchParams }: { searchParams: Promise<{ page?: string }> }) {
  const user = await requirePageUser("/leaderboard");
  const page = Math.max(1, Number.parseInt((await searchParams).page ?? "1", 10) || 1);
  const board = await getLeaderboard(page);
  const pages = Math.max(1, Math.ceil(board.total / board.pageSize));

  return (
    <div className="page">
      <div className="page-head">
        <h1>Leaderboard</h1>
        <p>
          Ranked by average score. When scores are equal, more ratings ranks higher; equal on both means a shared rank.
          Only ranked people with public profiles appear.
        </p>
      </div>
      {board.entries.length === 0 ? (
        <div className="empty">
          <h3>No one is ranked yet</h3>
          <p>People appear here once enough others have rated them. <Link href="/search">Rate someone</Link> to get it started.</p>
        </div>
      ) : (
        <ol className="list">
          {board.entries.map((e) => (
            <li key={e.id}>
              <Link href={`/u/${e.username}`} className={`board-row${e.id === user.id ? " me" : ""}`}>
                <span className={`rank${e.rank <= 3 ? " top" : ""}`}>{e.rank}</span>
                <Avatar name={e.displayName} color={e.avatarColor} size={40} />
                <span className="person-text">
                  <span className="person-name">{e.displayName}{e.id === user.id ? " (you)" : ""}</span>
                  <span className="person-handle">@{e.username}, {e.reputation.ratingCount} ratings</span>
                </span>
                <span className="person-end">
                  <TierBadge tier={e.reputation.tier} />
                  <span className="score-small">{formatScore(e.reputation.score)}</span>
                </span>
              </Link>
            </li>
          ))}
        </ol>
      )}
      {pages > 1 ? (
        <nav className="pager" aria-label="Pages">
          {page > 1 ? <Link href={`/leaderboard?page=${page - 1}`}>Previous</Link> : <span />}
          <span className="muted small">Page {page} of {pages}</span>
          {page < pages ? <Link href={`/leaderboard?page=${page + 1}`}>Next</Link> : <span />}
        </nav>
      ) : null}
    </div>
  );
}
