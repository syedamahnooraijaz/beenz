import Link from "next/link";
import { MarkAllRead } from "@/components/MarkAllRead";
import { timeAgo } from "@/lib/format";
import { requirePageUser } from "@/lib/page";
import { getNotifications } from "@/lib/users";

export const metadata = { title: "Notifications" };

export default async function NotificationsPage({ searchParams }: { searchParams: Promise<{ before?: string }> }) {
  const user = await requirePageUser("/notifications");
  const b = Number.parseInt((await searchParams).before ?? "", 10);
  const { items, nextBefore } = await getNotifications(user.id, Number.isFinite(b) ? b : null);
  const hasUnread = items.some((n) => !n.read);

  return (
    <div className="page">
      <MarkAllRead hasUnread={hasUnread} />
      <div className="page-head">
        <h1>Notifications</h1>
        <p>Tier changes, milestones and replies to your reports. You&apos;re never told who rated you.</p>
      </div>
      {items.length === 0 ? (
        <div className="empty">
          <h3>No notifications yet</h3>
          <p>You&apos;ll hear from us when your tier changes or you reach a milestone.</p>
        </div>
      ) : (
        <ul className="list">
          {items.map((n) => (
            <li key={n.id} className="spread" style={{ padding: "14px 4px", alignItems: "flex-start", flexWrap: "nowrap" }}>
              <span className="row" style={{ flexWrap: "nowrap", alignItems: "flex-start" }}>
                <span
                  aria-label={n.read ? undefined : "Unread"}
                  style={{ width: 8, height: 8, marginTop: 8, borderRadius: 4, flex: "none", background: n.read ? "transparent" : "var(--accent)" }}
                />
                <span style={{ fontWeight: n.read ? 400 : 600 }}>
                  {n.link ? <Link href={n.link} style={{ color: "inherit" }}>{n.message}</Link> : n.message}
                </span>
              </span>
              <span className="muted small" style={{ whiteSpace: "nowrap" }}>{timeAgo(n.createdAt)}</span>
            </li>
          ))}
        </ul>
      )}
      {nextBefore ? (
        <div className="pager"><span /><Link href={`/notifications?before=${nextBefore}`}>Older</Link></div>
      ) : null}
    </div>
  );
}
