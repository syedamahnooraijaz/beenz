import { OnboardingForm } from "@/components/OnboardingForm";
import { config } from "@/lib/config";
import { requirePageUser } from "@/lib/page";
import { getMyAccount } from "@/lib/users";

export const metadata = { title: "Welcome" };

export default async function OnboardingPage() {
  const user = await requirePageUser("/onboarding");
  const me = await getMyAccount(user.id);
  if (!me) return null;
  return (
    <div className="page">
      <div className="page-head">
        <h1>Welcome to Beenz, {me.displayName}</h1>
        <p>Set up your profile. You can change all of this later in Settings.</p>
      </div>
      <OnboardingForm
        initial={{
          displayName: me.displayName, bio: me.bio, avatarColor: me.avatarColor,
          acceptsRatings: me.acceptsRatings, isPublic: me.isPublic, minRatings: config.minRatingsForTier,
        }}
      />
    </div>
  );
}
