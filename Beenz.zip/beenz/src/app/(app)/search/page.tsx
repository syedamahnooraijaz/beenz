import { PersonRow } from "@/components/PersonRow";
import { requirePageUser } from "@/lib/page";
import { recentUsers, searchUsers } from "@/lib/users";

export const metadata = { title: "Find people" };

export default async function SearchPage({ searchParams }: { searchParams: Promise<{ q?: string }> }) {
  const user = await requirePageUser("/search");
  const q = ((await searchParams).q ?? "").trim();
  const results = q ? await searchUsers(user, q, 30) : await recentUsers(user, 20);

  return (
    <div className="page">
      <div className="page-head">
        <h1>Find people</h1>
        <p>Search by name or username, then open a profile to rate them.</p>
      </div>
      <form role="search" action="/search" className="row" style={{ marginBottom: 20, flexWrap: "nowrap" }}>
        <div className="field" style={{ flex: 1 }}>
          <label htmlFor="q" className="sr-only">Name or username</label>
          <input id="q" name="q" type="search" defaultValue={q} placeholder="Name or username" autoComplete="off" />
        </div>
        <button className="btn" type="submit">Search</button>
      </form>

      <h2 className="panel-title">{q ? `Results for "${q}"` : "New on Beenz"}</h2>
      {results.length ? (
        <ul className="list">
          {results.map((u) => (
            <li key={u.id}>
              <PersonRow user={u} />
            </li>
          ))}
        </ul>
      ) : (
        <div className="empty">
          <h3>{q ? `No one matches "${q}"` : "No one else is here yet"}</h3>
          <p>{q ? "Check the spelling, or try part of their username." : "Share the link with your classmates so they can join."}</p>
        </div>
      )}
    </div>
  );
}
