import { SettingsForms } from "@/components/SettingsForms";
import { requirePageUser } from "@/lib/page";
import { getMyAccount } from "@/lib/users";

export const metadata = { title: "Settings" };

export default async function SettingsPage() {
  const user = await requirePageUser("/settings");
  const me = await getMyAccount(user.id);
  if (!me) return null;
  return (
    <div className="page">
      <div className="page-head">
        <h1>Settings</h1>
        <p>Your profile, privacy, password and account.</p>
      </div>
      <SettingsForms me={me} />
    </div>
  );
}
