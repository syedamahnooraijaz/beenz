import Link from "next/link";

export default function ProfileNotFound() {
  return (
    <div className="page empty">
      <h3>This profile isn&apos;t available</h3>
      <p>The account may have been deleted or suspended, or the username is misspelled.</p>
      <p style={{ marginTop: 12 }}><Link href="/search">Search for people</Link></p>
    </div>
  );
}
