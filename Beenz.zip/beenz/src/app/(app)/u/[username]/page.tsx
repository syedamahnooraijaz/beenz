import Link from "next/link";
import { notFound } from "next/navigation";
import { Avatar } from "@/components/Avatar";
import { BeanRating } from "@/components/BeanRating";
import { ProfileActions } from "@/components/ProfileActions";
import { ScoreChart } from "@/components/ScoreChart";
import { TierBadge } from "@/components/TierBadge";
import { joinedDate } from "@/lib/format";
import { requirePageUser } from "@/lib/page";
import { formatScore } from "@/lib/tiers";
import { getProfile } from "@/lib/users";

type Params = { params: Promise<{ username: string }> };

export async function generateMetadata({ params }: Params) {
  const { username } = await params;
  return { title: `@${username}` };
}

export default async function ProfilePage({ params }: Params) {
  const { username } = await params;
  const viewer = await requirePageUser(`/u/${username}`);
  const p = await getProfile(viewer, username);
  if (!p) notFound();
  const r = p.reputation;
  const provisional = r.tier === null;
  const needed = Math.max(0, r.minRatings - r.ratingCount);

  return (
    <div className="page stack-l">
      <header>
        <div className="profile-head">
          <Avatar name={p.displayName} color={p.avatarColor} size={84} />
          <div style={{ minWidth: 0 }}>
            <h1>{p.displayName}</h1>
            <p className="muted">
              @{p.username}, joined {joinedDate(p.joinedAt)}
            </p>
          </div>
          {!p.isMe ? <ProfileActions username={p.username} blockedByMe={p.blockedByMe} /> : null}
        </div>
        {p.bio ? <p className="profile-bio">{p.bio}</p> : null}
      </header>

      <section className="standing" aria-label="Reputation">
        <div className={`big-score${provisional ? " pending" : ""}`}>
          {provisional ? (
            <>
              {r.ratingCount}
              <span className="of">/{r.minRatings}</span>
            </>
          ) : (
            formatScore(r.score)
          )}
        </div>
        <div className="facts">
          <TierBadge tier={r.tier} large />
          <p className="muted small">
            {provisional
              ? r.ratingCount === 0
                ? `No ratings yet. A score appears after ${r.minRatings} people rate ${p.isMe ? "you" : "them"}.`
                : `${r.ratingCount} of ${r.minRatings} ratings. ${needed} more until ${p.isMe ? "you're" : "they're"} ranked.`
              : `Average of ${r.ratingCount} rating${r.ratingCount === 1 ? "" : "s"}.`}
          </p>
        </div>
        {!provisional ? <ScoreChart history={p.history} /> : null}
      </section>

      {p.isMe ? (
        <section className="rate-panel stack">
          <h2>This is your profile</h2>
          <p className="muted">
            Others see your tier and average score once you&apos;re ranked. They never see who rated you or what anyone gave.
          </p>
          <div className="row">
            <Link className="btn btn-quiet btn-small" href="/settings">Edit profile and privacy</Link>
            {!p.acceptsRatings ? <span className="pill warn">You&apos;ve paused new ratings</span> : null}
          </div>
        </section>
      ) : p.blockedByMe ? (
        <p className="notice">You blocked @{p.username}. Neither of you can rate the other. Use More to unblock.</p>
      ) : !p.acceptsRatings ? (
        <p className="notice">@{p.username} has paused new ratings.</p>
      ) : p.canRate ? (
        <section className="rate-panel stack">
          <div className="head">
            <h2>Your rating</h2>
            <span className="muted small">Pick 1 to 5 beans</span>
          </div>
          <BeanRating username={p.username} displayName={p.displayName} initial={p.myRating} />
        </section>
      ) : null}

      <p className="muted small">
        A score shows what people on Beenz think right now. It isn&apos;t a measure of anyone&apos;s worth.
      </p>
    </div>
  );
}
