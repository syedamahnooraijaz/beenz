import { requireModerator } from "@/lib/auth";
import { ok, readJson, route } from "@/lib/http";
import { announce } from "@/lib/moderation";

/** POST /api/v1/admin/announcements  { text }  - posts to everyone's feed */
export const POST = route(async (req) => {
  const mod = await requireModerator();
  await announce(mod, await readJson(req));
  return ok({ posted: true }, 201);
});
