import { requireModerator } from "@/lib/auth";
import { ok, readJson, route } from "@/lib/http";
import { closeReport } from "@/lib/moderation";

/** PATCH /api/v1/admin/reports/:id  { status: "resolved" | "dismissed", note? }  (moderators) */
export const PATCH = route(async (req, { params }) => {
  const mod = await requireModerator();
  const { id } = await params;
  await closeReport(mod, id, await readJson(req));
  return ok({ closed: true });
});
