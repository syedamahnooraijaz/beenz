import { requireModerator } from "@/lib/auth";
import { ok, route } from "@/lib/http";
import { listReports } from "@/lib/moderation";

/** GET /api/v1/admin/reports?status=open|resolved|dismissed  (moderators) */
export const GET = route(async (req) => {
  await requireModerator();
  return ok({ reports: await listReports(req.nextUrl.searchParams.get("status") ?? "open") });
});
