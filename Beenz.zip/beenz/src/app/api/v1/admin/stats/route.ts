import { requireModerator } from "@/lib/auth";
import { ok, route } from "@/lib/http";
import { stats } from "@/lib/moderation";

/** GET /api/v1/admin/stats  - basic product analytics */
export const GET = route(async () => {
  await requireModerator();
  return ok(await stats());
});
