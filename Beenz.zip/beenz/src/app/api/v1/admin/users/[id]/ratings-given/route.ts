import { requireModerator } from "@/lib/auth";
import { fail, ok, route } from "@/lib/http";
import { ratingsGivenBy } from "@/lib/moderation";

/** GET /api/v1/admin/users/:id/ratings-given  (moderators; every view is logged) */
export const GET = route(async (_req, { params }) => {
  const mod = await requireModerator();
  const { id } = await params;
  if (!/^[0-9a-f-]{36}$/i.test(id)) throw fail.notFound("User not found.");
  return ok({ ratings: await ratingsGivenBy(mod, id) });
});
