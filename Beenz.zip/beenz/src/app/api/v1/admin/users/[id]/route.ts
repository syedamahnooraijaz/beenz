import { requireModerator } from "@/lib/auth";
import { fail, ok, readJson, route } from "@/lib/http";
import { moderateUser } from "@/lib/moderation";

const UUID = /^[0-9a-f-]{36}$/i;

/**
 * POST /api/v1/admin/users/:id
 *   { action: "suspend", reason } | { action: "unsuspend" } | { action: "remove_ratings", reason? }
 *   { action: "clear_profile" } | { action: "reset_password" } (admin) | { action: "set_role", role } (admin)
 */
export const POST = route(async (req, { params }) => {
  const mod = await requireModerator();
  const { id } = await params;
  if (!UUID.test(id)) throw fail.notFound("User not found.");
  return ok(await moderateUser(mod, id, await readJson(req)));
});
