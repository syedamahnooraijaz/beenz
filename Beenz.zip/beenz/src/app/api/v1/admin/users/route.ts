import { requireModerator } from "@/lib/auth";
import { ok, route } from "@/lib/http";
import { adminSearchUsers } from "@/lib/moderation";

/** GET /api/v1/admin/users?q=  (moderators; emails visible to admins only) */
export const GET = route(async (req) => {
  const mod = await requireModerator();
  return ok({ users: await adminSearchUsers(mod, req.nextUrl.searchParams.get("q") ?? "") });
});
