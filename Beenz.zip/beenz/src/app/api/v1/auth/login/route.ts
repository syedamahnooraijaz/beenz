import { login } from "@/lib/account";
import { clientIp, ok, readJson, route } from "@/lib/http";

/** POST /api/v1/auth/login  { email, password } */
export const POST = route(async (req) => {
  const user = await login(await readJson(req), clientIp(req));
  return ok({ user });
});
