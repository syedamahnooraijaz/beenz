import { destroySession } from "@/lib/auth";
import { ok, route } from "@/lib/http";

/** POST /api/v1/auth/logout */
export const POST = route(async () => {
  await destroySession();
  return ok({ loggedOut: true });
});
