import { signup } from "@/lib/account";
import { clientIp, ok, readJson, route } from "@/lib/http";

/** POST /api/v1/auth/signup  { username, email, password, displayName? } */
export const POST = route(async (req) => {
  const user = await signup(await readJson(req), clientIp(req));
  return ok({ user }, 201);
});
