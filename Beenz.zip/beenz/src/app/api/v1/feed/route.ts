import { requireUser } from "@/lib/auth";
import { ok, route } from "@/lib/http";
import { getFeed } from "@/lib/users";

/** GET /api/v1/feed?before=<id>  - newest first, 20 per page */
export const GET = route(async (req) => {
  const me = await requireUser();
  const before = Number.parseInt(req.nextUrl.searchParams.get("before") ?? "", 10);
  return ok(await getFeed(me, Number.isFinite(before) ? before : null));
});
