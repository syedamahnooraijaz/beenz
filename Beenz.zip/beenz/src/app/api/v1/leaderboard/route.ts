import { requireUser } from "@/lib/auth";
import { ok, route } from "@/lib/http";
import { getLeaderboard } from "@/lib/users";

/** GET /api/v1/leaderboard?page=1 */
export const GET = route(async (req) => {
  await requireUser();
  const page = Number.parseInt(req.nextUrl.searchParams.get("page") ?? "1", 10) || 1;
  return ok(await getLeaderboard(page));
});
