import { changePassword } from "@/lib/account";
import { requireUser } from "@/lib/auth";
import { clientIp, ok, readJson, route } from "@/lib/http";

/** PATCH /api/v1/me/password  { currentPassword, newPassword } */
export const PATCH = route(async (req) => {
  const me = await requireUser();
  await changePassword(me.id, await readJson(req), clientIp(req));
  return ok({ changed: true });
});
