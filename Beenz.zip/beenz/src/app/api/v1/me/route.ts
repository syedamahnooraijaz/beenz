import { deleteAccount, updateMe } from "@/lib/account";
import { destroySession, requireUser } from "@/lib/auth";
import { clientIp, ok, readJson, route } from "@/lib/http";
import { getMyAccount } from "@/lib/users";

/** GET /api/v1/me  - the logged-in user's account */
export const GET = route(async () => {
  const me = await requireUser();
  return ok({ me: await getMyAccount(me.id) });
});

/** PATCH /api/v1/me  { displayName?, bio?, avatarColor?, acceptsRatings?, isPublic?, onboarded? } */
export const PATCH = route(async (req) => {
  const me = await requireUser();
  await updateMe(me.id, await readJson(req));
  return ok({ me: await getMyAccount(me.id) });
});

/** DELETE /api/v1/me  { password }  - permanently delete the account */
export const DELETE = route(async (req) => {
  const me = await requireUser();
  await deleteAccount(me.id, await readJson(req), clientIp(req));
  await destroySession();
  return ok({ deleted: true });
});
