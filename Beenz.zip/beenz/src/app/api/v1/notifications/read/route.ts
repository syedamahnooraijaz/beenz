import { requireUser } from "@/lib/auth";
import { query } from "@/lib/db";
import { ok, route } from "@/lib/http";

/** POST /api/v1/notifications/read  - mark all your notifications as read */
export const POST = route(async () => {
  const me = await requireUser();
  await query(`UPDATE notifications SET read_at = now() WHERE user_id = $1 AND read_at IS NULL`, [me.id]);
  return ok({ unread: 0 });
});
