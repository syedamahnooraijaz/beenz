import { requireUser } from "@/lib/auth";
import { ok, route } from "@/lib/http";
import { getNotifications, unreadCount } from "@/lib/users";

/** GET /api/v1/notifications?before=<id> */
export const GET = route(async (req) => {
  const me = await requireUser();
  const before = Number.parseInt(req.nextUrl.searchParams.get("before") ?? "", 10);
  const page = await getNotifications(me.id, Number.isFinite(before) ? before : null);
  return ok({ ...page, unread: await unreadCount(me.id) });
});
