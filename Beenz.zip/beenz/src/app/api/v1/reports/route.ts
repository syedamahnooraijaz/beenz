import { requireUser } from "@/lib/auth";
import { ok, readJson, route } from "@/lib/http";
import { createReport } from "@/lib/moderation";

/** POST /api/v1/reports  { username, reason, details? } */
export const POST = route(async (req) => {
  const me = await requireUser();
  return ok({ report: await createReport(me, await readJson(req)) }, 201);
});
