import { requireUser } from "@/lib/auth";
import { ok, route } from "@/lib/http";
import { searchUsers } from "@/lib/users";

/** GET /api/v1/search?q=  - find people by name or username */
export const GET = route(async (req) => {
  const me = await requireUser();
  const q = req.nextUrl.searchParams.get("q") ?? "";
  return ok({ users: await searchUsers(me, q) });
});
