import { requireUser } from "@/lib/auth";
import { fail, ok, route } from "@/lib/http";
import { block, unblock } from "@/lib/moderation";
import { findUserByUsername } from "@/lib/users";

async function target(params: Promise<Record<string, string>>) {
  const { username } = await params;
  const user = await findUserByUsername(username);
  if (!user) throw fail.notFound("That person doesn't exist.");
  return user.id;
}

/** POST /api/v1/users/:username/block */
export const POST = route(async (_req, { params }) => {
  const me = await requireUser();
  await block(me, await target(params));
  return ok({ blocked: true });
});

/** DELETE /api/v1/users/:username/block */
export const DELETE = route(async (_req, { params }) => {
  const me = await requireUser();
  await unblock(me, await target(params));
  return ok({ blocked: false });
});
