import { requireUser } from "@/lib/auth";
import { fail, ok, readJson, route } from "@/lib/http";
import { removeRating, setRating } from "@/lib/reputation";
import { findUserByUsername } from "@/lib/users";
import { ratingValue } from "@/lib/validation";

async function subjectId(params: Promise<Record<string, string>>) {
  const { username } = await params;
  const subject = await findUserByUsername(username);
  if (!subject) throw fail.notFound("That person doesn't exist.");
  return subject.id;
}

/**
 * PUT /api/v1/users/:username/ratings/me  { value: 1-5 }
 * Creates or replaces YOUR rating of this person. The voter is taken from the
 * session, never from the request body. Sending the same value twice is a no-op.
 */
export const PUT = route(async (req, { params }) => {
  const me = await requireUser();
  const value = ratingValue((await readJson(req)).value);
  return ok(await setRating(me.id, await subjectId(params), value));
});

/** DELETE /api/v1/users/:username/ratings/me  - remove your rating */
export const DELETE = route(async (_req, { params }) => {
  const me = await requireUser();
  return ok(await removeRating(me.id, await subjectId(params)));
});
