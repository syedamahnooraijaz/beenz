import { getCurrentUser } from "@/lib/auth";
import { fail, ok, route } from "@/lib/http";
import { getProfile } from "@/lib/users";

/** GET /api/v1/users/:username  - public profile (+ your own rating of them, if logged in) */
export const GET = route(async (_req, { params }) => {
  const { username } = await params;
  const profile = await getProfile(await getCurrentUser(), username);
  if (!profile) throw fail.notFound("That profile doesn't exist or isn't available.");
  return ok({ profile });
});
