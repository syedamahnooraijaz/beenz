import "@fontsource-variable/bricolage-grotesque";
import "@fontsource-variable/instrument-sans";
import "./globals.css";
import type { Metadata, Viewport } from "next";

export const metadata: Metadata = {
  title: { default: "Beenz", template: "%s | Beenz" },
  description: "Rate people from 1 to 5. Ratings add up to a score, and the score places each person in one of five tiers.",
};

export const viewport: Viewport = { themeColor: "#f3f4f9", width: "device-width", initialScale: 1 };

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
