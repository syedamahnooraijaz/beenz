import { redirect } from "next/navigation";
import { AuthForm } from "@/components/AuthForm";
import { Wordmark } from "@/components/Wordmark";
import { getCurrentUser } from "@/lib/auth";

export const metadata = { title: "Log in" };

export default async function LoginPage({ searchParams }: { searchParams: Promise<{ next?: string; suspended?: string }> }) {
  const { next, suspended } = await searchParams;
  const user = await getCurrentUser();
  if (user && user.status === "active") redirect("/feed");
  const safeNext = next && next.startsWith("/") && !next.startsWith("//") ? next : "/feed";
  return (
    <div className="auth-wrap">
      <div className="auth-box">
        <Wordmark />
        <h1>Log in</h1>
        <p className="muted" style={{ marginBottom: 22 }}>Welcome back.</p>
        <AuthForm mode="login" next={safeNext} initialError={suspended ? "Your account is suspended. Contact the moderators if you think this is a mistake." : undefined} />
      </div>
    </div>
  );
}
