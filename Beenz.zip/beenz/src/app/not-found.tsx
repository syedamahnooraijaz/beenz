import Link from "next/link";
import { Wordmark } from "@/components/Wordmark";

export default function NotFound() {
  return (
    <div className="auth-wrap">
      <div className="auth-box stack">
        <Wordmark />
        <h1>Page not found</h1>
        <p className="muted">The link may be broken, or the page was removed.</p>
        <p><Link href="/">Go to the home page</Link></p>
      </div>
    </div>
  );
}
