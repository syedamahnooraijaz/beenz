import Link from "next/link";
import { redirect } from "next/navigation";
import { Bean } from "@/components/Bean";
import { LandingDemo } from "@/components/LandingDemo";
import { Wordmark } from "@/components/Wordmark";
import { getCurrentUser } from "@/lib/auth";
import { TIERS } from "@/lib/tiers";

const RULES = [
  ["Your votes are private", "People see their own average and tier. Nobody sees who rated them or what anyone gave."],
  ["One rating per person", "You can change or remove your rating later, after a short wait."],
  ["No rating yourself", "The server checks every rating. Self-ratings and duplicate votes are rejected."],
  ["Ranked after 3 ratings", "Until then a profile is provisional. One generous friend can't make anyone top tier."],
  ["Block and report", "Block anyone to stop them rating you. Moderators review every report."],
  ["Pause any time", "Turn off new ratings, hide from the leaderboard, or delete your account in Settings."],
];

export default async function Landing({ searchParams }: { searchParams: Promise<{ deleted?: string }> }) {
  if (await getCurrentUser()) redirect("/feed");
  const { deleted } = await searchParams;

  return (
    <div className="landing">
      <header className="landing-header">
        <Wordmark />
        <nav className="row">
          <Link href="/login" className="btn btn-quiet btn-small">Log in</Link>
          <Link href="/signup" className="btn btn-small">Create account</Link>
        </nav>
      </header>

      {deleted ? <p className="notice success landing-notice">Your account and its data were deleted.</p> : null}

      <section className="hero">
        <div className="hero-copy">
          <h1>Reputation, rated by the people around you.</h1>
          <p className="lead">
            Give anyone on Beenz a rating from 1 to 5 beans. Ratings add up to a score, and the score places each person in
            one of five tiers.
          </p>
          <div className="row">
            <Link href="/signup" className="btn">Create your profile</Link>
            <Link href="/login" className="btn btn-quiet">Log in</Link>
          </div>
        </div>
        <LandingDemo />
      </section>

      <section className="ladder-section">
        <div className="ladder-copy">
          <h2>Five tiers</h2>
          <p className="muted">
            Your score is the plain average of every rating you&apos;ve received. Where it lands decides your tier, and your tier
            moves as ratings change.
          </p>
        </div>
        <ol className="ladder" reversed>
          {[...TIERS].reverse().map((t) => (
            <li key={t.tier} style={{ marginLeft: `calc(${t.tier - 1} * var(--step))` }}>
              <Bean size={46} color={t.color} />
              <span>
                <b>Tier {t.tier}</b> {t.name}
              </span>
              <span className="band">{t.band}</span>
            </li>
          ))}
        </ol>
      </section>

      <section className="rules">
        <h2>Built to stay fair</h2>
        <dl>
          {RULES.map(([title, text]) => (
            <div key={title}>
              <dt>{title}</dt>
              <dd>{text}</dd>
            </div>
          ))}
        </dl>
      </section>

      <footer className="landing-footer">
        <p>A score shows what people on Beenz think right now. It isn&apos;t a measure of anyone&apos;s worth.</p>
        <p className="muted small">Beenz, a university project.</p>
      </footer>
    </div>
  );
}
