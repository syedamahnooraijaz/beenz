import { redirect } from "next/navigation";
import { AuthForm } from "@/components/AuthForm";
import { Wordmark } from "@/components/Wordmark";
import { getCurrentUser } from "@/lib/auth";

export const metadata = { title: "Create account" };

export default async function SignupPage() {
  if (await getCurrentUser()) redirect("/feed");
  return (
    <div className="auth-wrap">
      <div className="auth-box">
        <Wordmark />
        <h1>Create your account</h1>
        <p className="muted" style={{ marginBottom: 22 }}>It takes a minute. Your ratings of others stay private.</p>
        <AuthForm mode="signup" next="/onboarding" />
      </div>
    </div>
  );
}
