"use client";

import Link from "next/link";
import { useCallback, useEffect, useState } from "react";
import { api } from "@/lib/api-client";
import { TIERS } from "@/lib/tiers";
import { Avatar } from "./Avatar";
import { TierBadge } from "./TierBadge";

type Report = {
  id: string; reasonLabel: string; details: string; status: string; resolutionNote: string | null;
  createdAt: string; reporter: string | null; resolvedBy: string | null;
  subject: { id: string; username: string; displayName: string; status: string; avatarColor: string; openReports: number };
};
type AdminUser = {
  id: string; username: string; displayName: string; avatarColor: string; email: string | null; role: string; status: string;
  suspensionReason: string | null; reputation: { tier: number | null; ratingCount: number }; ratingsGiven: number; openReports: number;
};
type Msg = { kind: "error" | "success"; text: string } | null;

const date = (iso: string) => new Date(iso).toLocaleString("en-GB", { day: "numeric", month: "short", hour: "2-digit", minute: "2-digit" });

/** Moderator tools for one person. Used inside reports and the people list. */
function UserActions({ user, isAdmin, onDone }: { user: { id: string; username: string; status: string; role?: string }; isAdmin: boolean; onDone: () => void }) {
  const [reason, setReason] = useState("");
  const [msg, setMsg] = useState<Msg>(null);
  const [ratings, setRatings] = useState<{ username: string; value: number; at: string }[] | null>(null);
  const [busy, setBusy] = useState(false);

  async function act(action: string, extra: Record<string, unknown> = {}) {
    setBusy(true);
    const { data, error } = await api<{ message: string }>(`/api/v1/admin/users/${user.id}`, { method: "POST", body: { action, reason, ...extra } });
    setBusy(false);
    setMsg(error ? { kind: "error", text: error.message } : { kind: "success", text: data?.message ?? "Done." });
    if (!error) onDone();
  }

  async function loadRatings() {
    const { data, error } = await api<{ ratings: typeof ratings }>(`/api/v1/admin/users/${user.id}/ratings-given`);
    if (error) return setMsg({ kind: "error", text: error.message });
    setRatings(data?.ratings ?? []);
  }

  return (
    <div className="stack" style={{ marginTop: 12 }}>
      <div className="field">
        <label htmlFor={`reason-${user.id}`}>Reason (required to suspend; shown to the person)</label>
        <input id={`reason-${user.id}`} value={reason} maxLength={300} onChange={(e) => setReason(e.target.value)} />
      </div>
      <div className="row">
        <Link className="btn btn-quiet btn-small" href={`/u/${user.username}`}>View profile</Link>
        <button className="btn btn-quiet btn-small" type="button" onClick={loadRatings}>Ratings they gave</button>
        {user.status === "active" ? (
          <button className="btn btn-danger btn-small" type="button" disabled={busy || !reason.trim()} onClick={() => act("suspend")}>Suspend</button>
        ) : (
          <button className="btn btn-small" type="button" disabled={busy} onClick={() => act("unsuspend")}>Unsuspend</button>
        )}
        <button className="btn btn-quiet btn-small" type="button" disabled={busy} onClick={() => act("remove_ratings")}>Remove their ratings</button>
        <button className="btn btn-quiet btn-small" type="button" disabled={busy} onClick={() => act("clear_profile")}>Clear name and bio</button>
        {isAdmin ? (
          <>
            <button className="btn btn-quiet btn-small" type="button" disabled={busy} onClick={() => act("reset_password")}>Reset password</button>
            <select
              aria-label="Role"
              className="btn btn-quiet btn-small"
              value={user.role ?? "user"}
              onChange={(e) => act("set_role", { role: e.target.value })}
            >
              <option value="user">Role: user</option>
              <option value="moderator">Role: moderator</option>
              <option value="admin">Role: admin</option>
            </select>
          </>
        ) : null}
      </div>
      {msg ? <p className={`notice ${msg.kind}`}>{msg.text}</p> : null}
      {ratings ? (
        ratings.length ? (
          <ul className="list small">
            {ratings.map((r) => (
              <li key={r.username} className="spread" style={{ padding: "6px 0" }}>
                <span>@{r.username}</span>
                <span>{r.value} / 5, {date(r.at)}</span>
              </li>
            ))}
          </ul>
        ) : (
          <p className="muted small">They haven&apos;t rated anyone.</p>
        )
      ) : null}
    </div>
  );
}

function ReportsTab({ isAdmin }: { isAdmin: boolean }) {
  const [status, setStatus] = useState("open");
  const [reports, setReports] = useState<Report[] | null>(null);
  const [notes, setNotes] = useState<Record<string, string>>({});
  const [msg, setMsg] = useState<Msg>(null);
  const [openTools, setOpenTools] = useState<string | null>(null);

  const load = useCallback(async () => {
    const { data, error } = await api<{ reports: Report[] }>(`/api/v1/admin/reports?status=${status}`);
    if (error) return setMsg({ kind: "error", text: error.message });
    setReports(data?.reports ?? []);
  }, [status]);

  useEffect(() => {
    load();
  }, [load]);

  async function close(id: string, next: "resolved" | "dismissed") {
    const { error } = await api(`/api/v1/admin/reports/${id}`, { method: "PATCH", body: { status: next, note: notes[id] ?? "" } });
    setMsg(error ? { kind: "error", text: error.message } : { kind: "success", text: `Report ${next}.` });
    load();
  }

  return (
    <div className="stack">
      <div className="row">
        {["open", "resolved", "dismissed"].map((s) => (
          <button key={s} type="button" className={`btn btn-small${s === status ? "" : " btn-quiet"}`} onClick={() => setStatus(s)}>
            {s[0].toUpperCase() + s.slice(1)}
          </button>
        ))}
      </div>
      {msg ? <p className={`notice ${msg.kind}`}>{msg.text}</p> : null}
      {reports === null ? (
        <p className="muted">Loading reports...</p>
      ) : reports.length === 0 ? (
        <div className="empty"><h3>No {status} reports</h3><p>{status === "open" ? "Nothing needs review right now." : "Nothing here yet."}</p></div>
      ) : (
        <div>
          {reports.map((r) => (
            <article key={r.id} className="report stack">
              <div className="spread">
                <span className="row">
                  <Avatar name={r.subject.displayName} color={r.subject.avatarColor} size={36} />
                  <span>
                    <b>{r.subject.displayName}</b> <span className="muted">@{r.subject.username}</span>
                  </span>
                  {r.subject.status === "suspended" ? <span className="pill warn">Suspended</span> : null}
                  {r.subject.openReports > 1 ? <span className="pill warn">{r.subject.openReports} open reports</span> : null}
                </span>
                <span className="muted small">{date(r.createdAt)}</span>
              </div>
              <p><b>{r.reasonLabel}</b>{r.reporter ? <span className="muted"> reported by @{r.reporter}</span> : null}</p>
              {r.details ? <p className="notice" style={{ whiteSpace: "pre-line" }}>{r.details}</p> : null}
              {r.status === "open" ? (
                <>
                  <button type="button" className="link-button small" onClick={() => setOpenTools(openTools === r.id ? null : r.id)}>
                    {openTools === r.id ? "Hide tools for this person" : "Tools for this person"}
                  </button>
                  {openTools === r.id ? <UserActions user={r.subject} isAdmin={isAdmin} onDone={load} /> : null}
                  <div className="field">
                    <label htmlFor={`note-${r.id}`}>Note for the record (optional)</label>
                    <input id={`note-${r.id}`} value={notes[r.id] ?? ""} onChange={(e) => setNotes({ ...notes, [r.id]: e.target.value })} />
                  </div>
                  <div className="row">
                    <button className="btn btn-small" type="button" onClick={() => close(r.id, "resolved")}>Mark resolved</button>
                    <button className="btn btn-quiet btn-small" type="button" onClick={() => close(r.id, "dismissed")}>Dismiss</button>
                  </div>
                </>
              ) : (
                <p className="muted small">
                  {r.status === "resolved" ? "Resolved" : "Dismissed"}{r.resolvedBy ? ` by @${r.resolvedBy}` : ""}
                  {r.resolutionNote ? `: ${r.resolutionNote}` : ""}
                </p>
              )}
            </article>
          ))}
        </div>
      )}
    </div>
  );
}

function PeopleTab({ isAdmin }: { isAdmin: boolean }) {
  const [q, setQ] = useState("");
  const [users, setUsers] = useState<AdminUser[] | null>(null);
  const [open, setOpen] = useState<string | null>(null);

  const load = useCallback(async (term: string) => {
    const { data } = await api<{ users: AdminUser[] }>(`/api/v1/admin/users?q=${encodeURIComponent(term)}`);
    setUsers(data?.users ?? []);
  }, []);

  useEffect(() => {
    load("");
  }, [load]);

  return (
    <div className="stack">
      <form className="row" style={{ flexWrap: "nowrap" }} onSubmit={(e) => { e.preventDefault(); load(q); }}>
        <div className="field" style={{ flex: 1 }}>
          <label htmlFor="admin-q" className="sr-only">Search people</label>
          <input id="admin-q" type="search" placeholder={isAdmin ? "Name, username or email" : "Name or username"} value={q} onChange={(e) => setQ(e.target.value)} />
        </div>
        <button className="btn" type="submit">Search</button>
      </form>
      {users === null ? <p className="muted">Loading...</p> : null}
      <ul className="list">
        {users?.map((u) => (
          <li key={u.id} style={{ padding: "12px 0" }}>
            <div className="spread">
              <span className="row">
                <Avatar name={u.displayName} color={u.avatarColor} size={36} />
                <span>
                  <b>{u.displayName}</b> <span className="muted">@{u.username}</span>
                  {u.email ? <span className="muted small"><br />{u.email}</span> : null}
                </span>
              </span>
              <span className="row">
                <TierBadge tier={u.reputation.tier} />
                {u.role !== "user" ? <span className="pill">{u.role}</span> : null}
                {u.status === "suspended" ? <span className="pill warn">Suspended</span> : null}
                {u.openReports ? <span className="pill warn">{u.openReports} open reports</span> : null}
                <span className="muted small">gave {u.ratingsGiven}, got {u.reputation.ratingCount}</span>
                <button className="btn btn-quiet btn-small" type="button" onClick={() => setOpen(open === u.id ? null : u.id)}>
                  {open === u.id ? "Close" : "Manage"}
                </button>
              </span>
            </div>
            {u.suspensionReason ? <p className="muted small">Suspended: {u.suspensionReason}</p> : null}
            {open === u.id ? <UserActions user={u} isAdmin={isAdmin} onDone={() => load(q)} /> : null}
          </li>
        ))}
      </ul>
    </div>
  );
}

function AnnounceTab() {
  const [text, setText] = useState("");
  const [msg, setMsg] = useState<Msg>(null);
  async function post(e: React.FormEvent) {
    e.preventDefault();
    const { error } = await api("/api/v1/admin/announcements", { method: "POST", body: { text } });
    setMsg(error ? { kind: "error", text: error.message } : { kind: "success", text: "Posted to everyone's feed." });
    if (!error) setText("");
  }
  return (
    <form className="stack" onSubmit={post}>
      <div className="field">
        <label htmlFor="announcement">Announcement</label>
        <textarea id="announcement" maxLength={500} value={text} onChange={(e) => setText(e.target.value)} placeholder="Shown at the top of everyone's feed" />
        <span className="hint">{500 - text.length} characters left</span>
      </div>
      {msg ? <p className={`notice ${msg.kind}`}>{msg.text}</p> : null}
      <div><button className="btn" type="submit" disabled={!text.trim()}>Post announcement</button></div>
    </form>
  );
}

function StatsTab() {
  const [s, setS] = useState<Record<string, number> & { tiers?: Record<string, number> } | null>(null);
  useEffect(() => {
    api<typeof s>("/api/v1/admin/stats").then(({ data }) => setS(data ?? null));
  }, []);
  if (!s) return <p className="muted">Loading...</p>;
  const items: [string, string][] = [
    ["users", "Accounts"], ["new_users_7d", "New this week"], ["active_1d", "Active today"], ["active_30d", "Active this month"],
    ["ratings", "Ratings in total"], ["rating_actions_7d", "Rating changes this week"], ["users_rated", "People with a rating"],
    ["ranked", "Ranked people"], ["open_reports", "Open reports"], ["suspended", "Suspended"],
  ];
  const tiers = s.tiers ?? {};
  const max = Math.max(1, ...Object.values(tiers));
  return (
    <div className="stack-l">
      <div className="stat-grid">
        {items.map(([k, label]) => (
          <div className="stat" key={k}><b>{s[k] ?? 0}</b><span className="muted small">{label}</span></div>
        ))}
      </div>
      <section className="stack">
        <h2>People per tier</h2>
        {[...TIERS].reverse().map((t) => (
          <div className="bar-row" key={t.tier}>
            <span>Tier {t.tier}, {t.name}</span>
            <span className="bar" style={{ width: `${((tiers[t.tier] ?? 0) / max) * 100}%`, background: t.color, minWidth: 4 }} />
            <span>{tiers[t.tier] ?? 0}</span>
          </div>
        ))}
      </section>
    </div>
  );
}

export function AdminConsole({ isAdmin }: { isAdmin: boolean }) {
  const [tab, setTab] = useState("reports");
  const tabs: [string, string][] = [["reports", "Reports"], ["people", "People"], ["announce", "Announcements"], ["stats", "Stats"]];
  return (
    <div>
      <div className="tabs" role="tablist">
        {tabs.map(([id, label]) => (
          <button key={id} role="tab" type="button" aria-selected={tab === id} onClick={() => setTab(id)}>{label}</button>
        ))}
      </div>
      {tab === "reports" ? <ReportsTab isAdmin={isAdmin} /> : null}
      {tab === "people" ? <PeopleTab isAdmin={isAdmin} /> : null}
      {tab === "announce" ? <AnnounceTab /> : null}
      {tab === "stats" ? <StatsTab /> : null}
    </div>
  );
}
