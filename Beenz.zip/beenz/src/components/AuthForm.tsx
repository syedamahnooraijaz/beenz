"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { useState } from "react";
import { api, type ApiFailure } from "@/lib/api-client";

export function AuthForm({ mode, next, initialError }: { mode: "login" | "signup"; next: string; initialError?: string }) {
  const router = useRouter();
  const [form, setForm] = useState({ username: "", displayName: "", email: "", password: "" });
  const [error, setError] = useState<ApiFailure | null>(initialError ? { code: "info", message: initialError } : null);
  const [busy, setBusy] = useState(false);
  const set = (k: keyof typeof form) => (e: React.ChangeEvent<HTMLInputElement>) => setForm({ ...form, [k]: e.target.value });

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setBusy(true);
    setError(null);
    const body = mode === "signup" ? form : { email: form.email, password: form.password };
    const res = await api(`/api/v1/auth/${mode}`, { method: "POST", body });
    if (res.error) {
      setBusy(false);
      setError(res.error);
      return;
    }
    router.push(mode === "signup" ? "/onboarding" : next);
    router.refresh();
  }

  const fieldError = (f: string) => (error?.field === f ? <span className="field-error">{error.message}</span> : null);

  return (
    <form className="stack" onSubmit={submit} noValidate>
      {mode === "signup" ? (
        <>
          <div className="field">
            <label htmlFor="displayName">Your name</label>
            <input id="displayName" autoComplete="name" maxLength={40} value={form.displayName} onChange={set("displayName")} required />
            {fieldError("displayName")}
          </div>
          <div className="field">
            <label htmlFor="username">Username</label>
            <input id="username" autoComplete="username" autoCapitalize="none" maxLength={20} value={form.username} onChange={set("username")} required />
            <span className="hint">3–20 letters, numbers or underscores. It can&apos;t be changed later.</span>
            {fieldError("username")}
          </div>
        </>
      ) : null}
      <div className="field">
        <label htmlFor="email">Email</label>
        <input id="email" type="email" autoComplete="email" value={form.email} onChange={set("email")} required />
        {fieldError("email")}
      </div>
      <div className="field">
        <label htmlFor="password">Password</label>
        <input id="password" type="password" autoComplete={mode === "signup" ? "new-password" : "current-password"} value={form.password} onChange={set("password")} required />
        {mode === "signup" ? <span className="hint">At least 8 characters.</span> : null}
        {fieldError("password")}
      </div>
      {error && !error.field ? <p className={`notice ${error.code === "info" ? "" : "error"}`}>{error.message}</p> : null}
      <button className="btn btn-block" type="submit" disabled={busy}>
        {mode === "signup" ? (busy ? "Creating account..." : "Create account") : busy ? "Logging in..." : "Log in"}
      </button>
      <p className="muted small" style={{ textAlign: "center" }}>
        {mode === "signup" ? (
          <>Already have an account? <Link href="/login">Log in</Link></>
        ) : (
          <>New to Beenz? <Link href="/signup">Create an account</Link></>
        )}
      </p>
    </form>
  );
}
