// The bean: used for ratings, tier badges and the logo.
export const BEAN_PATH =
  "M3 13.5C2.6 6.6 8.4 2.2 14 3.6c2.9.7 5 .9 8 .1C28.4 2 34.2 5.6 33.6 12.6 33 20 26.5 24.4 18.2 24.4 9.6 24.4 3.4 20.6 3 13.5Z";

type Props = { size?: number; color?: string; shine?: boolean; title?: string };

export function Bean({ size = 24, color = "currentColor", shine = true, title }: Props) {
  return (
    <svg
      className="bean"
      width={size}
      height={Math.round(size * 0.74)}
      viewBox="0 0 36 27"
      role={title ? "img" : undefined}
      aria-hidden={title ? undefined : true}
    >
      {title ? <title>{title}</title> : null}
      <path d={BEAN_PATH} fill={color} />
      {shine ? (
        <path className="crease" d="M9 9.6c2.4-2 5.4-2.3 8.4-1.3" fill="none" strokeWidth="2.2" strokeLinecap="round" stroke="rgba(255,255,255,.55)" />
      ) : null}
    </svg>
  );
}
