"use client";

import { useRouter } from "next/navigation";
import { useState } from "react";
import { api } from "@/lib/api-client";
import { Bean } from "./Bean";

type Props = { username: string; displayName: string; initial: number | null };

/** Five beans. Pick one to rate 1-5; pick "Remove my rating" to take it back. */
export function BeanRating({ username, displayName, initial }: Props) {
  const router = useRouter();
  const [value, setValue] = useState<number | null>(initial);
  const [hover, setHover] = useState<number | null>(null);
  const [saving, setSaving] = useState(false);
  const [status, setStatus] = useState<{ kind: "error" | "success"; text: string } | null>(null);
  const shown = hover ?? value ?? 0;

  async function save(next: number | null) {
    if (saving || next === value) return;
    setSaving(true);
    setStatus(null);
    const { data, error } = await api<{ myRating: number | null }>(`/api/v1/users/${username}/ratings/me`, {
      method: next === null ? "DELETE" : "PUT",
      body: next === null ? undefined : { value: next },
    });
    setSaving(false);
    if (error) {
      setStatus({ kind: "error", text: error.message });
      return;
    }
    setValue(data?.myRating ?? null);
    setStatus({
      kind: "success",
      text: next === null ? "Your rating was removed." : `Saved. You rated ${displayName} ${next} out of 5.`,
    });
    router.refresh(); // reload the score the server calculated
  }

  return (
    <div className="stack">
      <div
        className={`bean-rating${saving ? " saving" : ""}`}
        role="group"
        aria-label={`Rate ${displayName} from 1 to 5`}
        onMouseLeave={() => setHover(null)}
      >
        {[1, 2, 3, 4, 5].map((n) => (
          <button
            key={n}
            type="button"
            data-on={n <= shown}
            aria-pressed={value === n}
            aria-label={`${n} out of 5`}
            disabled={saving}
            onMouseEnter={() => setHover(n)}
            onFocus={() => setHover(n)}
            onBlur={() => setHover(null)}
            onClick={() => save(n)}
          >
            <Bean size={44} />
          </button>
        ))}
      </div>
      <div className="row" aria-live="polite">
        <span className="muted small">
          {value ? `Your rating: ${value} out of 5.` : "You haven't rated this person."} Only you can see it.
        </span>
        {value ? (
          <button type="button" className="link-button small" onClick={() => save(null)} disabled={saving}>
            Remove my rating
          </button>
        ) : null}
      </div>
      {status ? <p className={`notice ${status.kind}`}>{status.text}</p> : null}
    </div>
  );
}
