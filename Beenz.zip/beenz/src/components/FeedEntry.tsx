import Link from "next/link";
import { timeAgo } from "@/lib/format";
import type { FeedItem } from "@/lib/users";
import { Avatar } from "./Avatar";
import { TierBadge } from "./TierBadge";

export function FeedEntry({ item }: { item: FeedItem }) {
  if (item.type === "announcement") {
    return (
      <div className="announcement">
        <p className="by">Announcement from {String(item.data.by ?? "the moderators")}, {timeAgo(item.createdAt)}</p>
        <p style={{ whiteSpace: "pre-line" }}>{String(item.data.text ?? "")}</p>
      </div>
    );
  }
  const u = item.user;
  if (!u) return null;
  const name = <Link href={`/u/${u.username}`}>{u.displayName}</Link>;
  let text: React.ReactNode;
  let badge: React.ReactNode = null;
  switch (item.type) {
    case "joined":
      text = <>{name} joined Beenz.</>;
      break;
    case "ranked":
      text = <>{name} has enough ratings to be ranked now.</>;
      break;
    case "tier_up":
      text = <>{name} moved up a tier.</>;
      badge = <TierBadge tier={Number(item.data.tier)} />;
      break;
    case "milestone":
      text = <>{name} has been rated by {String(item.data.count)} people.</>;
      break;
  }
  return (
    <div className="feed-item">
      <Link href={`/u/${u.username}`} tabIndex={-1} aria-hidden="true">
        <Avatar name={u.displayName} color={u.avatarColor} size={40} />
      </Link>
      <div className="feed-text">
        <p>{text}</p>
        {badge}
      </div>
      <span className="when">{timeAgo(item.createdAt)}</span>
    </div>
  );
}
