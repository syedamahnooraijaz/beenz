"use client";

import { useState } from "react";
import { formatScore, scoreFrom, tierForScore } from "@/lib/tiers";
import { Avatar } from "./Avatar";
import { Bean } from "./Bean";
import { TierBadge } from "./TierBadge";

const EXISTING = [5, 4, 4, 3]; // a made-up person's current ratings

/** Try the rating engine on the landing page. Nothing is saved. */
export function LandingDemo() {
  const [pick, setPick] = useState<number | null>(null);
  const [hover, setHover] = useState<number | null>(null);
  const ratings = pick ? [...EXISTING, pick] : EXISTING;
  const total = ratings.reduce((a, b) => a + b, 0);
  const score = scoreFrom(total, ratings.length);
  const tier = tierForScore(score, ratings.length, 3);
  const shown = hover ?? pick ?? 0;

  return (
    <div className="demo">
      <div className="row" style={{ gap: 14 }}>
        <Avatar name="Areeba Khan" color="#0E8A9A" size={52} />
        <div>
          <p style={{ fontWeight: 650, fontSize: 17 }}>Areeba Khan</p>
          <p className="muted small">@areeba, an example profile</p>
        </div>
      </div>

      <div className="demo-score">
        <span className="demo-number" aria-live="polite">{formatScore(score)}</span>
        <TierBadge tier={tier} large />
      </div>
      <p className="muted small">
        {ratings.length} ratings: {ratings.join(" + ")} = {total}, divided by {ratings.length}.
      </p>

      <div className="demo-rate">
        <p style={{ fontWeight: 600 }}>{pick ? "Your rating is in. Try another." : "Add your rating and watch the score move"}</p>
        <div className="bean-rating" role="group" aria-label="Example rating" onMouseLeave={() => setHover(null)}>
          {[1, 2, 3, 4, 5].map((n) => (
            <button
              key={n}
              type="button"
              data-on={n <= shown}
              aria-pressed={pick === n}
              aria-label={`${n} out of 5`}
              onMouseEnter={() => setHover(n)}
              onFocus={() => setHover(n)}
              onBlur={() => setHover(null)}
              onClick={() => setPick(pick === n ? null : n)}
            >
              <Bean size={40} />
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}
