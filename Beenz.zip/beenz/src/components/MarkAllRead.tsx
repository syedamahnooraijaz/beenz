"use client";

import { useRouter } from "next/navigation";
import { useEffect } from "react";
import { api } from "@/lib/api-client";

/** Marks notifications as read when the page opens, then refreshes the header badge. */
export function MarkAllRead({ hasUnread }: { hasUnread: boolean }) {
  const router = useRouter();
  useEffect(() => {
    if (!hasUnread) return;
    api("/api/v1/notifications/read", { method: "POST" }).then(() => router.refresh());
  }, [hasUnread, router]);
  return null;
}
