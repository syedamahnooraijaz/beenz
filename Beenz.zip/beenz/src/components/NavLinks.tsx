"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";

const LINKS = [
  { href: "/feed", label: "Feed" },
  { href: "/search", label: "Find people" },
  { href: "/leaderboard", label: "Leaderboard" },
];

function isActive(path: string, href: string) {
  return path === href || path.startsWith(href + "/");
}

export function NavLinks({ isModerator }: { isModerator: boolean }) {
  const path = usePathname();
  return (
    <nav className="nav-links" aria-label="Main">
      {LINKS.map((l) => (
        <Link key={l.href} href={l.href} aria-current={isActive(path, l.href) ? "page" : undefined}>
          {l.label}
        </Link>
      ))}
      {isModerator ? (
        <Link href="/admin" aria-current={isActive(path, "/admin") ? "page" : undefined}>
          Moderation
        </Link>
      ) : null}
    </nav>
  );
}

const ICONS: Record<string, string> = {
  feed: "M4 5h16M4 12h16M4 19h10",
  search: "M11 18a7 7 0 1 0 0-14 7 7 0 0 0 0 14Zm5-2 5 5",
  board: "M5 20V11M12 20V5M19 20v-6",
  me: "M12 12a4 4 0 1 0 0-8 4 4 0 0 0 0 8Zm-7 9a7 7 0 0 1 14 0",
};

export function TabBar({ username }: { username: string }) {
  const path = usePathname();
  const tabs = [
    { href: "/feed", label: "Feed", icon: "feed" },
    { href: "/search", label: "Find", icon: "search" },
    { href: "/leaderboard", label: "Ranks", icon: "board" },
    { href: `/u/${username}`, label: "Me", icon: "me" },
  ];
  return (
    <nav className="tabbar" aria-label="Main">
      {tabs.map((t) => (
        <Link key={t.href} href={t.href} aria-current={isActive(path, t.href) ? "page" : undefined}>
          <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" aria-hidden="true">
            <path d={ICONS[t.icon]} />
          </svg>
          {t.label}
        </Link>
      ))}
    </nav>
  );
}
