"use client";

import { useRouter } from "next/navigation";
import { useState } from "react";
import { api } from "@/lib/api-client";
import { PrivacyToggles, ProfileFields, type ProfileDraft } from "./ProfileFields";

type Initial = ProfileDraft & { acceptsRatings: boolean; isPublic: boolean; minRatings: number };

export function OnboardingForm({ initial }: { initial: Initial }) {
  const router = useRouter();
  const [draft, setDraft] = useState<ProfileDraft>({ displayName: initial.displayName, bio: initial.bio, avatarColor: initial.avatarColor });
  const [privacy, setPrivacy] = useState({ acceptsRatings: initial.acceptsRatings, isPublic: initial.isPublic });
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  async function finish() {
    setBusy(true);
    setError(null);
    const { error } = await api("/api/v1/me", { method: "PATCH", body: { ...draft, ...privacy, onboarded: true } });
    setBusy(false);
    if (error) return setError(error.message);
    router.push("/search");
    router.refresh();
  }

  return (
    <div className="stack-l">
      <section className="panel stack">
        <h2>1. Your profile</h2>
        <ProfileFields draft={draft} onChange={setDraft} />
      </section>

      <section className="panel stack">
        <h2>2. Privacy</h2>
        <PrivacyToggles {...privacy} onChange={(f, v) => setPrivacy({ ...privacy, [f]: v })} />
      </section>

      <section className="panel stack">
        <h2>3. How ratings work</h2>
        <ul className="stack" style={{ paddingLeft: 20, margin: 0 }}>
          <li>You can rate anyone else from 1 to 5 beans. One rating per person; you can change it later.</li>
          <li>Your ratings are private. People see their average, never who rated them or what anyone gave.</li>
          <li>Your score is the average of your ratings. After {initial.minRatings} ratings you get a tier from 1 to 5.</li>
          <li>Rate fairly. If someone uses ratings to bully, block and report them; moderators review every report.</li>
          <li>A score shows what people here think right now. It isn&apos;t a measure of anyone&apos;s worth.</li>
        </ul>
      </section>

      {error ? <p className="notice error">{error}</p> : null}
      <button className="btn" type="button" onClick={finish} disabled={busy}>
        {busy ? "Saving..." : "Save and find people"}
      </button>
    </div>
  );
}
