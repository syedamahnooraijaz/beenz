import Link from "next/link";
import { formatScore } from "@/lib/tiers";
import type { UserCard } from "@/lib/users";
import { Avatar } from "./Avatar";
import { TierBadge } from "./TierBadge";

export function PersonRow({ user, compact = false }: { user: UserCard; compact?: boolean }) {
  const r = user.reputation;
  const count = r.ratingCount > 0 ? `${r.ratingCount} rating${r.ratingCount === 1 ? "" : "s"}` : "not rated yet";
  return (
    <Link href={`/u/${user.username}`} className="person">
      <Avatar name={user.displayName} color={user.avatarColor} size={44} />
      <span className="person-text">
        <span className="person-name">{user.displayName}</span>
        <span className="person-handle">{compact ? `@${user.username}` : `@${user.username}, ${count}`}</span>
      </span>
      {compact ? null : (
        <span className="person-end">
          <TierBadge tier={r.tier} />
          <span className="score-small">{formatScore(r.score)}</span>
        </span>
      )}
    </Link>
  );
}
