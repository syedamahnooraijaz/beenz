"use client";

import { useRouter } from "next/navigation";
import { useEffect, useRef, useState } from "react";
import { api } from "@/lib/api-client";
import { REPORT_REASONS } from "@/lib/constants";

const REASONS = Object.entries(REPORT_REASONS);

export function ProfileActions({ username, blockedByMe }: { username: string; blockedByMe: boolean }) {
  const router = useRouter();
  const [open, setOpen] = useState(false);
  const reportRef = useRef<HTMLDialogElement>(null);
  const blockRef = useRef<HTMLDialogElement>(null);
  const [reason, setReason] = useState("");
  const [details, setDetails] = useState("");
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState<{ kind: "error" | "success"; text: string } | null>(null);

  useEffect(() => {
    if (!open) return;
    const close = () => setOpen(false);
    window.addEventListener("click", close);
    return () => window.removeEventListener("click", close);
  }, [open]);

  async function sendReport(e: React.FormEvent) {
    e.preventDefault();
    if (!reason) return setMessage({ kind: "error", text: "Choose a reason first." });
    setBusy(true);
    const { error } = await api("/api/v1/reports", { method: "POST", body: { username, reason, details } });
    setBusy(false);
    if (error) return setMessage({ kind: "error", text: error.message });
    setMessage({ kind: "success", text: "Report sent. A moderator will review it. The person isn't told who reported them." });
    setReason("");
    setDetails("");
  }

  async function toggleBlock() {
    setBusy(true);
    const { error } = await api(`/api/v1/users/${username}/block`, { method: blockedByMe ? "DELETE" : "POST" });
    setBusy(false);
    if (error) return setMessage({ kind: "error", text: error.message });
    blockRef.current?.close();
    router.refresh();
  }

  return (
    <div className="menu profile-menu">
      <button
        type="button"
        className="btn btn-quiet btn-small"
        aria-haspopup="menu"
        aria-expanded={open}
        onClick={(e) => {
          e.stopPropagation();
          setOpen(!open);
        }}
      >
        More
      </button>
      {open ? (
        <div className="menu-list" role="menu">
          <button role="menuitem" type="button" onClick={() => { setMessage(null); reportRef.current?.showModal(); }}>
            Report @{username}
          </button>
          <button role="menuitem" type="button" className="danger" onClick={() => { setMessage(null); blockRef.current?.showModal(); }}>
            {blockedByMe ? `Unblock @${username}` : `Block @${username}`}
          </button>
        </div>
      ) : null}

      <dialog ref={reportRef} aria-labelledby="report-title">
        <form className="stack" onSubmit={sendReport}>
          <h2 id="report-title">Report @{username}</h2>
          <p className="muted">Moderators review every report. Your name isn&apos;t shown to the person you report.</p>
          <fieldset className="stack" style={{ border: 0, padding: 0, margin: 0 }}>
            <legend className="sr-only">Reason</legend>
            {REASONS.map(([value, label]) => (
              <label key={value} className="row" style={{ gap: 8 }}>
                <input type="radio" name="reason" value={value} checked={reason === value} onChange={() => setReason(value)} />
                {label}
              </label>
            ))}
          </fieldset>
          <div className="field">
            <label htmlFor="report-details">What happened? (optional)</label>
            <textarea id="report-details" maxLength={1000} value={details} onChange={(e) => setDetails(e.target.value)} />
          </div>
          {message ? <p className={`notice ${message.kind}`}>{message.text}</p> : null}
          <div className="row" style={{ justifyContent: "flex-end" }}>
            <button type="button" className="btn btn-quiet" onClick={() => reportRef.current?.close()}>Close</button>
            <button type="submit" className="btn" disabled={busy}>Send report</button>
          </div>
        </form>
      </dialog>

      <dialog ref={blockRef} aria-labelledby="block-title">
        <div className="stack">
          <h2 id="block-title">{blockedByMe ? `Unblock @${username}?` : `Block @${username}?`}</h2>
          <p className="muted">
            {blockedByMe
              ? "You'll see each other again, and you'll both be able to rate each other."
              : "Neither of you will be able to rate the other, and they won't see your profile in search, the feed or on your profile page. Ratings already given stay; report them if they're abusive."}
          </p>
          {message ? <p className={`notice ${message.kind}`}>{message.text}</p> : null}
          <div className="row" style={{ justifyContent: "flex-end" }}>
            <button type="button" className="btn btn-quiet" onClick={() => blockRef.current?.close()}>Cancel</button>
            <button type="button" className={`btn${blockedByMe ? "" : " btn-danger"}`} disabled={busy} onClick={toggleBlock}>
              {blockedByMe ? "Unblock" : "Block"}
            </button>
          </div>
        </div>
      </dialog>
    </div>
  );
}
