"use client";

import { AVATAR_COLORS } from "@/lib/constants";
import { Avatar } from "./Avatar";

export type ProfileDraft = { displayName: string; bio: string; avatarColor: string };

/** Name, bio and colour fields, shared by onboarding and settings. */
export function ProfileFields({ draft, onChange }: { draft: ProfileDraft; onChange: (d: ProfileDraft) => void }) {
  return (
    <div className="stack">
      <div className="row" style={{ gap: 16 }}>
        <Avatar name={draft.displayName || "?"} color={draft.avatarColor} size={64} />
        <div className="field" style={{ flex: 1, minWidth: 200 }}>
          <span className="label" id="color-label">Avatar colour</span>
          <div className="swatches" role="radiogroup" aria-labelledby="color-label">
            {AVATAR_COLORS.map((c) => (
              <button
                key={c}
                type="button"
                role="radio"
                aria-checked={draft.avatarColor.toUpperCase() === c}
                aria-label={c}
                className="swatch"
                style={{ background: c }}
                onClick={() => onChange({ ...draft, avatarColor: c })}
              />
            ))}
          </div>
        </div>
      </div>
      <div className="field">
        <label htmlFor="displayName">Display name</label>
        <input id="displayName" maxLength={40} value={draft.displayName} onChange={(e) => onChange({ ...draft, displayName: e.target.value })} />
      </div>
      <div className="field">
        <label htmlFor="bio">Bio</label>
        <textarea id="bio" maxLength={160} value={draft.bio} placeholder="Course, year, what you're into" onChange={(e) => onChange({ ...draft, bio: e.target.value })} />
        <span className="hint">{160 - draft.bio.length} characters left</span>
      </div>
    </div>
  );
}

export function PrivacyToggles({
  acceptsRatings, isPublic, onChange,
}: { acceptsRatings: boolean; isPublic: boolean; onChange: (field: "acceptsRatings" | "isPublic", value: boolean) => void }) {
  return (
    <div>
      <label className="toggle">
        <span><b>Accept new ratings</b></span>
        <input type="checkbox" checked={acceptsRatings} onChange={(e) => onChange("acceptsRatings", e.target.checked)} />
        <span className="hint">Turn off to pause ratings. Ratings you already have stay.</span>
      </label>
      <label className="toggle">
        <span><b>Show me on the leaderboard and feed</b></span>
        <input type="checkbox" checked={isPublic} onChange={(e) => onChange("isPublic", e.target.checked)} />
        <span className="hint">People can still find and rate you through search.</span>
      </label>
    </div>
  );
}
