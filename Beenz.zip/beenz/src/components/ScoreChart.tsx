import { TIERS } from "@/lib/tiers";

/** Small line chart of score history, drawn over the five tier bands. */
export function ScoreChart({ history }: { history: { at: string; score: number }[] }) {
  if (history.length < 2) return null;
  const W = 600, H = 150, padL = 26, padR = 10, padT = 8, padB = 8;
  const y = (s: number) => padT + ((5 - s) / 4) * (H - padT - padB);
  const x = (i: number) => padL + (i / (history.length - 1)) * (W - padL - padR);
  const points = history.map((h, i) => `${x(i).toFixed(1)},${y(h.score).toFixed(1)}`).join(" ");
  const last = history[history.length - 1];
  const first = new Date(history[0].at);

  return (
    <figure className="chart" style={{ margin: 0 }}>
      <svg viewBox={`0 0 ${W} ${H}`} width="100%" role="img" aria-label={`Score history: ${history.length} changes, now ${last.score.toFixed(2)}`}>
        {TIERS.map((t, i) => {
          const top = y(i === TIERS.length - 1 ? 5 : TIERS[i + 1].minHundredths / 100);
          const bottom = y(t.minHundredths / 100);
          return <rect key={t.tier} x={padL} y={top} width={W - padL - padR} height={bottom - top} fill={t.color} opacity={0.07} />;
        })}
        {[1, 2, 3, 4, 5].map((v) => (
          <text key={v} x={padL - 8} y={y(v) + 4} textAnchor="end" fontSize="11" fill="#5d6382">{v}</text>
        ))}
        <polyline points={points} fill="none" stroke="#191c35" strokeWidth="2.5" strokeLinejoin="round" strokeLinecap="round" />
        <circle cx={x(history.length - 1)} cy={y(last.score)} r="5" fill="#3d3bd1" stroke="#fff" strokeWidth="2" />
      </svg>
      <figcaption className="muted small">
        Score since {first.toLocaleDateString("en-GB", { day: "numeric", month: "short" })}, last {history.length} changes. Background bands are the five tiers.
      </figcaption>
    </figure>
  );
}
