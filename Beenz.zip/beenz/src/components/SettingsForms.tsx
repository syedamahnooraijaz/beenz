"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { useRef, useState } from "react";
import { api } from "@/lib/api-client";
import type { MyAccount } from "@/lib/users";
import { PrivacyToggles, ProfileFields, type ProfileDraft } from "./ProfileFields";

type Msg = { kind: "error" | "success"; text: string } | null;

function Notice({ msg }: { msg: Msg }) {
  return msg ? <p className={`notice ${msg.kind}`} role="status">{msg.text}</p> : null;
}

export function SettingsForms({ me }: { me: MyAccount }) {
  const router = useRouter();
  const [draft, setDraft] = useState<ProfileDraft>({ displayName: me.displayName, bio: me.bio, avatarColor: me.avatarColor });
  const [privacy, setPrivacy] = useState({ acceptsRatings: me.acceptsRatings, isPublic: me.isPublic });
  const [pw, setPw] = useState({ currentPassword: "", newPassword: "" });
  const [deletePw, setDeletePw] = useState("");
  const [msgs, setMsgs] = useState<Record<string, Msg>>({});
  const deleteRef = useRef<HTMLDialogElement>(null);
  const say = (key: string, msg: Msg) => setMsgs((m) => ({ ...m, [key]: msg }));

  async function saveProfile(e: React.FormEvent) {
    e.preventDefault();
    const { error } = await api("/api/v1/me", { method: "PATCH", body: draft });
    say("profile", error ? { kind: "error", text: error.message } : { kind: "success", text: "Profile saved." });
    if (!error) router.refresh();
  }

  async function savePrivacy(field: "acceptsRatings" | "isPublic", value: boolean) {
    setPrivacy((p) => ({ ...p, [field]: value }));
    const { error } = await api("/api/v1/me", { method: "PATCH", body: { [field]: value } });
    if (error) {
      setPrivacy((p) => ({ ...p, [field]: !value }));
      say("privacy", { kind: "error", text: error.message });
    } else {
      say("privacy", { kind: "success", text: "Privacy settings saved." });
    }
  }

  async function changePassword(e: React.FormEvent) {
    e.preventDefault();
    const { error } = await api("/api/v1/me/password", { method: "PATCH", body: pw });
    say("password", error ? { kind: "error", text: error.message } : { kind: "success", text: "Password changed. Other devices were logged out." });
    if (!error) setPw({ currentPassword: "", newPassword: "" });
  }

  async function unblock(username: string) {
    const { error } = await api(`/api/v1/users/${username}/block`, { method: "DELETE" });
    if (error) say("blocks", { kind: "error", text: error.message });
    router.refresh();
  }

  async function logout() {
    await api("/api/v1/auth/logout", { method: "POST" });
    router.push("/");
    router.refresh();
  }

  async function deleteAccount() {
    const { error } = await api("/api/v1/me", { method: "DELETE", body: { password: deletePw } });
    if (error) return say("delete", { kind: "error", text: error.message });
    router.push("/?deleted=1");
    router.refresh();
  }

  return (
    <div className="stack-l">
      <form className="panel stack" onSubmit={saveProfile}>
        <h2>Profile</h2>
        <ProfileFields draft={draft} onChange={setDraft} />
        <Notice msg={msgs.profile} />
        <div><button className="btn" type="submit">Save profile</button></div>
      </form>

      <section className="panel stack">
        <h2>Privacy</h2>
        <PrivacyToggles {...privacy} onChange={savePrivacy} />
        <Notice msg={msgs.privacy} />
      </section>

      <section className="panel stack">
        <h2>Blocked people</h2>
        {me.blocked.length ? (
          <ul className="list">
            {me.blocked.map((b) => (
              <li key={b.username} className="spread" style={{ padding: "10px 0" }}>
                <Link href={`/u/${b.username}`}>{b.displayName} (@{b.username})</Link>
                <button className="btn btn-quiet btn-small" type="button" onClick={() => unblock(b.username)}>Unblock</button>
              </li>
            ))}
          </ul>
        ) : (
          <p className="muted">You haven&apos;t blocked anyone. You can block someone from their profile.</p>
        )}
        <Notice msg={msgs.blocks} />
      </section>

      <form className="panel stack" onSubmit={changePassword}>
        <h2>Password</h2>
        <div className="field">
          <label htmlFor="currentPassword">Current password</label>
          <input id="currentPassword" type="password" autoComplete="current-password" value={pw.currentPassword} onChange={(e) => setPw({ ...pw, currentPassword: e.target.value })} />
        </div>
        <div className="field">
          <label htmlFor="newPassword">New password</label>
          <input id="newPassword" type="password" autoComplete="new-password" value={pw.newPassword} onChange={(e) => setPw({ ...pw, newPassword: e.target.value })} />
          <span className="hint">At least 8 characters.</span>
        </div>
        <Notice msg={msgs.password} />
        <div><button className="btn" type="submit">Change password</button></div>
      </form>

      <section className="panel stack">
        <h2>Account</h2>
        <p className="muted">Signed in as {me.email}. You&apos;ve rated {me.ratingsGiven} {me.ratingsGiven === 1 ? "person" : "people"}.</p>
        <div className="row">
          <button className="btn btn-quiet" type="button" onClick={logout}>Log out</button>
          <button className="btn btn-quiet" type="button" style={{ color: "var(--danger)" }} onClick={() => deleteRef.current?.showModal()}>
            Delete account
          </button>
        </div>
      </section>

      <dialog ref={deleteRef} aria-labelledby="delete-title">
        <div className="stack">
          <h2 id="delete-title">Delete your account?</h2>
          <p className="muted">
            This permanently deletes your profile, your score and every rating you gave. People you rated get their scores
            recalculated. This can&apos;t be undone.
          </p>
          <div className="field">
            <label htmlFor="deletePassword">Enter your password to confirm</label>
            <input id="deletePassword" type="password" autoComplete="current-password" value={deletePw} onChange={(e) => setDeletePw(e.target.value)} />
          </div>
          <Notice msg={msgs.delete} />
          <div className="row" style={{ justifyContent: "flex-end" }}>
            <button className="btn btn-quiet" type="button" onClick={() => deleteRef.current?.close()}>Cancel</button>
            <button className="btn btn-danger" type="button" onClick={deleteAccount}>Delete account</button>
          </div>
        </div>
      </dialog>
    </div>
  );
}
