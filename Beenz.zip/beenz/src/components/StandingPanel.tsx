import Link from "next/link";
import { formatScore } from "@/lib/tiers";
import { TierBadge } from "./TierBadge";

type Standing = { score: number | null; tier: number | null; ratingCount: number; minRatings: number; rank: number | null };

export function StandingPanel({ standing, username }: { standing: Standing | null; username: string }) {
  if (!standing) return null;
  const provisional = standing.tier === null;
  return (
    <section className="panel stack">
      <h2 className="panel-title" style={{ marginBottom: 0 }}>Your standing</h2>
      <TierBadge tier={standing.tier} large />
      {provisional ? (
        <>
          <p className="muted small">
            {standing.ratingCount} of {standing.minRatings} ratings. You get a score and tier after {standing.minRatings} people rate you.
          </p>
          <div className="progress" aria-hidden="true">
            <span style={{ width: `${Math.min(100, (standing.ratingCount / standing.minRatings) * 100)}%` }} />
          </div>
        </>
      ) : (
        <div className="spread">
          <span style={{ font: "750 40px/1 var(--font-display)", letterSpacing: "-0.03em" }}>{formatScore(standing.score)}</span>
          <span className="muted small" style={{ textAlign: "right" }}>
            {standing.ratingCount} ratings
            <br />
            {standing.rank ? `#${standing.rank} on the leaderboard` : "Hidden from the leaderboard"}
          </span>
        </div>
      )}
      <Link href={`/u/${username}`} className="small">View your profile</Link>
    </section>
  );
}
