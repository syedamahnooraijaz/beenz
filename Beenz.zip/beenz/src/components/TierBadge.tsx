import type { CSSProperties } from "react";
import { PROVISIONAL_COLOR, tierInfo } from "@/lib/tiers";
import { Bean } from "./Bean";

export function TierBadge({ tier, large = false }: { tier: number | null; large?: boolean }) {
  const info = tierInfo(tier);
  const color = info?.color ?? PROVISIONAL_COLOR;
  return (
    <span className={`tier-badge${large ? " large" : ""}`} style={{ "--tier-color": color } as CSSProperties}>
      <Bean size={large ? 22 : 18} color={color} shine={false} />
      {info ? (
        <span>
          <b>Tier {info.tier}</b> {info.name}
        </span>
      ) : (
        <b>Provisional</b>
      )}
    </span>
  );
}
