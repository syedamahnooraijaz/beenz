import Link from "next/link";
import { Bean } from "./Bean";

export function Wordmark({ href = "/" }: { href?: string }) {
  return (
    <Link href={href} className="wordmark" aria-label="Beenz home">
      <Bean size={30} color="#3d3bd1" />
      beenz
    </Link>
  );
}
