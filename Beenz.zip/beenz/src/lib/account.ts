// Sign-up, login, profile updates, password change and account deletion.
import crypto from "node:crypto";
import { audit, createSession, getDummyHash, hashPassword, verifyPassword } from "./auth";
import { config } from "./config";
import { query, queryOne, tx } from "./db";
import { ApiError, fail } from "./http";
import { enforceLimit } from "./ratelimit";
import { addFeedEvent, notify, recalculateSubjectsOf } from "./reputation";
import * as v from "./validation";

function uniqueViolation(err: unknown): string | null {
  const e = err as { code?: string; constraint?: string };
  return e?.code === "23505" ? e.constraint ?? "unique" : null;
}

export async function signup(body: Record<string, unknown>, ip: string) {
  const username = v.username(body.username);
  const email = v.email(body.email);
  const password = v.password(body.password);
  const displayName = body.displayName ? v.displayName(body.displayName) : username;

  // Campus networks share one IP between many students, so this limit is generous.
  await enforceLimit(`signup:${ip}`, 30, 3600, "Too many sign-ups from this network. Try again in a while.");

  const passwordHash = await hashPassword(password);
  const role = config.adminEmails.includes(email) ? "admin" : "user";

  try {
    return await tx(async (c) => {
      const user = (
        await c.query<{ id: string }>(
          `INSERT INTO users (username, email, password_hash, display_name, role)
           VALUES ($1, $2, $3, $4, $5) RETURNING id`,
          [username, email, passwordHash, displayName, role],
        )
      ).rows[0];
      await addFeedEvent(c, "joined", user.id);
      await notify(c, user.id, "welcome",
        "Welcome to Beenz. Your ratings of other people are private: only you can see them.", "/onboarding");
      await createSession(user.id, c);
      await audit(user.id, "signup", null, ip, c);
      return { id: user.id, username };
    });
  } catch (err) {
    const constraint = uniqueViolation(err);
    if (constraint?.includes("username")) throw fail.conflict("username_taken", "That username is taken. Try another one.");
    if (constraint?.includes("email")) throw fail.conflict("email_taken", "There's already an account with that email. Log in instead.");
    throw err;
  }
}

export async function login(body: Record<string, unknown>, ip: string) {
  const email = typeof body.email === "string" ? body.email.trim().toLowerCase() : "";
  const password = typeof body.password === "string" ? body.password : "";
  if (!email || !password) throw fail.badRequest("missing_fields", "Enter your email and password.");

  await enforceLimit(`login:ip:${ip}`, 40, 900, "Too many login attempts from this network. Wait 15 minutes.");
  await enforceLimit(`login:email:${email}`, 10, 900, "Too many login attempts for this account. Wait 15 minutes.");

  const user = await queryOne<{ id: string; password_hash: string; status: string; suspension_reason: string | null; role: string }>(
    `SELECT id, password_hash, status, suspension_reason, role FROM users WHERE lower(email) = $1`,
    [email],
  );
  const valid = await verifyPassword(password, user?.password_hash ?? (await getDummyHash()));
  if (!user || !valid) {
    await audit(user?.id ?? null, "login_failed", email, ip);
    throw new ApiError(401, "invalid_credentials", "Email or password is incorrect.");
  }
  if (user.status === "suspended") {
    throw fail.forbidden("suspended",
      `Your account is suspended${user.suspension_reason ? `: ${user.suspension_reason}` : "."} Contact the moderators if you think this is a mistake.`);
  }
  // Emails listed in ADMIN_EMAILS become admins on their next login
  if (config.adminEmails.includes(email) && user.role !== "admin") {
    await query(`UPDATE users SET role = 'admin' WHERE id = $1`, [user.id]);
  }
  await createSession(user.id);
  await audit(user.id, "login", null, ip);
  return { id: user.id };
}

export async function updateMe(userId: string, body: Record<string, unknown>) {
  const sets: string[] = [];
  const params: unknown[] = [userId];
  const add = (column: string, value: unknown) => {
    params.push(value);
    sets.push(`${column} = $${params.length}`);
  };
  if ("displayName" in body) add("display_name", v.displayName(body.displayName));
  if ("bio" in body) add("bio", v.bio(body.bio));
  if ("avatarColor" in body) add("avatar_color", v.avatarColor(body.avatarColor));
  if ("acceptsRatings" in body) add("accepts_ratings", v.bool(body.acceptsRatings, "acceptsRatings"));
  if ("isPublic" in body) add("is_public", v.bool(body.isPublic, "isPublic"));
  if (body.onboarded === true) add("onboarded", true);
  if (!sets.length) throw fail.badRequest("nothing_to_update", "Nothing to update.");
  await query(`UPDATE users SET ${sets.join(", ")}, updated_at = now() WHERE id = $1`, params);
}

export async function changePassword(userId: string, body: Record<string, unknown>, ip: string) {
  const current = typeof body.currentPassword === "string" ? body.currentPassword : "";
  const next = v.password(body.newPassword);
  await enforceLimit(`pwchange:${userId}`, 10, 3600, "Too many attempts. Try again later.");
  const row = await queryOne<{ password_hash: string }>(`SELECT password_hash FROM users WHERE id = $1`, [userId]);
  if (!row || !(await verifyPassword(current, row.password_hash))) {
    throw fail.badRequest("wrong_password", "Your current password is incorrect.", { field: "currentPassword" });
  }
  await tx(async (c) => {
    await c.query(`UPDATE users SET password_hash = $2, updated_at = now() WHERE id = $1`, [userId, await hashPassword(next)]);
    await c.query(`DELETE FROM sessions WHERE user_id = $1`, [userId]); // log out every device
    await createSession(userId, c);
    await audit(userId, "password_change", null, ip, c);
  });
}

/** Deletes the account and everything attached to it. Ratings the person gave stop counting. */
export async function deleteAccount(userId: string, body: Record<string, unknown>, ip: string) {
  const password = typeof body.password === "string" ? body.password : "";
  const row = await queryOne<{ password_hash: string }>(`SELECT password_hash FROM users WHERE id = $1`, [userId]);
  if (!row || !(await verifyPassword(password, row.password_hash))) {
    throw fail.badRequest("wrong_password", "Enter your password to confirm.", { field: "password" });
  }
  const rated = (await query<{ subject_id: string }>(`SELECT subject_id FROM ratings WHERE rater_id = $1`, [userId])).map((r) => r.subject_id);
  await audit(userId, "account_deleted", userId, ip);
  await query(`DELETE FROM users WHERE id = $1`, [userId]); // cascades to ratings, sessions, blocks, notifications...
  await recalculateSubjectsOf(userId, rated);
}

export function temporaryPassword() {
  return crypto.randomBytes(9).toString("base64url");
}
