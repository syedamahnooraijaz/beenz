// Browser helper for calling the Beenz API with consistent error handling.
export type ApiFailure = { code: string; message: string; field?: string; retryAfter?: number };

export async function api<T = unknown>(
  url: string,
  options: { method?: string; body?: unknown } = {},
): Promise<{ data?: T; error?: ApiFailure }> {
  try {
    const res = await fetch(url, {
      method: options.method ?? "GET",
      headers: options.body !== undefined ? { "Content-Type": "application/json" } : undefined,
      body: options.body !== undefined ? JSON.stringify(options.body) : undefined,
    });
    const json = await res.json().catch(() => null);
    if (!res.ok) {
      return { error: json?.error ?? { code: `http_${res.status}`, message: "Something went wrong. Try again." } };
    }
    return { data: json?.data as T };
  } catch {
    return { error: { code: "network", message: "Couldn't reach Beenz. Check your connection and try again." } };
  }
}
