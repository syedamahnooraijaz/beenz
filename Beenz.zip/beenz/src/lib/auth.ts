// Accounts, passwords and sessions.
//
// Passwords: hashed with scrypt (built into Node) + a random salt. Plain-text
// passwords are never stored or logged.
// Sessions: a random 256-bit token lives in an httpOnly cookie; the database
// stores only its SHA-256 hash, so a leaked database can't be used to log in.
import crypto from "node:crypto";
import { promisify } from "node:util";
import { cache } from "react";
import { cookies } from "next/headers";
import { config } from "./config";
import { query, queryOne, type Db } from "./db";
import { fail } from "./http";

const scrypt = promisify(crypto.scrypt) as (pw: string, salt: Buffer, len: number, opts: crypto.ScryptOptions) => Promise<Buffer>;
const COOKIE = "beenz_session";
const SCRYPT = { N: 16384, r: 8, p: 1, maxmem: 64 * 1024 * 1024 };

export async function hashPassword(password: string): Promise<string> {
  const salt = crypto.randomBytes(16);
  const key = await scrypt(password, salt, 64, SCRYPT);
  return `scrypt$${SCRYPT.N}$${SCRYPT.r}$${SCRYPT.p}$${salt.toString("base64")}$${key.toString("base64")}`;
}

export async function verifyPassword(password: string, stored: string): Promise<boolean> {
  const [algo, n, r, p, saltB64, keyB64] = stored.split("$");
  if (algo !== "scrypt") return false;
  const expected = Buffer.from(keyB64, "base64");
  const actual = await scrypt(password, Buffer.from(saltB64, "base64"), expected.length, {
    N: Number(n), r: Number(r), p: Number(p), maxmem: SCRYPT.maxmem,
  });
  return crypto.timingSafeEqual(actual, expected);
}

// Used when the email doesn't exist, so a login takes the same time either way
// (otherwise response time would reveal which emails have accounts).
let dummyHash: Promise<string> | null = null;
export function getDummyHash() {
  dummyHash ??= hashPassword(crypto.randomBytes(16).toString("hex"));
  return dummyHash;
}

function sha256(value: string) {
  return crypto.createHash("sha256").update(value).digest("hex");
}

export async function createSession(userId: string, db?: Db) {
  const token = crypto.randomBytes(32).toString("base64url");
  const expires = new Date(Date.now() + config.sessionDays * 86_400_000);
  await query(`INSERT INTO sessions (token_hash, user_id, expires_at) VALUES ($1, $2, $3)`, [sha256(token), userId, expires], db);
  const store = await cookies();
  store.set(COOKIE, token, {
    httpOnly: true,
    secure: process.env.NODE_ENV === "production",
    sameSite: "lax",
    path: "/",
    expires,
  });
}

export async function destroySession() {
  const store = await cookies();
  const token = store.get(COOKIE)?.value;
  if (token) await query(`DELETE FROM sessions WHERE token_hash = $1`, [sha256(token)]);
  store.delete(COOKIE);
}

export type SessionUser = {
  id: string;
  username: string;
  email: string;
  displayName: string;
  avatarColor: string;
  role: "user" | "moderator" | "admin";
  status: "active" | "suspended";
  onboarded: boolean;
};

type Row = {
  id: string; username: string; email: string; display_name: string; avatar_color: string;
  role: SessionUser["role"]; status: SessionUser["status"]; onboarded: boolean; last_seen_at: Date;
};

/** The logged-in user, or null. Cached for the length of one request. */
export const getCurrentUser = cache(async (): Promise<SessionUser | null> => {
  const store = await cookies();
  const token = store.get(COOKIE)?.value;
  if (!token) return null;
  const hash = sha256(token);
  const row = await queryOne<Row>(
    `SELECT u.id, u.username, u.email, u.display_name, u.avatar_color, u.role, u.status, u.onboarded, s.last_seen_at
       FROM sessions s JOIN users u ON u.id = s.user_id
      WHERE s.token_hash = $1 AND s.expires_at > now()`,
    [hash],
  );
  if (!row) return null;
  // record activity at most every 5 minutes (used for "active users" analytics)
  if (Date.now() - new Date(row.last_seen_at).getTime() > 5 * 60_000) {
    await query(`UPDATE sessions SET last_seen_at = now() WHERE token_hash = $1`, [hash]);
    await query(`UPDATE users SET last_active_at = now() WHERE id = $1`, [row.id]);
  }
  return {
    id: row.id, username: row.username, email: row.email, displayName: row.display_name,
    avatarColor: row.avatar_color, role: row.role, status: row.status, onboarded: row.onboarded,
  };
});

/** For API routes: the logged-in, non-suspended user, or a 401/403 error. */
export async function requireUser(): Promise<SessionUser> {
  const user = await getCurrentUser();
  if (!user) throw fail.unauthorized();
  if (user.status === "suspended") throw fail.forbidden("suspended", "Your account is suspended.");
  return user;
}

export async function requireModerator(): Promise<SessionUser> {
  const user = await requireUser();
  if (user.role !== "moderator" && user.role !== "admin") {
    throw fail.forbidden("forbidden", "Only moderators can do that.");
  }
  return user;
}

export async function requireAdmin(): Promise<SessionUser> {
  const user = await requireUser();
  if (user.role !== "admin") throw fail.forbidden("forbidden", "Only admins can do that.");
  return user;
}

export function isModerator(user: SessionUser | null) {
  return !!user && (user.role === "moderator" || user.role === "admin");
}

export async function audit(actorId: string | null, action: string, target: string | null, ip: string | null = null, db?: Db) {
  await query(`INSERT INTO audit_logs (actor_id, action, target, ip) VALUES ($1, $2, $3, $4)`, [actorId, action, target, ip], db);
}
