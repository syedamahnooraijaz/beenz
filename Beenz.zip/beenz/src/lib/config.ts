// Settings read from environment variables (see .env.example).

function int(name: string, fallback: number, min: number): number {
  const value = Number.parseInt(process.env[name] ?? "", 10);
  return Number.isFinite(value) && value >= min ? value : fallback;
}

function list(name: string): string[] {
  return (process.env[name] ?? "")
    .split(",")
    .map((s) => s.trim().toLowerCase())
    .filter(Boolean);
}

export const config = {
  /** ratings needed before a tier is shown */
  get minRatingsForTier() {
    return int("MIN_RATINGS_FOR_TIER", 3, 1);
  },
  /** minutes a person must wait before changing their rating of the same person again */
  get ratingCooldownMinutes() {
    return int("RATING_CHANGE_COOLDOWN_MINUTES", 10, 0);
  },
  /** rating creates/changes/removals one person may make per hour */
  get maxRatingActionsPerHour() {
    return int("MAX_RATING_ACTIONS_PER_HOUR", 60, 1);
  },
  get adminEmails() {
    return list("ADMIN_EMAILS");
  },
  get allowedEmailDomains() {
    return list("ALLOWED_EMAIL_DOMAINS").map((d) => d.replace(/^@/, ""));
  },
  sessionDays: 30,
};
