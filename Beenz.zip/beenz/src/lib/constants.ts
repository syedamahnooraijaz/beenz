// Values shared by the server and the browser.
export const AVATAR_COLORS = ["#3D3BD1", "#1F9D6B", "#C2416B", "#C27C0E", "#7A4FD6", "#2F6FE4", "#0E8A9A", "#5B5F73"];

export const REPORT_REASONS = {
  harassment: "Harassment or bullying",
  rating_abuse: "Rating abuse (brigading, revenge ratings)",
  fake_account: "Fake or duplicate account",
  inappropriate_profile: "Inappropriate name, bio or avatar",
  spam: "Spam",
  other: "Something else",
} as const;
