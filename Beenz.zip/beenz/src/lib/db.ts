// PostgreSQL connection pool + small helpers.
import { Pool, type PoolClient, type QueryResultRow } from "pg";

declare global {
  // Re-use one pool across hot reloads in development
  // eslint-disable-next-line no-var
  var __beenzPool: Pool | undefined;
}

export function pool(): Pool {
  if (!globalThis.__beenzPool) {
    const url = process.env.DATABASE_URL;
    if (!url) throw new Error("DATABASE_URL is not set. Copy .env.example to .env.local.");
    // SSL is taken from the connection string (Neon/Supabase URLs include sslmode=require)
    globalThis.__beenzPool = new Pool({ connectionString: url, max: 5, idleTimeoutMillis: 10_000 });
  }
  return globalThis.__beenzPool;
}

export type Db = Pick<PoolClient, "query">;

export async function query<T extends QueryResultRow>(text: string, params: unknown[] = [], db: Db = pool()) {
  const result = await db.query<T>(text, params);
  return result.rows;
}

export async function queryOne<T extends QueryResultRow>(text: string, params: unknown[] = [], db: Db = pool()) {
  const rows = await query<T>(text, params, db);
  return rows[0] ?? null;
}

/** Run `fn` inside a transaction: everything is saved together or not at all. */
export async function tx<T>(fn: (client: PoolClient) => Promise<T>): Promise<T> {
  const client = await pool().connect();
  try {
    await client.query("BEGIN");
    const result = await fn(client);
    await client.query("COMMIT");
    return result;
  } catch (err) {
    await client.query("ROLLBACK");
    throw err;
  } finally {
    client.release();
  }
}

/** pg returns NUMERIC columns as strings; convert to number (or null). */
export function num(value: unknown): number | null {
  return value === null || value === undefined ? null : Number(value);
}
