// Consistent API responses, errors and request helpers.
import { NextResponse, type NextRequest } from "next/server";

export class ApiError extends Error {
  constructor(
    public status: number,
    public code: string,
    message: string,
    public details: Record<string, unknown> = {},
  ) {
    super(message);
  }
}

export const fail = {
  badRequest: (code: string, message: string, details?: Record<string, unknown>) =>
    new ApiError(400, code, message, details),
  unauthorized: () => new ApiError(401, "unauthorized", "Log in to do that."),
  forbidden: (code: string, message: string) => new ApiError(403, code, message),
  notFound: (message = "Not found.") => new ApiError(404, "not_found", message),
  conflict: (code: string, message: string) => new ApiError(409, code, message),
  tooMany: (code: string, message: string, retryAfter: number) =>
    new ApiError(429, code, message, { retryAfter }),
};

/** Success:  { "data": ... } */
export function ok(data: unknown, status = 200) {
  return NextResponse.json({ data }, { status });
}

type Ctx = { params: Promise<Record<string, string>> };
type Handler = (req: NextRequest, ctx: Ctx) => Promise<Response>;

const MUTATING = new Set(["POST", "PUT", "PATCH", "DELETE"]);

/**
 * Wraps every API route:
 *  - blocks cross-site form posts (CSRF) by checking the Origin header
 *  - turns ApiError into   { "error": { code, message, ...details } }
 *  - hides unexpected errors behind a generic 500
 */
export function route(handler: Handler): Handler {
  return async (req, ctx) => {
    try {
      if (MUTATING.has(req.method)) checkOrigin(req);
      return await handler(req, ctx);
    } catch (err) {
      if (err instanceof ApiError) {
        const headers: Record<string, string> = {};
        if (typeof err.details.retryAfter === "number") headers["Retry-After"] = String(err.details.retryAfter);
        return NextResponse.json(
          { error: { code: err.code, message: err.message, ...err.details } },
          { status: err.status, headers },
        );
      }
      console.error("[api error]", err);
      return NextResponse.json(
        { error: { code: "server_error", message: "Something went wrong on our side. Try again." } },
        { status: 500 },
      );
    }
  };
}

function checkOrigin(req: NextRequest) {
  const origin = req.headers.get("origin");
  if (!origin) return; // non-browser clients (curl, tests) send no Origin
  const host = req.headers.get("x-forwarded-host") ?? req.headers.get("host");
  let originHost = "";
  try {
    originHost = new URL(origin).host;
  } catch {
    /* invalid origin */
  }
  if (!host || originHost !== host) {
    throw fail.forbidden("bad_origin", "This request came from another site and was blocked.");
  }
}

export async function readJson(req: NextRequest): Promise<Record<string, unknown>> {
  let body: unknown;
  try {
    body = await req.json();
  } catch {
    throw fail.badRequest("invalid_json", "The request body must be JSON.");
  }
  if (typeof body !== "object" || body === null || Array.isArray(body)) {
    throw fail.badRequest("invalid_json", "The request body must be a JSON object.");
  }
  return body as Record<string, unknown>;
}

export function clientIp(req: NextRequest): string {
  return (
    req.headers.get("x-forwarded-for")?.split(",")[0]?.trim() ||
    req.headers.get("x-real-ip") ||
    "unknown"
  );
}
