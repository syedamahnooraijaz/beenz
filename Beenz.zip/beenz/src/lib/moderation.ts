// Reports, blocking and moderator tools. Every moderator action is recorded
// in moderation_actions and audit_logs so it can be reviewed later.
import { temporaryPassword } from "./account";
import { audit, hashPassword, type SessionUser } from "./auth";
import { query, queryOne, tx } from "./db";
import { fail } from "./http";
import { enforceLimit } from "./ratelimit";
import { addFeedEvent, notify, publicReputation, recalculate, recalculateSubjectsOf } from "./reputation";
import * as v from "./validation";

// ---------------------------------------------------------------------------
// Blocking
// ---------------------------------------------------------------------------
export async function block(me: SessionUser, targetId: string) {
  if (me.id === targetId) throw fail.badRequest("self_block", "You can't block yourself.");
  await query(`INSERT INTO blocks (blocker_id, blocked_id) VALUES ($1, $2) ON CONFLICT DO NOTHING`, [me.id, targetId]);
}

export async function unblock(me: SessionUser, targetId: string) {
  await query(`DELETE FROM blocks WHERE blocker_id = $1 AND blocked_id = $2`, [me.id, targetId]);
}

// ---------------------------------------------------------------------------
// Reports
// ---------------------------------------------------------------------------
export async function createReport(me: SessionUser, body: Record<string, unknown>) {
  const username = typeof body.username === "string" ? body.username : "";
  const reason = v.reportReason(body.reason);
  const details = v.longText(body.details, 1000, "Details");
  const subject = await queryOne<{ id: string }>(`SELECT id FROM users WHERE lower(username) = lower($1)`, [username]);
  if (!subject) throw fail.notFound("That person doesn't exist.");
  if (subject.id === me.id) throw fail.badRequest("self_report", "You can't report yourself.");
  await enforceLimit(`report:${me.id}`, 10, 3600, "You've sent a lot of reports. Try again later.");

  try {
    const report = await tx(async (c) => {
      const r = (
        await c.query<{ id: string }>(
          `INSERT INTO reports (reporter_id, subject_id, reason, details) VALUES ($1, $2, $3, $4) RETURNING id`,
          [me.id, subject.id, reason, details],
        )
      ).rows[0];
      const mods = (await c.query<{ id: string }>(`SELECT id FROM users WHERE role IN ('moderator','admin') AND status = 'active'`)).rows;
      for (const m of mods) {
        await notify(c, m.id, "report", `New report: ${v.REPORT_REASONS[reason].toLowerCase()} about @${username.toLowerCase()}.`, "/admin");
      }
      return r;
    });
    return { id: String(report.id) };
  } catch (err) {
    if ((err as { code?: string }).code === "23505") {
      throw fail.conflict("already_reported", "You've already reported this person. A moderator will review it.");
    }
    throw err;
  }
}

export async function listReports(status: string) {
  const s = ["open", "resolved", "dismissed"].includes(status) ? status : "open";
  const rows = await query<{
    id: string; reason: v.ReportReason; details: string; status: string; resolution_note: string | null;
    created_at: Date; resolved_at: Date | null;
    reporter_username: string | null; subject_id: string; subject_username: string; subject_display_name: string;
    subject_status: string; subject_avatar_color: string; open_reports_on_subject: number; resolver_username: string | null;
  }>(
    `SELECT r.id, r.reason, r.details, r.status, r.resolution_note, r.created_at, r.resolved_at,
            rep.username AS reporter_username,
            s.id AS subject_id, s.username AS subject_username, s.display_name AS subject_display_name,
            s.status AS subject_status, s.avatar_color AS subject_avatar_color,
            (SELECT count(*)::int FROM reports x WHERE x.subject_id = s.id AND x.status = 'open') AS open_reports_on_subject,
            res.username AS resolver_username
       FROM reports r
       JOIN users s ON s.id = r.subject_id
       LEFT JOIN users rep ON rep.id = r.reporter_id
       LEFT JOIN users res ON res.id = r.resolved_by
      WHERE r.status = $1
      ORDER BY r.created_at ${s === "open" ? "ASC" : "DESC"}
      LIMIT 100`,
    [s],
  );
  return rows.map((r) => ({
    id: String(r.id),
    reason: r.reason,
    reasonLabel: v.REPORT_REASONS[r.reason],
    details: r.details,
    status: r.status,
    resolutionNote: r.resolution_note,
    createdAt: r.created_at.toISOString(),
    resolvedAt: r.resolved_at?.toISOString() ?? null,
    reporter: r.reporter_username,
    resolvedBy: r.resolver_username,
    subject: {
      id: r.subject_id, username: r.subject_username, displayName: r.subject_display_name,
      status: r.subject_status, avatarColor: r.subject_avatar_color, openReports: r.open_reports_on_subject,
    },
  }));
}

export async function closeReport(mod: SessionUser, reportId: string, body: Record<string, unknown>) {
  const status = body.status === "resolved" || body.status === "dismissed" ? body.status : null;
  if (!status) throw fail.badRequest("invalid_status", "Status must be 'resolved' or 'dismissed'.");
  const note = v.longText(body.note, 500, "Note");
  await tx(async (c) => {
    const r = (
      await c.query<{ subject_id: string; reporter_id: string | null; status: string }>(
        `SELECT subject_id, reporter_id, status FROM reports WHERE id = $1 FOR UPDATE`, [reportId],
      )
    ).rows[0];
    if (!r) throw fail.notFound("Report not found.");
    if (r.status !== "open") throw fail.conflict("already_closed", "This report was already handled.");
    await c.query(
      `UPDATE reports SET status = $2, resolution_note = $3, resolved_by = $4, resolved_at = now() WHERE id = $1`,
      [reportId, status, note, mod.id],
    );
    await c.query(
      `INSERT INTO moderation_actions (moderator_id, target_user_id, report_id, action, note) VALUES ($1, $2, $3, $4, $5)`,
      [mod.id, r.subject_id, reportId, status === "resolved" ? "resolve_report" : "dismiss_report", note],
    );
    if (r.reporter_id) {
      await notify(c, r.reporter_id, "report_update",
        status === "resolved" ? "A moderator reviewed your report and took action." : "A moderator reviewed your report. No action was needed.");
    }
    await audit(mod.id, `report_${status}`, `report:${reportId}`, null, c);
  });
}

// ---------------------------------------------------------------------------
// User management
// ---------------------------------------------------------------------------
export async function adminSearchUsers(viewer: SessionUser, q: string) {
  const term = q.trim().toLowerCase().slice(0, 60);
  const pattern = "%" + term.replace(/[\\%_]/g, (ch) => "\\" + ch) + "%";
  const rows = await query<{
    id: string; username: string; display_name: string; avatar_color: string; email: string; role: string; status: string;
    suspension_reason: string | null; score: string | null; tier: number | null; rating_count: number; created_at: Date;
    given: number; open_reports: number;
  }>(
    `SELECT u.id, u.username, u.display_name, u.avatar_color, u.email, u.role, u.status, u.suspension_reason,
            u.score, u.tier, u.rating_count, u.created_at,
            (SELECT count(*)::int FROM ratings WHERE rater_id = u.id) AS given,
            (SELECT count(*)::int FROM reports WHERE subject_id = u.id AND status = 'open') AS open_reports
       FROM users u
      WHERE $1 = '' OR lower(u.username) LIKE $2 OR lower(u.display_name) LIKE $2 OR lower(u.email) LIKE $2
      ORDER BY open_reports DESC, u.created_at DESC
      LIMIT 50`,
    [term, pattern],
  );
  const showEmail = viewer.role === "admin";
  return rows.map((r) => ({
    id: r.id, username: r.username, displayName: r.display_name, avatarColor: r.avatar_color,
    email: showEmail ? r.email : null, role: r.role, status: r.status, suspensionReason: r.suspension_reason,
    reputation: publicReputation(r), joinedAt: r.created_at.toISOString(), ratingsGiven: r.given, openReports: r.open_reports,
  }));
}

/** Ratings a user GAVE (to spot brigading). Viewing this is logged. */
export async function ratingsGivenBy(mod: SessionUser, userId: string) {
  await audit(mod.id, "view_ratings_given", `user:${userId}`);
  const rows = await query<{ username: string; value: number; updated_at: Date }>(
    `SELECT s.username, r.value, r.updated_at FROM ratings r JOIN users s ON s.id = r.subject_id
      WHERE r.rater_id = $1 ORDER BY r.updated_at DESC LIMIT 200`,
    [userId],
  );
  return rows.map((r) => ({ username: r.username, value: r.value, at: r.updated_at.toISOString() }));
}

type Target = { id: string; username: string; role: string; status: string };

export async function moderateUser(mod: SessionUser, targetId: string, body: Record<string, unknown>) {
  const action = String(body.action ?? "");
  const target = await queryOne<Target>(`SELECT id, username, role, status FROM users WHERE id = $1`, [targetId]);
  if (!target) throw fail.notFound("User not found.");
  if (target.id === mod.id) throw fail.badRequest("self_action", "You can't use moderator tools on your own account.");
  if (target.role === "admin" && mod.role !== "admin") throw fail.forbidden("forbidden", "Only admins can act on admin accounts.");

  const reason = v.longText(body.reason, 300, "Reason");
  const log = async (name: string, note = reason) => {
    await query(`INSERT INTO moderation_actions (moderator_id, target_user_id, action, note) VALUES ($1, $2, $3, $4)`, [mod.id, target.id, name, note]);
    await audit(mod.id, name, `user:${target.id}`);
  };

  switch (action) {
    case "suspend": {
      if (!reason) throw fail.badRequest("reason_required", "Give a reason for the suspension. The person will see it.");
      await query(`UPDATE users SET status = 'suspended', suspension_reason = $2 WHERE id = $1`, [target.id, reason]);
      await query(`DELETE FROM sessions WHERE user_id = $1`, [target.id]);
      await log("suspend");
      const affected = await recalculateSubjectsOf(target.id); // their ratings stop counting
      return { message: `@${target.username} is suspended. ${affected} people's scores were recalculated.` };
    }
    case "unsuspend": {
      await query(`UPDATE users SET status = 'active', suspension_reason = NULL WHERE id = $1`, [target.id]);
      await log("unsuspend");
      const affected = await recalculateSubjectsOf(target.id);
      return { message: `@${target.username} is active again. ${affected} people's scores were recalculated.` };
    }
    case "remove_ratings": {
      const removed = await query<{ subject_id: string; value: number }>(
        `DELETE FROM ratings WHERE rater_id = $1 RETURNING subject_id, value`, [target.id],
      );
      for (const r of removed) {
        await query(
          `INSERT INTO rating_audit_history (rater_id, subject_id, action, old_value) VALUES ($1, $2, 'moderator_remove', $3)`,
          [target.id, r.subject_id, r.value],
        );
      }
      await log("remove_ratings", `${removed.length} ratings removed. ${reason}`);
      for (const r of removed) await tx((c) => recalculate(c, r.subject_id));
      return { message: `Removed ${removed.length} ratings given by @${target.username}.` };
    }
    case "clear_profile": {
      await query(`UPDATE users SET display_name = username, bio = '' WHERE id = $1`, [target.id]);
      await log("clear_profile");
      return { message: `Cleared the name and bio of @${target.username}.` };
    }
    case "reset_password": {
      if (mod.role !== "admin") throw fail.forbidden("forbidden", "Only admins can reset passwords.");
      const temp = temporaryPassword();
      await query(`UPDATE users SET password_hash = $2 WHERE id = $1`, [target.id, await hashPassword(temp)]);
      await query(`DELETE FROM sessions WHERE user_id = $1`, [target.id]);
      await log("reset_password", "");
      return { message: `Temporary password for @${target.username}: ${temp}  (shown once; ask them to change it in Settings)` };
    }
    case "set_role": {
      if (mod.role !== "admin") throw fail.forbidden("forbidden", "Only admins can change roles.");
      const role = body.role;
      if (role !== "user" && role !== "moderator" && role !== "admin") throw fail.badRequest("invalid_role", "Unknown role.");
      await query(`UPDATE users SET role = $2 WHERE id = $1`, [target.id, role]);
      await log("set_role", `role=${role}`);
      return { message: `@${target.username} is now ${role === "user" ? "a regular user" : `a ${role}`}.` };
    }
    default:
      throw fail.badRequest("invalid_action", "Unknown moderation action.");
  }
}

export async function announce(mod: SessionUser, body: Record<string, unknown>) {
  const text = v.longText(body.text, 500, "Announcement");
  if (!text) throw fail.badRequest("empty", "Write the announcement first.");
  await tx(async (c) => {
    await addFeedEvent(c, "announcement", mod.id, { text, by: mod.displayName });
    await c.query(`INSERT INTO moderation_actions (moderator_id, action, note) VALUES ($1, 'announce', $2)`, [mod.id, text]);
  });
}

export async function stats() {
  const row = await queryOne<Record<string, number>>(
    `SELECT
       (SELECT count(*)::int FROM users) AS users,
       (SELECT count(*)::int FROM users WHERE created_at > now() - interval '7 days') AS new_users_7d,
       (SELECT count(*)::int FROM users WHERE last_active_at > now() - interval '1 day') AS active_1d,
       (SELECT count(*)::int FROM users WHERE last_active_at > now() - interval '30 days') AS active_30d,
       (SELECT count(*)::int FROM users WHERE rating_count > 0) AS users_rated,
       (SELECT count(*)::int FROM users WHERE tier IS NOT NULL) AS ranked,
       (SELECT count(*)::int FROM ratings) AS ratings,
       (SELECT count(*)::int FROM rating_audit_history WHERE created_at > now() - interval '7 days') AS rating_actions_7d,
       (SELECT count(*)::int FROM reports WHERE status = 'open') AS open_reports,
       (SELECT count(*)::int FROM users WHERE status = 'suspended') AS suspended`,
  );
  const tiers = await query<{ tier: number; n: number }>(
    `SELECT tier, count(*)::int AS n FROM users WHERE tier IS NOT NULL AND status = 'active' GROUP BY tier ORDER BY tier`,
  );
  return { ...row, tiers: Object.fromEntries(tiers.map((t) => [t.tier, t.n])) };
}

