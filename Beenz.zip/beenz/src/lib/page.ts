// Helpers for server-rendered pages.
import { redirect } from "next/navigation";
import { getCurrentUser, isModerator } from "./auth";

/** The logged-in user, or a redirect to the login page. */
export async function requirePageUser(next = "/feed") {
  const user = await getCurrentUser();
  if (!user) redirect(`/login?next=${encodeURIComponent(next)}`);
  if (user.status === "suspended") redirect("/login?suspended=1");
  return user;
}

export async function requirePageModerator() {
  const user = await requirePageUser("/admin");
  if (!isModerator(user)) redirect("/feed");
  return user;
}
