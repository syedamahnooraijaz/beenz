// Fixed-window rate limiting stored in Postgres, so it works across
// serverless instances (in-memory counters would reset on every instance).
import { queryOne } from "./db";
import { fail } from "./http";

export async function hit(key: string, limit: number, windowSeconds: number) {
  const row = await queryOne<{ count: number; retry_after: number }>(
    `INSERT INTO rate_limits (key, window_start, count) VALUES ($1, now(), 1)
     ON CONFLICT (key) DO UPDATE SET
       count = CASE WHEN rate_limits.window_start < now() - make_interval(secs => $2)
                    THEN 1 ELSE rate_limits.count + 1 END,
       window_start = CASE WHEN rate_limits.window_start < now() - make_interval(secs => $2)
                    THEN now() ELSE rate_limits.window_start END
     RETURNING count,
       GREATEST(1, CEIL(EXTRACT(EPOCH FROM (window_start + make_interval(secs => $2) - now()))))::int AS retry_after`,
    [key, windowSeconds],
  );
  // occasionally clear out old windows
  if (Math.random() < 0.01) {
    await queryOne(`DELETE FROM rate_limits WHERE window_start < now() - interval '1 day'`);
  }
  return { allowed: (row?.count ?? 0) <= limit, retryAfter: row?.retry_after ?? windowSeconds };
}

export async function enforceLimit(key: string, limit: number, windowSeconds: number, message: string) {
  const result = await hit(key, limit, windowSeconds);
  if (!result.allowed) throw fail.tooMany("rate_limited", message, result.retryAfter);
}
