// ============================================================================
// The reputation engine (server only).
//
// 1. A rating is saved in `ratings` (the source of truth) inside a transaction.
// 2. recalculate() re-derives the subject's score, tier and count from ALL
//    eligible ratings (ratings from active, non-suspended accounts).
// 3. If the result changed, it saves a snapshot (for the history chart) and
//    sends notifications / feed events for tier changes and milestones.
//
// The subject's user row is locked (SELECT ... FOR UPDATE) for the whole
// transaction, so two ratings arriving at the same moment are applied one
// after the other and the score can't be corrupted.
// ============================================================================
import type { PoolClient } from "pg";
import { config } from "./config";
import { num, queryOne, tx, query, type Db } from "./db";
import { fail } from "./http";
import { ALGORITHM_VERSION, MILESTONES, scoreFrom, tierForScore, tierInfo } from "./tiers";

export type Reputation = {
  score: number | null; // hidden (null) while provisional
  tier: number | null; // null = provisional
  ratingCount: number;
  minRatings: number;
};

export type RatingResult = { myRating: number | null; reputation: Reputation };

/** What the outside world may see: no score until the user is ranked. */
export function publicReputation(row: { score: unknown; tier: unknown; rating_count: number }): Reputation {
  const tier = row.tier === null ? null : Number(row.tier);
  return {
    score: tier === null ? null : num(row.score),
    tier,
    ratingCount: row.rating_count,
    minRatings: config.minRatingsForTier,
  };
}

// ---------------------------------------------------------------------------
// Notifications and feed
// ---------------------------------------------------------------------------
export async function notify(
  db: Db,
  userId: string,
  type: string,
  message: string,
  link: string | null = null,
  dedupeKey: string | null = null,
): Promise<boolean> {
  const result = await db.query(
    `INSERT INTO notifications (user_id, type, message, link, dedupe_key)
     VALUES ($1, $2, $3, $4, $5)
     ON CONFLICT (user_id, dedupe_key) WHERE dedupe_key IS NOT NULL DO NOTHING`,
    [userId, type, message, link, dedupeKey],
  );
  return (result.rowCount ?? 0) > 0;
}

export async function addFeedEvent(db: Db, type: string, userId: string | null, data: Record<string, unknown> = {}) {
  await db.query(`INSERT INTO feed_events (type, user_id, data) VALUES ($1, $2, $3)`, [type, userId, JSON.stringify(data)]);
}

// ---------------------------------------------------------------------------
// Recalculation
// ---------------------------------------------------------------------------
type SubjectRow = {
  id: string; username: string; score: string | null; tier: number | null;
  rating_count: number; is_public: boolean; status: string;
};

export async function recalculate(c: PoolClient, subjectId: string): Promise<Reputation> {
  const subject = (
    await c.query<SubjectRow>(
      `SELECT id, username, score, tier, rating_count, is_public, status FROM users WHERE id = $1 FOR UPDATE`,
      [subjectId],
    )
  ).rows[0];
  if (!subject) throw fail.notFound("That person doesn't exist.");

  const agg = (
    await c.query<{ n: number; total: number }>(
      `SELECT count(*)::int AS n, COALESCE(sum(r.value), 0)::int AS total
         FROM ratings r JOIN users rater ON rater.id = r.rater_id
        WHERE r.subject_id = $1 AND rater.status = 'active'`,
      [subjectId],
    )
  ).rows[0];

  const minRatings = config.minRatingsForTier;
  const score = scoreFrom(agg.total, agg.n);
  const tier = tierForScore(score, agg.n, minRatings);
  const oldScore = num(subject.score);
  const oldTier = subject.tier;
  const oldCount = subject.rating_count;

  if (score !== oldScore || tier !== oldTier || agg.n !== oldCount) {
    await c.query(
      `UPDATE users SET score = $2, tier = $3, rating_count = $4, updated_at = now() WHERE id = $1`,
      [subjectId, score, tier, agg.n],
    );
    await c.query(
      `INSERT INTO reputation_snapshots (user_id, score, tier, rating_count, algorithm_version) VALUES ($1, $2, $3, $4, $5)`,
      [subjectId, score, tier, agg.n, ALGORITHM_VERSION],
    );
    await announceChanges(c, subject, { oldTier, tier, oldCount, count: agg.n });
  }
  return publicReputation({ score, tier, rating_count: agg.n });
}

async function announceChanges(
  c: PoolClient,
  subject: SubjectRow,
  ch: { oldTier: number | null; tier: number | null; oldCount: number; count: number },
) {
  const link = `/u/${subject.username}`;
  const publicFeed = subject.is_public && subject.status === "active";
  const info = tierInfo(ch.tier);

  // Tier changes: always a private notification. Only moves UP go to the public feed.
  if (ch.tier !== ch.oldTier) {
    if (ch.oldTier === null && info) {
      await notify(c, subject.id, "ranked", `You're ranked now: Tier ${info.tier}, ${info.name}.`, link);
      if (publicFeed) await addFeedEvent(c, "ranked", subject.id);
    } else if (ch.tier === null) {
      await notify(c, subject.id, "provisional",
        `You're provisional again. You need ${config.minRatingsForTier} ratings to be ranked.`, link);
    } else if (info && ch.oldTier !== null && ch.tier > ch.oldTier) {
      await notify(c, subject.id, "tier_up", `You moved up to Tier ${info.tier}, ${info.name}.`, link);
      if (publicFeed) await addFeedEvent(c, "tier_up", subject.id, { tier: info.tier });
    } else if (info) {
      await notify(c, subject.id, "tier_down", `Your tier changed to Tier ${info.tier}, ${info.name}.`, link);
    }
  }

  // Milestones: sent once each (dedupe key), never for individual votes.
  for (const m of MILESTONES) {
    if (ch.oldCount < m && ch.count >= m) {
      const message = m === 1 ? "You received your first rating." : `${m} people have rated you.`;
      const isNew = await notify(c, subject.id, "milestone", message, link, `milestone_${m}`);
      if (isNew && publicFeed && m >= 10) await addFeedEvent(c, "milestone", subject.id, { count: m });
    }
  }
}

// ---------------------------------------------------------------------------
// Rating actions
// ---------------------------------------------------------------------------
type Party = { id: string; status: string; accepts_ratings: boolean };

async function loadParties(c: PoolClient, raterId: string, subjectId: string) {
  // Lock the subject first: all rating changes for one person run one at a time.
  const subject = (
    await c.query<Party>(`SELECT id, status, accepts_ratings FROM users WHERE id = $1 FOR UPDATE`, [subjectId])
  ).rows[0];
  const rater = (await c.query<Party>(`SELECT id, status, accepts_ratings FROM users WHERE id = $1`, [raterId])).rows[0];
  if (!subject || subject.status !== "active") throw fail.notFound("That person doesn't exist.");
  if (!rater || rater.status !== "active") throw fail.forbidden("suspended", "Your account can't rate people right now.");
  return { subject, rater };
}

async function isBlockedEitherWay(c: Db, a: string, b: string) {
  const row = await queryOne(
    `SELECT 1 FROM blocks WHERE (blocker_id = $1 AND blocked_id = $2) OR (blocker_id = $2 AND blocked_id = $1)`,
    [a, b], c,
  );
  return !!row;
}

async function checkLimits(c: PoolClient, raterId: string, subjectId: string, hasExistingActivity: boolean) {
  // 1) cooldown before changing the rating of the same person again
  const cooldown = config.ratingCooldownMinutes;
  if (hasExistingActivity && cooldown > 0) {
    const last = await queryOne<{ wait: number }>(
      `SELECT CEIL(EXTRACT(EPOCH FROM (max(created_at) + make_interval(mins => $3) - now())))::int AS wait
         FROM rating_audit_history WHERE rater_id = $1 AND subject_id = $2`,
      [raterId, subjectId, cooldown], c,
    );
    if (last?.wait && last.wait > 0) {
      const minutes = Math.ceil(last.wait / 60);
      throw fail.tooMany("cooldown", `You changed this rating recently. You can change it again in ${minutes} min.`, last.wait);
    }
  }
  // 2) overall cap per hour (stops scripts and mass-voting)
  const recent = await queryOne<{ n: number }>(
    `SELECT count(*)::int AS n FROM rating_audit_history WHERE rater_id = $1 AND created_at > now() - interval '1 hour'`,
    [raterId], c,
  );
  if ((recent?.n ?? 0) >= config.maxRatingActionsPerHour) {
    throw fail.tooMany("rate_limited", "You've made a lot of ratings in the last hour. Take a break and try again later.", 3600);
  }
}

/** Create or replace the rater's rating of the subject (PUT .../ratings/me). */
export async function setRating(raterId: string, subjectId: string, value: number): Promise<RatingResult> {
  if (raterId === subjectId) throw fail.badRequest("self_rating", "You can't rate yourself.");

  return tx(async (c) => {
    const { subject } = await loadParties(c, raterId, subjectId);
    if (!subject.accepts_ratings) throw fail.forbidden("ratings_closed", "This person isn't accepting ratings right now.");
    if (await isBlockedEitherWay(c, raterId, subjectId)) throw fail.forbidden("blocked", "You can't rate this person.");

    const existing = (
      await c.query<{ value: number }>(`SELECT value FROM ratings WHERE rater_id = $1 AND subject_id = $2`, [raterId, subjectId])
    ).rows[0];

    // Same value again (double click, retried request) -> nothing changes. No duplicate vote.
    if (existing && existing.value === value) {
      const row = (await c.query(`SELECT score, tier, rating_count FROM users WHERE id = $1`, [subjectId])).rows[0];
      return { myRating: value, reputation: publicReputation(row) };
    }

    const pairHistory = await queryOne(`SELECT 1 FROM rating_audit_history WHERE rater_id = $1 AND subject_id = $2 LIMIT 1`, [raterId, subjectId], c);
    await checkLimits(c, raterId, subjectId, !!pairHistory);

    await c.query(
      `INSERT INTO ratings (rater_id, subject_id, value) VALUES ($1, $2, $3)
       ON CONFLICT (rater_id, subject_id) DO UPDATE SET value = EXCLUDED.value, updated_at = now()`,
      [raterId, subjectId, value],
    );
    await c.query(
      `INSERT INTO rating_audit_history (rater_id, subject_id, action, old_value, new_value) VALUES ($1, $2, $3, $4, $5)`,
      [raterId, subjectId, existing ? "update" : "create", existing?.value ?? null, value],
    );
    const reputation = await recalculate(c, subjectId);
    return { myRating: value, reputation };
  });
}

/** Remove the rater's rating of the subject (DELETE .../ratings/me). */
export async function removeRating(raterId: string, subjectId: string): Promise<RatingResult> {
  return tx(async (c) => {
    await loadParties(c, raterId, subjectId);
    const existing = (
      await c.query<{ value: number }>(`SELECT value FROM ratings WHERE rater_id = $1 AND subject_id = $2`, [raterId, subjectId])
    ).rows[0];
    if (!existing) {
      const row = (await c.query(`SELECT score, tier, rating_count FROM users WHERE id = $1`, [subjectId])).rows[0];
      return { myRating: null, reputation: publicReputation(row) };
    }
    await checkLimits(c, raterId, subjectId, true);
    await c.query(`DELETE FROM ratings WHERE rater_id = $1 AND subject_id = $2`, [raterId, subjectId]);
    await c.query(
      `INSERT INTO rating_audit_history (rater_id, subject_id, action, old_value) VALUES ($1, $2, 'delete', $3)`,
      [raterId, subjectId, existing.value],
    );
    const reputation = await recalculate(c, subjectId);
    return { myRating: null, reputation };
  });
}

/**
 * Re-derive the reputation of everyone `raterId` has rated. Used when that
 * account is suspended, unsuspended or deleted (its ratings stop/start counting).
 */
export async function recalculateSubjectsOf(raterId: string, subjectIds?: string[]) {
  const ids =
    subjectIds ??
    (await query<{ subject_id: string }>(`SELECT subject_id FROM ratings WHERE rater_id = $1`, [raterId])).map((r) => r.subject_id);
  for (const id of ids) {
    await tx((c) => recalculate(c, id)).catch((err) => {
      if (!(err && err.code === "not_found")) throw err;
    });
  }
  return ids.length;
}
