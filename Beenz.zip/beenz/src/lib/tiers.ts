// ============================================================================
// Reputation rules: pure functions with no database access.
// Shared by the server (to calculate) and the browser (to display).
// ============================================================================

export const ALGORITHM_VERSION = "simple-average-v1";

export type TierInfo = {
  tier: number;
  name: string;
  /** lowest score (in hundredths, e.g. 450 = 4.50) that reaches this tier */
  minHundredths: number;
  band: string;
  color: string;
};

/** Five tiers, lowest first. Thresholds follow the proposal's illustrative table. */
export const TIERS: TierInfo[] = [
  { tier: 1, name: "Entry-level", minHundredths: 100, band: "1.00 – 1.49", color: "#C2416B" },
  { tier: 2, name: "Developing", minHundredths: 150, band: "1.50 – 2.49", color: "#C27C0E" },
  { tier: 3, name: "Established", minHundredths: 250, band: "2.50 – 3.49", color: "#7A4FD6" },
  { tier: 4, name: "High", minHundredths: 350, band: "3.50 – 4.49", color: "#2F6FE4" },
  { tier: 5, name: "Highest", minHundredths: 450, band: "4.50 – 5.00", color: "#1F9D6B" },
];

export const PROVISIONAL_COLOR = "#8A90A6";

/** Rating counts that trigger a milestone notification. */
export const MILESTONES = [1, 5, 10, 25, 50, 100, 250, 500];

/**
 * Simple average, rounded to 2 decimals (half up).
 * score = sum(ratings) / count(ratings).  Example: 5, 4, 4, 3 -> 16 / 4 = 4.00
 * Uses integer maths so 4.495 can never be mis-rounded by floating point.
 */
export function scoreFrom(total: number, count: number): number | null {
  if (count <= 0) return null;
  return Math.round((total * 100) / count) / 100;
}

/**
 * Map a score to a tier. Returns null ("provisional") until the user has at
 * least `minRatings` eligible ratings, so one 5-point vote can't make anyone top tier.
 */
export function tierForScore(score: number | null, count: number, minRatings: number): number | null {
  if (score === null || count < minRatings) return null;
  const hundredths = Math.round(score * 100);
  for (let i = TIERS.length - 1; i >= 0; i--) {
    if (hundredths >= TIERS[i].minHundredths) return TIERS[i].tier;
  }
  return 1;
}

export function tierInfo(tier: number | null | undefined): TierInfo | null {
  return TIERS.find((t) => t.tier === tier) ?? null;
}

export function formatScore(score: number | null): string {
  return score === null ? "–" : score.toFixed(2);
}
