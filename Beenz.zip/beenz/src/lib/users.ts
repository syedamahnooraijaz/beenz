// Read models for pages and API: profiles, search, leaderboard, feed, notifications.
import type { SessionUser } from "./auth";
import { config } from "./config";
import { query, queryOne } from "./db";
import { publicReputation, type Reputation } from "./reputation";

export type UserCard = {
  id: string;
  username: string;
  displayName: string;
  avatarColor: string;
  reputation: Reputation;
};

type CardRow = {
  id: string; username: string; display_name: string; avatar_color: string;
  score: string | null; tier: number | null; rating_count: number;
};

const CARD_COLUMNS = `u.id, u.username, u.display_name, u.avatar_color, u.score, u.tier, u.rating_count`;

export function toCard(r: CardRow): UserCard {
  return {
    id: r.id,
    username: r.username,
    displayName: r.display_name,
    avatarColor: r.avatar_color,
    reputation: publicReputation(r),
  };
}

/** SQL condition: no block between user u and the viewer ($n), in either direction. */
function notBlocked(param: string) {
  return `NOT EXISTS (SELECT 1 FROM blocks b
            WHERE (b.blocker_id = u.id AND b.blocked_id = ${param})
               OR (b.blocker_id = ${param} AND b.blocked_id = u.id))`;
}

// ---------------------------------------------------------------------------
export async function findUserByUsername(username: string) {
  return queryOne<{ id: string; status: string; username: string }>(
    `SELECT id, status, username FROM users WHERE lower(username) = lower($1)`,
    [username],
  );
}

export type Profile = UserCard & {
  bio: string;
  joinedAt: string;
  acceptsRatings: boolean;
  isMe: boolean;
  blockedByMe: boolean;
  myRating: number | null;
  canRate: boolean;
  history: { at: string; score: number }[];
};

/** A profile as `viewer` may see it, or null if it doesn't exist / is hidden from them. */
export async function getProfile(viewer: SessionUser | null, username: string): Promise<Profile | null> {
  const row = await queryOne<CardRow & { bio: string; created_at: Date; accepts_ratings: boolean; status: string }>(
    `SELECT ${CARD_COLUMNS}, u.bio, u.created_at, u.accepts_ratings, u.status
       FROM users u WHERE lower(u.username) = lower($1)`,
    [username],
  );
  if (!row) return null;
  const viewerIsMod = viewer?.role === "moderator" || viewer?.role === "admin";
  if (row.status !== "active" && !viewerIsMod) return null;

  const isMe = viewer?.id === row.id;
  let blockedByMe = false;
  let myRating: number | null = null;
  if (viewer && !isMe) {
    const rel = await queryOne<{ blocked_by_me: boolean; blocks_me: boolean; my_rating: number | null }>(
      `SELECT
         EXISTS (SELECT 1 FROM blocks WHERE blocker_id = $1 AND blocked_id = $2) AS blocked_by_me,
         EXISTS (SELECT 1 FROM blocks WHERE blocker_id = $2 AND blocked_id = $1) AS blocks_me,
         (SELECT value FROM ratings WHERE rater_id = $1 AND subject_id = $2) AS my_rating`,
      [viewer.id, row.id],
    );
    if (rel?.blocks_me && !viewerIsMod) return null; // people who blocked you are hidden from you
    blockedByMe = !!rel?.blocked_by_me;
    myRating = rel?.my_rating ?? null;
  }

  // Score history: only points where the user was ranked (protects early voters' privacy)
  const history = await query<{ calculated_at: Date; score: string }>(
    `SELECT calculated_at, score FROM (
        SELECT calculated_at, score FROM reputation_snapshots
         WHERE user_id = $1 AND tier IS NOT NULL
         ORDER BY calculated_at DESC LIMIT 60) s
      ORDER BY calculated_at`,
    [row.id],
  );

  return {
    ...toCard(row),
    bio: row.bio,
    joinedAt: row.created_at.toISOString(),
    acceptsRatings: row.accepts_ratings,
    isMe,
    blockedByMe,
    myRating,
    canRate: !!viewer && !isMe && viewer.status === "active" && row.accepts_ratings && !blockedByMe && row.status === "active",
    history: history.map((h) => ({ at: h.calculated_at.toISOString(), score: Number(h.score) })),
  };
}

// ---------------------------------------------------------------------------
export async function searchUsers(viewer: SessionUser, q: string, limit = 20): Promise<UserCard[]> {
  const term = q.trim().toLowerCase().slice(0, 40);
  const pattern = "%" + term.replace(/[\\%_]/g, (c) => "\\" + c) + "%";
  const rows = await query<CardRow>(
    `SELECT ${CARD_COLUMNS} FROM users u
      WHERE u.status = 'active' AND u.id <> $1 AND ${notBlocked("$1")}
        AND ($2 = '' OR lower(u.username) LIKE $3 OR lower(u.display_name) LIKE $3)
      ORDER BY (lower(u.username) = $2) DESC, u.rating_count DESC, u.created_at DESC
      LIMIT $4`,
    [viewer.id, term, pattern, limit],
  );
  return rows.map(toCard);
}

// ---------------------------------------------------------------------------
export const LEADERBOARD_PAGE_SIZE = 25;

export type LeaderboardEntry = UserCard & { rank: number };

/**
 * Ranked users only (tier is not null), public profiles only.
 * Order: score, then more ratings, then who joined first.
 * People with the same score AND the same number of ratings share a rank.
 */
export async function getLeaderboard(page: number) {
  const offset = (Math.max(1, page) - 1) * LEADERBOARD_PAGE_SIZE;
  const rows = await query<CardRow & { rank: string; total: string }>(
    `SELECT * FROM (
       SELECT ${CARD_COLUMNS}, u.created_at,
              RANK() OVER (ORDER BY u.score DESC, u.rating_count DESC) AS rank,
              count(*) OVER () AS total
         FROM users u
        WHERE u.tier IS NOT NULL AND u.status = 'active' AND u.is_public
     ) ranked
     ORDER BY rank, created_at
     LIMIT $1 OFFSET $2`,
    [LEADERBOARD_PAGE_SIZE, offset],
  );
  return {
    entries: rows.map((r) => ({ ...toCard(r), rank: Number(r.rank) })),
    total: rows.length ? Number(rows[0].total) : 0,
    page: Math.max(1, page),
    pageSize: LEADERBOARD_PAGE_SIZE,
  };
}

// ---------------------------------------------------------------------------
export type FeedItem = {
  id: string;
  type: "joined" | "ranked" | "tier_up" | "milestone" | "announcement";
  createdAt: string;
  data: Record<string, unknown>;
  user: UserCard | null;
};

export const FEED_PAGE_SIZE = 20;

export async function getFeed(viewer: SessionUser, before: number | null) {
  const rows = await query<CardRow & { event_id: string; type: FeedItem["type"]; data: Record<string, unknown>; created_at: Date }>(
    `SELECT f.id AS event_id, f.type, f.data, f.created_at, ${CARD_COLUMNS}
       FROM feed_events f
       LEFT JOIN users u ON u.id = f.user_id
      WHERE ($2::bigint IS NULL OR f.id < $2)
        AND (f.type = 'announcement'
             OR (u.status = 'active' AND u.is_public AND ${notBlocked("$1")}))
      ORDER BY f.id DESC
      LIMIT $3`,
    [viewer.id, before, FEED_PAGE_SIZE],
  );
  const items: FeedItem[] = rows.map((r) => ({
    id: String(r.event_id),
    type: r.type,
    createdAt: r.created_at.toISOString(),
    data: r.data,
    user: r.id && r.type !== "announcement" ? toCard(r) : null,
  }));
  return { items, nextBefore: items.length === FEED_PAGE_SIZE ? Number(items[items.length - 1].id) : null };
}

// ---------------------------------------------------------------------------
export type NotificationItem = {
  id: string; type: string; message: string; link: string | null; read: boolean; createdAt: string;
};

export async function getNotifications(userId: string, before: number | null, limit = 30) {
  const rows = await query<{ id: string; type: string; message: string; link: string | null; read_at: Date | null; created_at: Date }>(
    `SELECT id, type, message, link, read_at, created_at FROM notifications
      WHERE user_id = $1 AND ($2::bigint IS NULL OR id < $2)
      ORDER BY id DESC LIMIT $3`,
    [userId, before, limit],
  );
  const items: NotificationItem[] = rows.map((r) => ({
    id: String(r.id), type: r.type, message: r.message, link: r.link, read: !!r.read_at, createdAt: r.created_at.toISOString(),
  }));
  return { items, nextBefore: items.length === limit ? Number(items[items.length - 1].id) : null };
}

export async function unreadCount(userId: string): Promise<number> {
  const row = await queryOne<{ n: number }>(
    `SELECT count(*)::int AS n FROM notifications WHERE user_id = $1 AND read_at IS NULL`,
    [userId],
  );
  return row?.n ?? 0;
}

// ---------------------------------------------------------------------------
export type MyAccount = {
  id: string; username: string; email: string; displayName: string; bio: string; avatarColor: string;
  role: string; acceptsRatings: boolean; isPublic: boolean; onboarded: boolean; reputation: Reputation;
  ratingsGiven: number; blocked: { username: string; displayName: string }[];
};

export async function getMyAccount(userId: string): Promise<MyAccount | null> {
  const r = await queryOne<CardRow & { email: string; bio: string; role: string; accepts_ratings: boolean; is_public: boolean; onboarded: boolean; given: number }>(
    `SELECT ${CARD_COLUMNS}, u.email, u.bio, u.role, u.accepts_ratings, u.is_public, u.onboarded,
            (SELECT count(*)::int FROM ratings WHERE rater_id = u.id) AS given
       FROM users u WHERE u.id = $1`,
    [userId],
  );
  if (!r) return null;
  const blocked = await query<{ username: string; display_name: string }>(
    `SELECT u.username, u.display_name FROM blocks b JOIN users u ON u.id = b.blocked_id
      WHERE b.blocker_id = $1 ORDER BY b.created_at DESC`,
    [userId],
  );
  return {
    id: r.id, username: r.username, email: r.email, displayName: r.display_name, bio: r.bio,
    avatarColor: r.avatar_color, role: r.role, acceptsRatings: r.accepts_ratings, isPublic: r.is_public,
    onboarded: r.onboarded, reputation: publicReputation(r), ratingsGiven: r.given,
    blocked: blocked.map((b) => ({ username: b.username, displayName: b.display_name })),
  };
}

/** Score + tier for the "your standing" panel. The owner sees how far they are from being ranked. */
export async function myStanding(userId: string) {
  const r = await queryOne<{ score: string | null; tier: number | null; rating_count: number; rank: string | null }>(
    `SELECT u.score, u.tier, u.rating_count,
            (SELECT rank FROM (
               SELECT id, RANK() OVER (ORDER BY score DESC, rating_count DESC) AS rank
                 FROM users WHERE tier IS NOT NULL AND status = 'active' AND is_public) x
              WHERE x.id = u.id) AS rank
       FROM users u WHERE u.id = $1`,
    [userId],
  );
  if (!r) return null;
  return { ...publicReputation(r), rank: r.rank === null ? null : Number(r.rank), minRatings: config.minRatingsForTier };
}

/** People the viewer hasn't rated yet (newest first), for the "people to rate" list. */
export async function suggestPeople(viewer: SessionUser, limit = 5): Promise<UserCard[]> {
  const rows = await query<CardRow>(
    `SELECT ${CARD_COLUMNS} FROM users u
      WHERE u.status = 'active' AND u.id <> $1 AND u.accepts_ratings AND ${notBlocked("$1")}
        AND NOT EXISTS (SELECT 1 FROM ratings r WHERE r.rater_id = $1 AND r.subject_id = u.id)
      ORDER BY u.created_at DESC
      LIMIT $2`,
    [viewer.id, limit],
  );
  return rows.map(toCard);
}

export async function recentUsers(viewer: SessionUser, limit = 12): Promise<UserCard[]> {
  return searchUsers(viewer, "", limit);
}
