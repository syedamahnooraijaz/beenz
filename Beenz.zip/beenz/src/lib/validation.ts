// Input validation. Every check runs on the server; the browser forms only
// repeat some of them to give faster feedback.
import { config } from "./config";
import { AVATAR_COLORS, REPORT_REASONS } from "./constants";
import { fail } from "./http";

export { REPORT_REASONS };


const RESERVED = new Set([
  "admin", "administrator", "api", "beenz", "feed", "help", "leaderboard", "login", "logout",
  "me", "moderator", "notifications", "onboarding", "search", "settings", "signup", "support", "system",
]);

function str(value: unknown): string {
  return typeof value === "string" ? value : "";
}

/** Remove control characters and trim. */
function clean(value: unknown): string {
  // eslint-disable-next-line no-control-regex
  return str(value).replace(/[\u0000-\u001F\u007F]/g, "").trim();
}

export function username(value: unknown): string {
  const v = clean(value).toLowerCase();
  if (!/^[a-z0-9_]{3,20}$/.test(v)) {
    throw fail.badRequest("invalid_username", "Usernames are 3–20 characters: letters, numbers and underscores.", { field: "username" });
  }
  if (RESERVED.has(v)) throw fail.badRequest("invalid_username", "That username is reserved. Pick another one.", { field: "username" });
  return v;
}

export function email(value: unknown): string {
  const v = clean(value).toLowerCase();
  if (v.length > 254 || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v)) {
    throw fail.badRequest("invalid_email", "Enter a valid email address.", { field: "email" });
  }
  const domains = config.allowedEmailDomains;
  if (domains.length && !domains.some((d) => v.endsWith("@" + d))) {
    throw fail.badRequest("email_domain_not_allowed", `Sign-up is limited to ${domains.map((d) => "@" + d).join(", ")} addresses.`, { field: "email" });
  }
  return v;
}

export function password(value: unknown): string {
  const v = str(value);
  if (v.length < 8) throw fail.badRequest("weak_password", "Passwords need at least 8 characters.", { field: "password" });
  if (v.length > 200) throw fail.badRequest("invalid_password", "That password is too long.", { field: "password" });
  return v;
}

export function displayName(value: unknown): string {
  const v = clean(value).replace(/\s+/g, " ");
  if (v.length < 1 || v.length > 40) throw fail.badRequest("invalid_display_name", "Display names are 1–40 characters.", { field: "displayName" });
  return v;
}

export function bio(value: unknown): string {
  const v = clean(value).replace(/\s+/g, " ");
  if (v.length > 160) throw fail.badRequest("invalid_bio", "Bios are at most 160 characters.", { field: "bio" });
  return v;
}

export function avatarColor(value: unknown): string {
  const v = str(value).toUpperCase();
  if (!AVATAR_COLORS.includes(v)) throw fail.badRequest("invalid_color", "Pick one of the listed colours.", { field: "avatarColor" });
  return v;
}

export function ratingValue(value: unknown): number {
  if (typeof value !== "number" || !Number.isInteger(value) || value < 1 || value > 5) {
    throw fail.badRequest("invalid_rating", "A rating must be a whole number from 1 to 5.");
  }
  return value;
}

export function bool(value: unknown, field: string): boolean {
  if (typeof value !== "boolean") throw fail.badRequest("invalid_value", `${field} must be true or false.`);
  return value;
}


export type ReportReason = keyof typeof REPORT_REASONS;

export function reportReason(value: unknown): ReportReason {
  const v = str(value);
  if (!(v in REPORT_REASONS)) throw fail.badRequest("invalid_reason", "Choose a reason for the report.");
  return v as ReportReason;
}

export function longText(value: unknown, max: number, field: string): string {
  const v = str(value).trim();
  if (v.length > max) throw fail.badRequest("too_long", `${field} is limited to ${max} characters.`);
  return v;
}
