// =============================================================================
// End-to-end API tests, written against the proposal's acceptance criteria.
//
// They start the real app (`next start`) on port 3100 against a THROWAWAY
// database, then call the REST API the same way the browser does.
//
//   1. Create an empty database whose name contains "test", e.g. beenz_test
//   2. Put TEST_DATABASE_URL=postgres://.../beenz_test in .env.local
//   3. npm run build && npm test
// =============================================================================
import assert from "node:assert/strict";
import { spawn } from "node:child_process";
import { after, before, describe, test } from "node:test";
import pg from "pg";
import { loadEnv } from "../scripts/env.mjs";

loadEnv();
const DB = process.env.TEST_DATABASE_URL;
if (!DB) {
  console.log("API tests skipped: set TEST_DATABASE_URL to a throwaway database (see tests/api.test.mjs).");
  process.exit(0);
}
if (!/test/i.test(new URL(DB).pathname)) {
  throw new Error("TEST_DATABASE_URL must name a database containing 'test' - it is wiped before every run.");
}

const PORT = 3100;
const BASE = `http://localhost:${PORT}`;
const ADMIN_EMAIL = "admin@test.local";
const db = new pg.Client({ connectionString: DB });
let server;

// ----------------------------------------------------------------- helpers
function run(cmd, args, env) {
  return new Promise((resolve, reject) => {
    const p = spawn(cmd, args, { env: { ...process.env, ...env }, stdio: "inherit" });
    p.on("exit", (code) => (code === 0 ? resolve() : reject(new Error(`${cmd} exited with ${code}`))));
  });
}

async function waitForServer() {
  for (let i = 0; i < 60; i++) {
    try {
      const res = await fetch(BASE + "/login");
      if (res.ok) return;
    } catch {
      /* not up yet */
    }
    await new Promise((r) => setTimeout(r, 500));
  }
  throw new Error("Server did not start. Did you run `npm run build` first?");
}

let ipCounter = 0;
/** A browser-like client with its own cookie jar and IP address. */
class Client {
  constructor() {
    ipCounter++;
    this.ip = `10.${Math.floor(ipCounter / 250)}.${ipCounter % 250}.7`;
    this.cookie = null;
  }
  async req(method, path, body, headers = {}) {
    const res = await fetch(BASE + path, {
      method,
      redirect: "manual",
      headers: {
        "x-forwarded-for": this.ip,
        ...(body !== undefined ? { "content-type": "application/json" } : {}),
        ...(this.cookie ? { cookie: this.cookie } : {}),
        ...headers,
      },
      body: body === undefined ? undefined : typeof body === "string" ? body : JSON.stringify(body),
    });
    const set = res.headers.get("set-cookie");
    const m = set?.match(/beenz_session=([^;]*)/);
    if (m) this.cookie = m[1] ? `beenz_session=${m[1]}` : null;
    let json = null;
    try {
      json = await res.json();
    } catch {
      /* not JSON */
    }
    return { status: res.status, body: json };
  }
}

async function newUser(username, email = `${username}@test.local`) {
  const c = new Client();
  const r = await c.req("POST", "/api/v1/auth/signup", { username, email, password: "password123", displayName: username });
  assert.equal(r.status, 201, JSON.stringify(r.body));
  Object.assign(c, { username, email, id: r.body.data.user.id });
  return c;
}

const rate = (c, subject, value) => c.req("PUT", `/api/v1/users/${subject}/ratings/me`, { value });
const unrate = (c, subject) => c.req("DELETE", `/api/v1/users/${subject}/ratings/me`);
async function reputationOf(subject, viewer) {
  const r = await viewer.req("GET", `/api/v1/users/${subject}/reputation`);
  assert.equal(r.status, 200, JSON.stringify(r.body));
  return r.body.data.reputation;
}
/** "Time travel": make every past rating change look a day old, so cooldowns have passed. */
const expireCooldowns = () => db.query(`UPDATE rating_audit_history SET created_at = created_at - interval '1 day'`);
const count = async (sql, params = []) => Number((await db.query(sql, params)).rows[0].n);

// ------------------------------------------------------------------- setup
before(async () => {
  await db.connect();
  await db.query("DROP SCHEMA public CASCADE; CREATE SCHEMA public;");
  await run("node", ["scripts/db-setup.mjs"], { DATABASE_URL: DB });
  server = spawn(process.execPath, ["node_modules/next/dist/bin/next", "start", "-p", String(PORT)], {
    env: {
      ...process.env,
      NODE_ENV: "production",
      DATABASE_URL: DB,
      ADMIN_EMAILS: ADMIN_EMAIL,
      ALLOWED_EMAIL_DOMAINS: "",
      MIN_RATINGS_FOR_TIER: "3",
      RATING_CHANGE_COOLDOWN_MINUTES: "10",
      MAX_RATING_ACTIONS_PER_HOUR: "60",
    },
    stdio: "ignore",
  });
  await waitForServer();
});

after(async () => {
  server?.kill();
  await db.end();
});

// ------------------------------------------------------------------- tests
describe("Accounts: register, authenticate, keep a persistent profile", () => {
  test("sign up logs you in and creates a profile", async () => {
    const alice = await newUser("alice");
    const me = await alice.req("GET", "/api/v1/me");
    assert.equal(me.status, 200);
    assert.equal(me.body.data.me.username, "alice");
    assert.equal(me.body.data.me.role, "user");
  });

  test("usernames and emails are unique (case-insensitive)", async () => {
    const c = new Client();
    let r = await c.req("POST", "/api/v1/auth/signup", { username: "ALICE", email: "other@test.local", password: "password123" });
    assert.equal(r.status, 409);
    assert.equal(r.body.error.code, "username_taken");
    r = await c.req("POST", "/api/v1/auth/signup", { username: "alice2", email: "Alice@Test.Local", password: "password123" });
    assert.equal(r.status, 409);
    assert.equal(r.body.error.code, "email_taken");
  });

  test("bad sign-up input is rejected with a clear error", async () => {
    const c = new Client();
    const bad = [
      [{ username: "ab", email: "x1@test.local", password: "password123" }, "invalid_username"],
      [{ username: "admin", email: "x2@test.local", password: "password123" }, "invalid_username"],
      [{ username: "okname", email: "not-an-email", password: "password123" }, "invalid_email"],
      [{ username: "okname", email: "x3@test.local", password: "short" }, "weak_password"],
    ];
    for (const [body, code] of bad) {
      const r = await c.req("POST", "/api/v1/auth/signup", body);
      assert.equal(r.status, 400);
      assert.equal(r.body.error.code, code);
    }
  });

  test("passwords are hashed, never stored as plain text", async () => {
    const row = (await db.query(`SELECT password_hash FROM users WHERE username = 'alice'`)).rows[0];
    assert.match(row.password_hash, /^scrypt\$/);
    assert.ok(!row.password_hash.includes("password123"));
  });

  test("log in, log out, and wrong passwords", async () => {
    const c = new Client();
    let r = await c.req("POST", "/api/v1/auth/login", { email: "alice@test.local", password: "wrong-password" });
    assert.equal(r.status, 401);
    assert.equal(r.body.error.code, "invalid_credentials");
    r = await c.req("POST", "/api/v1/auth/login", { email: "ALICE@test.local", password: "password123" });
    assert.equal(r.status, 200);
    assert.equal((await c.req("GET", "/api/v1/me")).status, 200);
    await c.req("POST", "/api/v1/auth/logout");
    assert.equal((await c.req("GET", "/api/v1/me")).status, 401);
  });

  test("profile edits persist", async () => {
    const c = new Client();
    await c.req("POST", "/api/v1/auth/login", { email: "alice@test.local", password: "password123" });
    let r = await c.req("PATCH", "/api/v1/me", { displayName: "Alice A.", bio: "Hello", avatarColor: "#1F9D6B" });
    assert.equal(r.status, 200);
    assert.equal(r.body.data.me.displayName, "Alice A.");
    r = await c.req("PATCH", "/api/v1/me", { avatarColor: "#123456" });
    assert.equal(r.status, 400);
    const profile = await c.req("GET", "/api/v1/users/alice");
    assert.equal(profile.body.data.profile.bio, "Hello");
  });
});

describe("Ratings: eligibility, duplicates, updates and deletes", () => {
  let a, b, c, subject;
  before(async () => {
    [a, b, c, subject] = await Promise.all(["rater_a", "rater_b", "rater_c", "subject1"].map((n) => newUser(n)));
  });

  test("you must be logged in to rate", async () => {
    const r = await rate(new Client(), "subject1", 5);
    assert.equal(r.status, 401);
  });

  test("self-rating is rejected", async () => {
    const r = await rate(subject, "subject1", 5);
    assert.equal(r.status, 400);
    assert.equal(r.body.error.code, "self_rating");
  });

  test("only whole numbers 1 to 5 are accepted", async () => {
    for (const v of [0, 6, 2.5, "3", null, -1]) {
      const r = await rate(a, "subject1", v);
      assert.equal(r.status, 400, `value ${JSON.stringify(v)}`);
      assert.equal(r.body.error.code, "invalid_rating");
    }
    assert.equal((await rate(a, "nobody_here", 3)).status, 404);
  });

  test("a new user has an explicit empty reputation", async () => {
    const rep = await reputationOf("subject1", a);
    assert.deepEqual(rep, { score: null, tier: null, ratingCount: 0, minRatings: 3 });
  });

  test("users stay provisional (no score shown) until 3 ratings", async () => {
    let r = await rate(a, "subject1", 5);
    assert.equal(r.status, 200);
    assert.equal(r.body.data.myRating, 5);
    r = await rate(b, "subject1", 4);
    assert.deepEqual(r.body.data.reputation, { score: null, tier: null, ratingCount: 2, minRatings: 3 });
  });

  test("the third rating ranks the user: (5 + 4 + 3) / 3 = 4.00, Tier 4", async () => {
    const r = await rate(c, "subject1", 3);
    assert.deepEqual(r.body.data.reputation, { score: 4, tier: 4, ratingCount: 3, minRatings: 3 });
    // the profile shows exactly what the server calculated
    assert.deepEqual(await reputationOf("subject1", a), r.body.data.reputation);
    assert.equal(await count(`SELECT count(*) AS n FROM notifications WHERE user_id = $1 AND type = 'ranked'`, [subject.id]), 1);
  });

  test("repeated identical requests never create duplicate votes", async () => {
    const before = await count(`SELECT count(*) AS n FROM rating_audit_history`);
    const results = await Promise.all(Array.from({ length: 10 }, () => rate(a, "subject1", 5)));
    assert.ok(results.every((r) => r.status === 200));
    assert.equal(await count(`SELECT count(*) AS n FROM ratings WHERE rater_id = $1 AND subject_id = $2`, [a.id, subject.id]), 1);
    assert.equal(await count(`SELECT count(*) AS n FROM rating_audit_history`), before);
    assert.equal((await reputationOf("subject1", a)).ratingCount, 3);
  });

  test("changing a rating straight away hits the cooldown", async () => {
    const r = await rate(a, "subject1", 1);
    assert.equal(r.status, 429);
    assert.equal(r.body.error.code, "cooldown");
    assert.ok(r.body.error.retryAfter > 0);
  });

  test("updating a rating updates the score: (1 + 4 + 3) / 3 = 2.67, Tier 3", async () => {
    await expireCooldowns();
    const r = await rate(a, "subject1", 1);
    assert.equal(r.status, 200);
    assert.deepEqual(r.body.data.reputation, { score: 2.67, tier: 3, ratingCount: 3, minRatings: 3 });
  });

  test("deleting a rating updates the score and can make someone provisional again", async () => {
    await expireCooldowns();
    const r = await unrate(b, "subject1");
    assert.equal(r.status, 200);
    assert.equal(r.body.data.myRating, null);
    assert.deepEqual(r.body.data.reputation, { score: null, tier: null, ratingCount: 2, minRatings: 3 });
    assert.equal(await count(`SELECT count(*) AS n FROM notifications WHERE user_id = $1 AND type = 'provisional'`, [subject.id]), 1);
  });

  test("every change is recorded in the audit history", async () => {
    const rows = (await db.query(`SELECT action FROM rating_audit_history WHERE subject_id = $1 ORDER BY id`, [subject.id])).rows;
    assert.deepEqual(rows.map((r) => r.action), ["create", "create", "create", "update", "delete"]);
  });

  test("votes are private: only the rater sees their own rating, nobody sees who rated", async () => {
    const asRater = await a.req("GET", "/api/v1/users/subject1");
    assert.equal(asRater.body.data.profile.myRating, 1);
    const asOther = await b.req("GET", "/api/v1/users/subject1");
    assert.equal(asOther.body.data.profile.myRating, null);
    const asSubject = JSON.stringify((await subject.req("GET", "/api/v1/users/subject1")).body);
    for (const name of ["rater_a", "rater_b", "rater_c", "@test.local"]) assert.ok(!asSubject.includes(name), `leaked ${name}`);
  });
});

describe("Concurrency: simultaneous ratings can't corrupt the score", () => {
  test("20 people rating at the same moment", async () => {
    const target = await newUser("busy_person");
    const raters = await Promise.all(Array.from({ length: 20 }, (_, i) => newUser(`crowd_${i}`)));
    const results = await Promise.all(raters.map((r, i) => rate(r, "busy_person", (i % 5) + 1)));
    assert.ok(results.every((r) => r.status === 200));
    const row = (await db.query(`SELECT score, rating_count FROM users WHERE id = $1`, [target.id])).rows[0];
    const truth = (await db.query(`SELECT count(*)::int AS n, round(avg(value), 2) AS avg FROM ratings WHERE subject_id = $1`, [target.id])).rows[0];
    assert.equal(row.rating_count, 20);
    assert.equal(Number(row.score), Number(truth.avg)); // (4 x (1+2+3+4+5)) / 20 = 3.00
    assert.equal(Number(row.score), 3);
  });
});

describe("Leaderboard", () => {
  test("ranked, public users only, correctly ordered, ties share a rank", async () => {
    const [t1, t2] = await Promise.all([newUser("tie_one"), newUser("tie_two")]);
    const judges = await Promise.all(["judge_1", "judge_2", "judge_3"].map((n) => newUser(n)));
    for (const j of judges) {
      await rate(j, "tie_one", 5);
      await rate(j, "tie_two", 5);
    }
    const r = await t1.req("GET", "/api/v1/leaderboard");
    assert.equal(r.status, 200);
    const entries = r.body.data.entries;
    // every entry is ranked
    assert.ok(entries.every((e) => e.reputation.tier !== null));
    // sorted by score, then rating count
    for (let i = 1; i < entries.length; i++) {
      const [p, q] = [entries[i - 1].reputation, entries[i].reputation];
      assert.ok(p.score > q.score || (p.score === q.score && p.ratingCount >= q.ratingCount), "order");
      assert.ok(entries[i].rank >= entries[i - 1].rank, "ranks never go down");
    }
    const one = entries.find((e) => e.username === "tie_one");
    const two = entries.find((e) => e.username === "tie_two");
    assert.equal(one.rank, two.rank); // same score + same count = same rank
    assert.equal(one.rank, 1);
    // provisional users are not listed
    assert.ok(!entries.some((e) => e.username === "judge_1"));
    // hiding yourself removes you from the leaderboard
    await t2.req("PATCH", "/api/v1/me", { isPublic: false });
    const after = (await t1.req("GET", "/api/v1/leaderboard")).body.data.entries;
    assert.ok(!after.some((e) => e.username === "tie_two"));
  });
});

describe("Blocking", () => {
  test("blocking stops ratings both ways and hides the blocker", async () => {
    const [x, y] = await Promise.all([newUser("blocker_x"), newUser("blocked_y")]);
    assert.equal((await x.req("POST", "/api/v1/users/blocked_y/block")).status, 200);
    let r = await rate(y, "blocker_x", 1);
    assert.equal(r.status, 403);
    assert.equal(r.body.error.code, "blocked");
    assert.equal((await rate(x, "blocked_y", 1)).body.error.code, "blocked");
    assert.equal((await y.req("GET", "/api/v1/users/blocker_x")).status, 404); // hidden from the blocked person
    const view = await x.req("GET", "/api/v1/users/blocked_y");
    assert.equal(view.body.data.profile.blockedByMe, true);
    const search = await y.req("GET", "/api/v1/search?q=blocker");
    assert.ok(!search.body.data.users.some((u) => u.username === "blocker_x"));
    await x.req("DELETE", "/api/v1/users/blocked_y/block");
    assert.equal((await rate(y, "blocker_x", 4)).status, 200);
    assert.equal((await x.req("POST", "/api/v1/users/blocker_x/block")).status, 400); // can't block yourself
  });
});

describe("Reports and moderation", () => {
  let admin, mod, reporter, troll, victim, fans;
  before(async () => {
    admin = await newUser("the_admin", ADMIN_EMAIL);
    [mod, reporter, troll, victim] = await Promise.all(["the_mod", "reporter_r", "troll_t", "victim_v"].map((n) => newUser(n)));
    fans = await Promise.all(["fan_1", "fan_2"].map((n) => newUser(n)));
    await rate(fans[0], "victim_v", 5);
    await rate(fans[1], "victim_v", 5);
    await rate(troll, "victim_v", 1); // (5 + 5 + 1) / 3 = 3.67
  });

  test("ADMIN_EMAILS accounts become admins", async () => {
    assert.equal((await admin.req("GET", "/api/v1/me")).body.data.me.role, "admin");
  });

  test("regular users can't open moderator tools", async () => {
    assert.equal((await reporter.req("GET", "/api/v1/admin/reports")).status, 403);
    assert.equal((await reporter.req("GET", "/api/v1/admin/stats")).status, 403);
    assert.equal((await reporter.req("POST", `/api/v1/admin/users/${troll.id}`, { action: "suspend", reason: "x" })).status, 403);
  });

  test("admins can make moderators; moderators can't use admin-only tools", async () => {
    const r = await admin.req("POST", `/api/v1/admin/users/${mod.id}`, { action: "set_role", role: "moderator" });
    assert.equal(r.status, 200);
    assert.equal((await mod.req("GET", "/api/v1/admin/reports")).status, 200);
    assert.equal((await mod.req("POST", `/api/v1/admin/users/${troll.id}`, { action: "reset_password" })).status, 403);
    assert.equal((await mod.req("POST", `/api/v1/admin/users/${admin.id}`, { action: "suspend", reason: "x" })).status, 403);
  });

  test("reporting: one open report per person, never yourself", async () => {
    let r = await reporter.req("POST", "/api/v1/reports", { username: "troll_t", reason: "rating_abuse", details: "Gives everyone 1." });
    assert.equal(r.status, 201);
    r = await reporter.req("POST", "/api/v1/reports", { username: "troll_t", reason: "harassment" });
    assert.equal(r.status, 409);
    assert.equal(r.body.error.code, "already_reported");
    r = await reporter.req("POST", "/api/v1/reports", { username: "reporter_r", reason: "spam" });
    assert.equal(r.status, 400);
    r = await reporter.req("POST", "/api/v1/reports", { username: "troll_t", reason: "made_up_reason" });
    assert.equal(r.status, 400);
  });

  test("moderators see the report and are notified", async () => {
    const list = await mod.req("GET", "/api/v1/admin/reports?status=open");
    const report = list.body.data.reports.find((x) => x.subject.username === "troll_t");
    assert.ok(report);
    assert.equal(report.reporter, "reporter_r");
    assert.ok(await count(`SELECT count(*) AS n FROM notifications WHERE user_id = $1 AND type = 'report'`, [mod.id]) >= 1);
  });

  test("suspending removes the account's ratings from everyone's score", async () => {
    let r = await mod.req("POST", `/api/v1/admin/users/${troll.id}`, { action: "suspend" });
    assert.equal(r.status, 400); // a reason is required
    r = await mod.req("POST", `/api/v1/admin/users/${troll.id}`, { action: "suspend", reason: "Rating abuse" });
    assert.equal(r.status, 200);
    let rep = await reputationOf("victim_v", reporter);
    assert.equal(rep.ratingCount, 2); // troll's 1 no longer counts -> provisional again
    assert.equal(rep.tier, null);
    // suspended users are logged out and can't log back in
    assert.equal((await troll.req("GET", "/api/v1/me")).status, 401);
    const login = await troll.req("POST", "/api/v1/auth/login", { email: troll.email, password: "password123" });
    assert.equal(login.status, 403);
    assert.equal(login.body.error.code, "suspended");
    assert.match(login.body.error.message, /Rating abuse/);
    // unsuspending brings the ratings back
    await mod.req("POST", `/api/v1/admin/users/${troll.id}`, { action: "unsuspend" });
    rep = await reputationOf("victim_v", reporter);
    assert.deepEqual([rep.ratingCount, rep.score], [3, 3.67]);
  });

  test("moderators can remove every rating an account gave", async () => {
    const r = await mod.req("POST", `/api/v1/admin/users/${troll.id}`, { action: "remove_ratings", reason: "Brigading" });
    assert.equal(r.status, 200);
    assert.equal((await reputationOf("victim_v", reporter)).ratingCount, 2);
    assert.equal(await count(`SELECT count(*) AS n FROM rating_audit_history WHERE rater_id = $1 AND action = 'moderator_remove'`, [troll.id]), 1);
  });

  test("closing a report notifies the reporter; every action is logged", async () => {
    const list = await mod.req("GET", "/api/v1/admin/reports?status=open");
    const report = list.body.data.reports.find((x) => x.subject.username === "troll_t");
    const r = await mod.req("PATCH", `/api/v1/admin/reports/${report.id}`, { status: "resolved", note: "Suspended and ratings removed" });
    assert.equal(r.status, 200);
    assert.equal((await mod.req("PATCH", `/api/v1/admin/reports/${report.id}`, { status: "dismissed" })).status, 409);
    assert.equal(await count(`SELECT count(*) AS n FROM notifications WHERE user_id = $1 AND type = 'report_update'`, [reporter.id]), 1);
    await mod.req("GET", `/api/v1/admin/users/${troll.id}/ratings-given`);
    const actions = (await db.query(`SELECT action FROM moderation_actions WHERE moderator_id = $1 ORDER BY id`, [mod.id])).rows.map((x) => x.action);
    assert.deepEqual(actions, ["suspend", "unsuspend", "remove_ratings", "resolve_report"]);
    assert.equal(await count(`SELECT count(*) AS n FROM audit_logs WHERE actor_id = $1 AND action = 'view_ratings_given'`, [mod.id]), 1);
  });

  test("moderators don't see emails; admins do", async () => {
    const asMod = await mod.req("GET", "/api/v1/admin/users?q=troll");
    assert.equal(asMod.body.data.users[0].email, null);
    const asAdmin = await admin.req("GET", "/api/v1/admin/users?q=troll");
    assert.equal(asAdmin.body.data.users[0].email, "troll_t@test.local");
  });
});

describe("Security", () => {
  test("requests from other websites are blocked (CSRF)", async () => {
    const c = await newUser("csrf_target");
    const r = await c.req("PATCH", "/api/v1/me", { bio: "hacked" }, { origin: "https://evil.example" });
    assert.equal(r.status, 403);
    assert.equal(r.body.error.code, "bad_origin");
  });

  test("private endpoints need a login", async () => {
    const anon = new Client();
    for (const path of ["/api/v1/feed", "/api/v1/leaderboard", "/api/v1/search?q=a", "/api/v1/notifications", "/api/v1/me"]) {
      assert.equal((await anon.req("GET", path)).status, 401, path);
    }
  });

  test("broken JSON and SQL-looking input are handled safely", async () => {
    const c = await newUser("safe_user");
    assert.equal((await c.req("PATCH", "/api/v1/me", "{not json")).status, 400);
    const r = await c.req("GET", `/api/v1/search?q=${encodeURIComponent("' OR 1=1; DROP TABLE users; --")}`);
    assert.equal(r.status, 200);
    assert.deepEqual(r.body.data.users, []);
    assert.ok(await count(`SELECT count(*) AS n FROM users`) > 10);
  });

  test("repeated wrong passwords are rate limited", async () => {
    const c = new Client();
    let last;
    for (let i = 0; i < 11; i++) last = await c.req("POST", "/api/v1/auth/login", { email: "alice@test.local", password: "nope-nope" });
    assert.equal(last.status, 429);
    assert.equal(last.body.error.code, "rate_limited");
  });
});

describe("Account deletion", () => {
  test("deleting an account removes its ratings and recalculates scores", async () => {
    const leaver = await newUser("leaver");
    const target = await newUser("left_behind");
    const others = await Promise.all(["lb_1", "lb_2"].map((n) => newUser(n)));
    await rate(others[0], "left_behind", 2);
    await rate(others[1], "left_behind", 2);
    await rate(leaver, "left_behind", 5); // (2 + 2 + 5) / 3 = 3.00
    assert.equal((await reputationOf("left_behind", target)).score, 3);
    assert.equal((await leaver.req("DELETE", "/api/v1/me", { password: "wrong" })).status, 400);
    assert.equal((await leaver.req("DELETE", "/api/v1/me", { password: "password123" })).status, 200);
    const rep = await reputationOf("left_behind", target);
    assert.equal(rep.ratingCount, 2);
    const login = await new Client().req("POST", "/api/v1/auth/login", { email: leaver.email, password: "password123" });
    assert.equal(login.status, 401);
  });
});

describe("Feed and notifications", () => {
  test("the feed shows events, never individual ratings", async () => {
    const admin = new Client();
    await admin.req("POST", "/api/v1/auth/login", { email: ADMIN_EMAIL, password: "password123" });
    await admin.req("POST", "/api/v1/admin/announcements", { text: "Exams next week. Be kind." });
    const viewer = await newUser("feed_viewer");
    const feed = await viewer.req("GET", "/api/v1/feed");
    assert.equal(feed.status, 200);
    const types = new Set(feed.body.data.items.map((i) => i.type));
    assert.ok(types.has("announcement"));
    assert.ok(types.has("joined"));
    const text = JSON.stringify(feed.body);
    assert.ok(!text.includes("\"value\""), "no rating values in the feed");
  });

  test("milestones are sent once, and notifications can be marked read", async () => {
    const subject = new Client();
    await subject.req("POST", "/api/v1/auth/login", { email: "busy_person@test.local", password: "password123" });
    const list = await subject.req("GET", "/api/v1/notifications");
    const firsts = list.body.data.items.filter((n) => n.message === "You received your first rating.");
    assert.equal(firsts.length, 1);
    assert.ok(list.body.data.unread > 0);
    await subject.req("POST", "/api/v1/notifications/read");
    assert.equal((await subject.req("GET", "/api/v1/notifications")).body.data.unread, 0);
  });
});
