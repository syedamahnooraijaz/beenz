// Unit tests for the scoring rules (no database needed).
// Run: node --import tsx --test tests/unit.test.ts
import assert from "node:assert/strict";
import { test } from "node:test";
import { MILESTONES, scoreFrom, tierForScore } from "../src/lib/tiers";

test("simple average, rounded to 2 decimals", () => {
  assert.equal(scoreFrom(16, 4), 4.0); // proposal example: 5, 4, 4, 3
  assert.equal(scoreFrom(13, 3), 4.33);
  assert.equal(scoreFrom(14, 3), 4.67);
  assert.equal(scoreFrom(5, 1), 5.0);
  assert.equal(scoreFrom(0, 0), null); // no ratings -> no score
});

test("rounding is exact at half points (no floating point surprises)", () => {
  assert.equal(scoreFrom(899, 200), 4.5); // 4.495 rounds up to 4.50
  assert.equal(scoreFrom(897, 200), 4.49); // 4.485 -> 4.49
  assert.equal(scoreFrom(299, 200), 1.5); // 1.495 -> 1.50
});

test("tier boundaries follow the threshold table", () => {
  const cases: [number, number][] = [
    [1.0, 1], [1.49, 1], [1.5, 2], [2.49, 2], [2.5, 3],
    [3.49, 3], [3.5, 4], [4.49, 4], [4.5, 5], [5.0, 5],
  ];
  for (const [score, tier] of cases) {
    assert.equal(tierForScore(score, 10, 3), tier, `score ${score} should be tier ${tier}`);
  }
});

test("provisional until the minimum number of ratings", () => {
  assert.equal(tierForScore(5, 1, 3), null); // one 5-point vote is NOT top tier
  assert.equal(tierForScore(5, 2, 3), null);
  assert.equal(tierForScore(5, 3, 3), 5);
  assert.equal(tierForScore(null, 0, 3), null);
});

test("milestones are increasing and start at the first rating", () => {
  assert.equal(MILESTONES[0], 1);
  for (let i = 1; i < MILESTONES.length; i++) assert.ok(MILESTONES[i] > MILESTONES[i - 1]);
});
